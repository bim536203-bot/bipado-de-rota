package br.com.leitorencomendas

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.lang.ref.WeakReference
import java.util.concurrent.Executors

/** A consulta de atualização nunca bloqueia a inicialização do app. */
class BipadoApplication:Application(),Application.ActivityLifecycleCallbacks {
 private var foreground:WeakReference<Activity>?=null
 private val ui=Handler(Looper.getMainLooper())
 private val worker=Executors.newSingleThreadExecutor()
 @Volatile private var checking=false
 @Volatile private var lastAttempt=0L
 override fun onCreate(){
  super.onCreate()
  registerActivityLifecycleCallbacks(this)
  val cm=getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
  cm.registerDefaultNetworkCallback(object:android.net.ConnectivityManager.NetworkCallback(){
   override fun onAvailable(network:android.net.Network){ui.post{checkInBackground()}}
   override fun onCapabilitiesChanged(network:android.net.Network,caps:android.net.NetworkCapabilities){
    if(caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED))ui.post{checkInBackground()}
   }
  })
 }
 private fun showRequired(){
  val a=foreground?.get() ?: return
  if(a is UpdateActivity || a.isFinishing) return
  if(Updater.pending(a)!=null){
   stopService(Intent(this,CaptureService::class.java))
   Updater.openGate(a)
  }
 }
 fun checkInBackground(){
  if(Updater.pending(this)!=null){showRequired();return}
  val now=SystemClock.elapsedRealtime()
  if(checking || (lastAttempt>0 && now-lastAttempt<60000))return
  if(!Updater.hasInternet(this))return
  checking=true;lastAttempt=now
  worker.execute{
   try {Updater.check(this)}catch(e:Exception){Log.w("BipadoUpdate","Consulta indisponível; app continua aberto",e)}
   finally {checking=false;ui.post{showRequired()}}
  }
 }
 override fun onActivityResumed(a:Activity){
  foreground=WeakReference(a)
  if(a !is UpdateActivity){
   if(Updater.pending(a)!=null)showRequired() else checkInBackground()
  }
 }
 override fun onActivityCreated(a:Activity,s:Bundle?){}
 override fun onActivityStarted(a:Activity){TouchFeedback.install(a.window.decorView)}
 override fun onActivityPaused(a:Activity){if(foreground?.get()===a)foreground=null}
 override fun onActivityStopped(a:Activity){}
 override fun onActivitySaveInstanceState(a:Activity,s:Bundle){}
 override fun onActivityDestroyed(a:Activity){}
}
