package br.com.leitorencomendas

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Histórico só de operações APAGAR TUDO / substituição por restauração. */
class HistoryActivity:Activity() {
 private lateinit var root:LinearLayout
 private var showingDetails=false
 private fun dp(n:Int)=(n*resources.displayMetrics.density+.5f).toInt()
 private fun box(color:Int=0xFFF2F5FA.toInt())=GradientDrawable().apply{setColor(color);cornerRadius=dp(14).toFloat();setStroke(dp(1),0xFFD8DFE9.toInt())}
 private fun line(value:String,size:Float=17f,bold:Boolean=false,color:Int=Color.BLACK)=TextView(this).apply{
  text=value;textSize=size;setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD);setPadding(dp(5),dp(7),dp(5),dp(7))
 }
 private fun fmt(at:Long,pattern:String)=SimpleDateFormat(pattern,Locale.forLanguageTag("pt-BR")).format(Date(at))
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);listHistory()}
 private fun frame(heading:String):LinearLayout{
  root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE);setPadding(dp(15),dp(18),dp(15),dp(12))}
  val back=Button(this).apply{text="← VOLTAR";setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(0xFF216BE0.toInt());setOnClickListener{if(showingDetails)listHistory() else finish()}}
  root.addView(back,LinearLayout.LayoutParams(-1,dp(50)))
  root.addView(line(heading,23f,true,0xFF172C50.toInt()))
  val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  root.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f))
  setContentView(root);return list
 }
 private fun askDeleteHistory(at:Long, fromDetails:Boolean=false){
  AlertDialog.Builder(this).setTitle("Apagar esta lista do histórico?")
   .setMessage("Se confirmar, esta lista apagada será removida do histórico imediatamente.")
   .setNegativeButton("CANCELAR",null)
   .setPositiveButton("APAGAR"){_,_->
    if(Store.deleteHistory(this,at)){
     Toast.makeText(this,"Lista apagada do histórico",Toast.LENGTH_SHORT).show()
     if(fromDetails) listHistory() else listHistory()
    } else Toast.makeText(this,"Não foi possível apagar esta lista",Toast.LENGTH_SHORT).show()
   }.showWithFeedback()
 }
 private fun listHistory(){
  showingDetails=false
  val list=frame("Histórico de lista apagada")
  val h=Store.history(this)
  if(h.length()==0){list.addView(line("Nenhuma lista apagada nas últimas 24 horas."));return}
  val snapshots=(0 until h.length()).mapNotNull{h.optJSONObject(it)}.sortedByDescending{it.optLong("deletedAt")}
  for(snapshot in snapshots){
   val at=snapshot.optLong("deletedAt");val count=snapshot.optJSONArray("items")?.length()?:0
   val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(10),dp(15),dp(10));background=box()}
   val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
   header.addView(line("Lista apagada",19f,true,0xFF172C50.toInt()),LinearLayout.LayoutParams(0,-2,1f))
   header.addView(ImageView(this).apply{
    setImageResource(R.drawable.ic_trash)
    setPadding(dp(8),dp(8),dp(8),dp(8))
    contentDescription="Apagar lista do histórico"
    setOnClickListener{askDeleteHistory(at)}
   },LinearLayout.LayoutParams(dp(40),dp(40)))
   card.addView(header)
   card.addView(line("◷  ${fmt(at,"HH:mm")}",30f,true,0xFF1766CF.toInt()))
   card.addView(line("${fmt(at,"dd/MM/yyyy")}  •  $count endereços",14f,false,0xFF5A6779.toInt()))
   card.setOnClickListener{showDetails(at)}
   list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(12)})
  }
 }
 private fun showDetails(at:Long){
  showingDetails=true
  val snapshot=(0 until Store.history(this).length()).mapNotNull{Store.history(this).optJSONObject(it)}.firstOrNull{it.optLong("deletedAt")==at}
  if(snapshot==null){listHistory();Toast.makeText(this,"Lista expirada ou indisponível",Toast.LENGTH_SHORT).show();return}
  val items=snapshot.optJSONArray("items")?:return
  val list=frame("Lista apagada")
  val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  top.addView(line("${fmt(at,"HH:mm")}   •   ${fmt(at,"dd/MM/yyyy")}",22f,true,0xFF1766CF.toInt()),LinearLayout.LayoutParams(0,-2,1f))
  top.addView(ImageView(this).apply{
   setImageResource(R.drawable.ic_trash)
   setPadding(dp(8),dp(8),dp(8),dp(8))
   contentDescription="Apagar esta lista do histórico"
   setOnClickListener{askDeleteHistory(at,true)}
  },LinearLayout.LayoutParams(dp(42),dp(42)))
  list.addView(top)
  list.addView(Button(this).apply{
   text="RESTAURAR LISTA";setTextColor(Color.WHITE)
   backgroundTintList=android.content.res.ColorStateList.valueOf(0xFF16B979.toInt())
   setOnClickListener{
    val oldCount=Store.all(this@HistoryActivity).length()
    val message=if(oldCount>0)
     "A lista atual ($oldCount endereços) será SUBSTITUÍDA pela lista escolhida. Antes disso, a lista atual será enviada ao histórico por 24 horas. Confirmar?"
    else "Restaurar estes ${items.length()} endereços como lista principal?"
    AlertDialog.Builder(this@HistoryActivity).setTitle("CONFIRMAR RESTAURAÇÃO").setMessage(message)
     .setNegativeButton("CANCELAR",null).setPositiveButton("CONFIRMAR"){_,_->
      if(Store.restore(this@HistoryActivity,at)){
       Toast.makeText(this@HistoryActivity,"Lista restaurada com sucesso",Toast.LENGTH_LONG).show();listHistory()
      }else Toast.makeText(this@HistoryActivity,"Não foi possível restaurar. Nenhuma lista foi alterada.",Toast.LENGTH_LONG).show()
     }.showWithFeedback()
   }
  },LinearLayout.LayoutParams(-1,dp(56)).apply{bottomMargin=dp(12)})
  list.addView(line("${items.length()} endereços",15f,false,0xFF5A6779.toInt()))
  for(i in 0 until items.length()){
   val item=items.optJSONObject(i)?:continue
   val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=box();setPadding(dp(10),dp(8),dp(10),dp(8))}
   card.addView(line("Pacote ${item.optInt("number",i+1)}",19f,true,0xFF172C50.toInt()))
   card.addView(line(item.optString("address"),16f))
   list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})
  }
 }
 override fun onBackPressed(){if(showingDetails)listHistory() else finish()}
}
