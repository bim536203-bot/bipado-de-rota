package br.com.leitorencomendas

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Future
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** Photon autocomplete and Geoapify capture lookup run independently of OCR. */
class MapAssistant(context:Context,private val web:WebView,private val status:TextView){
 data class Hit(val label:String,val lat:Double,val lon:Double,val score:Int=0,val exact:Boolean=false,val source:String="",val streetLine:String=label,val location:String="",val place:Boolean=false)
 private val app=context.applicationContext
 private val main=Handler(Looper.getMainLooper())
 private val executor=ThreadPoolExecutor(1,1,0L,TimeUnit.MILLISECONDS,LinkedBlockingQueue<Runnable>())
 private val generation=AtomicInteger()
 @Volatile private var connection:HttpURLConnection?=null
 private var job:Future<*>?=null
 @Volatile private var closed=false
 private var ready=false
 private var addressMissing=false
 private var pending:Hit?=null
 private var message="Procurando endereço…"
 private var lastQuery=""
 private val prefs=app.getSharedPreferences("geoapify_cache_v2",Context.MODE_PRIVATE)
 companion object {
  private data class Entry(val at:Long,val hits:List<Hit>)
  private val cache=object:LinkedHashMap<String,Entry>(160,.75f,true){override fun removeEldestEntry(eldest:MutableMap.MutableEntry<String,Entry>)=size>160}
  private var lastPhotonRequest=0L
  private const val TTL=7L*24*60*60*1000
 }
 init{
  web.setBackgroundColor(Color.rgb(241,245,249));web.settings.javaScriptEnabled=true
  web.settings.allowFileAccess=true;web.settings.allowContentAccess=false
  web.webViewClient=object:WebViewClient(){override fun onPageFinished(view:WebView?,url:String?){
   if(closed)return
   ready=true
   if(addressMissing)web.evaluateJavascript("window.setMissingAddress(true);",null)
   else pending?.let{show(it)} ?: setStatus(message)
  }}
  web.loadUrl("file:///android_asset/mapa.html")
 }
 private fun setStatus(text:String){
  if(closed)return
  message=text;status.text=text
  if(ready)web.evaluateJavascript("window.setMapStatus(${JSONObject.quote(text)});",null)
 }
 private fun show(hit:Hit){
  if(closed)return
  pending=hit
  message=if(hit.exact)"Número localizado na base • confira o ponto" else if(hit.place)"Local selecionado na base • confira o ponto" else "Localização aproximada da rua • número não confirmado"
  status.text=message
  if(ready)web.evaluateJavascript("window.placePin(${hit.lat},${hit.lon},${JSONObject.quote(hit.label)},${hit.exact},${JSONObject.quote(hit.source)});",null)
 }
 /** Display an unread parcel without searching the placeholder text or inventing a pin. */
 fun showMissingAddress(){
  if(closed)return
  generation.incrementAndGet();job?.cancel(true);connection?.disconnect();executor.purge()
  addressMissing=true;pending=null;message="";status.text=""
  if(ready)web.evaluateJavascript("window.setMissingAddress(true);",null)
 }
 private fun cached(key:String):List<Hit>? {
  synchronized(cache){cache[key]?.takeIf{System.currentTimeMillis()-it.at<TTL}?.let{return it.hits}}
  return try{
   val saved=JSONObject(prefs.getString(key,"")!!)
   val at=saved.getLong("at")
   if(System.currentTimeMillis()-at !in 0 until TTL)return null
   val a=saved.getJSONArray("hits")
   val list=(0 until a.length()).map{val h=a.getJSONObject(it);Hit(h.getString("label"),h.getDouble("lat"),h.getDouble("lon"),h.getInt("score"),h.optBoolean("exact"),h.optString("source"),h.optString("streetLine",h.getString("label")),h.optString("location"),h.optBoolean("place"))}
   synchronized(cache){cache[key]=Entry(at,list)};list
  }catch(_:Exception){null}
 }
 private fun remember(key:String,hits:List<Hit>,persist:Boolean){
  if(hits.isEmpty())return
  val at=System.currentTimeMillis();synchronized(cache){cache[key]=Entry(at,hits)}
  if(persist){
   val a=JSONArray();hits.forEach{a.put(JSONObject().put("label",it.label).put("lat",it.lat).put("lon",it.lon).put("score",it.score).put("exact",it.exact).put("source",it.source).put("streetLine",it.streetLine).put("location",it.location).put("place",it.place))}
   val editor=prefs.edit();val keys=prefs.all.keys
   if(keys.size>=150)keys.firstOrNull()?.let{editor.remove(it)}
   editor.putString(key,JSONObject().put("at",at).put("hits",a).toString()).apply()
  }
 }
 private fun fetch(text:String,q:GeoAddress.Query,suggestions:Boolean,id:Int,deadline:Long):List<Hit>{
  if(closed || id!=generation.get())return emptyList()
  if(suggestions){
   val wait=synchronized(cache){(900-(SystemClock.elapsedRealtime()-lastPhotonRequest)).coerceAtLeast(0)}
   if(wait>0)Thread.sleep(wait)
   if(closed || id!=generation.get())return emptyList()
   synchronized(cache){lastPhotonRequest=SystemClock.elapsedRealtime()}
  }
  val remaining=(deadline-SystemClock.elapsedRealtime()).toInt()
  if(remaining<300)throw java.net.SocketTimeoutException()
  val path=if(suggestions)"autocomplete" else "search"
  fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
  val url=if(suggestions)"https://photon.komoot.io/api/?q="+enc(text)+"&limit=8&countrycode=BR&lat=2.8235&lon=-60.6758"
   else "https://api.geoapify.com/v1/geocode/$path?text="+enc(text)+"&format=json&limit=5&lang=pt&filter=countrycode:br&bias=proximity:-60.6758,2.8235&apiKey="+enc(BuildConfig.GEOAPIFY_API_KEY)
  val conn=URL(url).openConnection() as HttpURLConnection
  conn.connectTimeout=minOf(2000,remaining);conn.readTimeout=minOf(4000,remaining)
  conn.setRequestProperty("User-Agent","BipadoDeRota/5.12 Android")
  connection=conn
  try{
   if(closed || id!=generation.get())return emptyList()
   val code=conn.responseCode
   if(code==401 || code==403)throw IllegalStateException("Chave Geoapify inválida ou sem permissão")
   if(code==429)throw IllegalStateException("Limite de consultas atingido. Tente mais tarde")
   if(code !in 200..299)throw java.io.IOException("Serviço de mapas indisponível")
   val body=JSONObject(conn.inputStream.bufferedReader().use{it.readText()})
   val data=if(suggestions)body.optJSONArray("features") else body.optJSONArray("results")
   if(data==null)return emptyList()
   val hits=mutableListOf<Hit>()
   for(i in 0 until data.length()){
    val item=data.getJSONObject(i)
    val p=if(suggestions)item.optJSONObject("properties") ?: continue else item
    val coordinates=if(suggestions)item.optJSONObject("geometry")?.optJSONArray("coordinates") else null
    val lat=if(suggestions)coordinates?.optDouble(1,Double.NaN) ?: Double.NaN else p.optDouble("lat",Double.NaN)
    val lon=if(suggestions)coordinates?.optDouble(0,Double.NaN) ?: Double.NaN else p.optDouble("lon",Double.NaN)
    if(suggestions && p.optString("countrycode").isNotBlank() && !p.optString("countrycode").equals("BR",true))continue
    if(!GeoAddress.inRegion(lat,lon))continue
    val street=p.optString("street").ifBlank{if(p.optString("result_type")=="street" || p.optString("type")=="street")p.optString("name") else ""}
    val name=p.optString("name")
    if(street.isBlank() && name.isBlank())continue
    val score=maxOf(GeoAddress.streetScore(street,q.street),GeoAddress.streetScore(listOf(name,p.optString("suburb"),p.optString("district"),p.optString("locality")).filter{it.isNotBlank()}.joinToString(" "),q.street))
    if(score<70)continue
    val returnedNumber=p.optString("housenumber")
    val exact=returnedNumber.isNotBlank() && (q.number.isBlank() || GeoAddress.exactNumber(q.number,returnedNumber))
    val place=name.isNotBlank() && name!=street && (p.optString("result_type") in setOf("amenity","building") || (suggestions && p.optString("type") in setOf("house","street") && p.optString("osm_key") !in setOf("place","highway")))
    // Input number can fill the suggestion, but is not proof of its map coordinate.
    val displayedNumber=if(q.number.isNotBlank())q.number else returnedNumber
    val streetLine=listOf(if(place)name else "",street,displayedNumber,p.optString("suburb").ifBlank{p.optString("district")}).filter{it.isNotBlank()&&it!="null"}.joinToString(", ")
    val location=listOf(p.optString("city").ifBlank{"Boa Vista"},p.optString("state_code").ifBlank{if(p.optString("state")=="Roraima")"RR" else p.optString("state").ifBlank{"RR"}},p.optString("postcode")).filter{it.isNotBlank()&&it!="null"}.joinToString(", ")
    val label=listOf(streetLine,location).filter{it.isNotBlank()}.joinToString(" — ")
    val source=if(suggestions)"OpenStreetMap / Photon" else p.optJSONObject("datasource")?.optString("attribution").orEmpty()
    hits.add(Hit(label,lat,lon,score,exact,source,streetLine,location,place && q.number.isBlank()))
   }
   return hits.sortedWith(compareByDescending<Hit>{it.exact}.thenByDescending{it.score}).distinctBy{it.label}.take(5)
  }finally{if(connection===conn)connection=null;conn.disconnect()}
 }
 fun lookup(text:String,provideSuggestions:Boolean=false,onResults:((List<Hit>)->Unit)?=null){
  if(closed)return
  addressMissing=false
  if(ready)web.evaluateJavascript("window.setMissingAddress(false);",null)
  val id=generation.incrementAndGet();job?.cancel(true);connection?.disconnect();executor.purge()
  val q=GeoAddress.query(text);lastQuery=q.full
  val key=(if(provideSuggestions)"suggest:" else "address:")+AddressIdentity.normalize(q.full)
  pending=null
  if(ready)web.evaluateJavascript("window.clearPin();",null)
  if(q.street.length<(if(provideSuggestions)2 else 3)){setStatus("Digite o nome da rua para localizar");onResults?.invoke(emptyList());return}
  cached(key)?.let{hits->if(!provideSuggestions)show(hits.first()) else setStatus("Selecione uma sugestão");onResults?.invoke(hits);return}
  if(!provideSuggestions && BuildConfig.GEOAPIFY_API_KEY.isBlank()){setStatus("Serviço de mapas não configurado");onResults?.invoke(emptyList());return}
  setStatus(if(provideSuggestions)"Buscando sugestões…" else "Procurando endereço…")
  job=executor.submit{
   val started=SystemClock.elapsedRealtime();val deadline=started+6000
   var error:String?=null
   val hits=try{
    // One focused request; selecting a suggestion reuses its coordinates.
    val query=listOf(q.street,q.number,q.district,"Boa Vista","RR").filter{it.isNotBlank()}.joinToString(", ")
    fetch(query,q,provideSuggestions,id,deadline)
   }catch(_:java.net.SocketTimeoutException){error="Busca demorou. Confira a internet e tente novamente";emptyList()}
    catch(e:IllegalStateException){error=e.message;emptyList()}
    catch(_:Exception){error="Sem conexão com o serviço de mapas. Confira a internet";emptyList()}
   if(!closed && id==generation.get())remember(key,hits,!provideSuggestions)
   main.post{
    if(closed || id!=generation.get())return@post
    android.util.Log.d("BipadoMapa","Mapa ${SystemClock.elapsedRealtime()-started}ms results=${hits.size}")
    if(hits.isNotEmpty()){if(!provideSuggestions)show(hits.first()) else setStatus("Selecione uma sugestão para localizar no mapa")}
    else setStatus(error ?: "Endereço ou local não encontrado. Confira a busca")
    onResults?.invoke(hits)
   }
  }
 }
 fun cancelLookup(){generation.incrementAndGet();job?.cancel(true);connection?.disconnect();executor.purge();pending=null;if(ready)web.evaluateJavascript("window.clearPin();",null)}
 fun choose(hit:Hit){addressMissing=false;if(ready)web.evaluateJavascript("window.setMissingAddress(false);",null);generation.incrementAndGet();job?.cancel(true);connection?.disconnect();remember("address:"+AddressIdentity.normalize(lastQuery),listOf(hit),true);remember("address:"+AddressIdentity.normalize(GeoAddress.query("${hit.streetLine}, ${hit.location}").full),listOf(hit),true);show(hit)}
 fun release(){if(closed)return;closed=true;generation.incrementAndGet();job?.cancel(true);connection?.disconnect();executor.shutdownNow();main.removeCallbacksAndMessages(null);web.stopLoading();web.destroy()}
}
