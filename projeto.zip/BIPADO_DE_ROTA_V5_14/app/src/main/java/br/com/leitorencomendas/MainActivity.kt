package br.com.leitorencomendas

import android.app.*
import android.content.*
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.*
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.time.LocalDate
import java.time.DayOfWeek

class MainActivity : Activity() {
 private val projectionRequest = 44
 private lateinit var summary: TextView
 private var pendingCsv: String? = null
 private lateinit var toggleBar: LinearLayout
 private lateinit var toggleImage: ImageView
 private var reading = false
 private val toggleHandler=Handler(Looper.getMainLooper())
 private val syncToggle=object:Runnable {override fun run(){reading=CaptureService.active;refreshToggle();toggleHandler.postDelayed(this,500)}}
 override fun onSaveInstanceState(outState:Bundle){outState.putString("pendingCsv",pendingCsv);super.onSaveInstanceState(outState)}
 override fun onPause(){toggleHandler.removeCallbacks(syncToggle);super.onPause()}
 private val statusReceiver = object: BroadcastReceiver() {
  override fun onReceive(context: Context?, intent: Intent?) { reading = false; if (::toggleBar.isInitialized) refreshToggle() }
 }
 private fun rounded(color: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(color, color)).apply {cornerRadius = (18 * resources.displayMetrics.density)}
 private fun dp(n:Int)=(n*resources.displayMetrics.density+.5f).toInt()
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  pendingCsv=savedInstanceState?.getString("pendingCsv")
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),46)
  val display=android.util.DisplayMetrics();windowManager.defaultDisplay.getMetrics(display)
  val page=FrameLayout(this).apply {setBackgroundColor(Color.WHITE)}
  val root=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(24),dp(56),dp(24),dp(22));setBackgroundColor(Color.WHITE)}
  val menu=ImageView(this).apply {
   setImageResource(R.drawable.ic_more);setPadding(dp(10),dp(10),dp(10),dp(10))
   contentDescription="Abrir menu";setOnClickListener { showSideMenu() }
  }
  page.addView(root,FrameLayout.LayoutParams(-1,-1))
  page.addView(menu,FrameLayout.LayoutParams(dp(52),dp(52),Gravity.END or Gravity.TOP).apply{topMargin=dp(10);marginEnd=dp(18)})
  val title=TextView(this).apply {text="BIPADO DE ROTA";textSize=27f;setTextColor(0xFF0A2B62.toInt());gravity=Gravity.CENTER;setTypeface(null, Typeface.BOLD)}
  root.addView(title,LinearLayout.LayoutParams(-1,-2).apply {bottomMargin=dp(48)})
  fun actionButton(label:String, icon:Int, color:Int, action:()->Unit):Pair<LinearLayout,ImageView> {
   val bar=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER; background=rounded(color); elevation=dp(5).toFloat();isClickable=true;isFocusable=true;setOnClickListener{action()}}
   val image=ImageView(this).apply {setImageResource(icon);contentDescription=null}
   bar.addView(image,LinearLayout.LayoutParams(dp(26),dp(26)).apply{marginEnd=dp(12)})
   bar.addView(TextView(this).apply {text=label;textSize=17f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE);gravity=Gravity.CENTER_VERTICAL})
   root.addView(bar,LinearLayout.LayoutParams(-1,dp(76)).apply {bottomMargin=dp(18)})
   return bar to image
  }
  summary=TextView(this).apply {visibility=View.GONE};root.addView(summary)
  val start=actionButton("INICIAR BIPE",R.drawable.ic_scan,0xFF19B874.toInt()) {
   if(reading){stopService(Intent(this,CaptureService::class.java));reading=false;refreshToggle()} else startCapture()
  }
  toggleBar=start.first;toggleImage=start.second
  actionButton("VER ENDEREÇOS SALVOS",R.drawable.ic_saved,0xFF1975EA.toInt()){startActivity(Intent(this,SavedAddressesActivity::class.java))}
  actionButton("BAIXAR ROTAS",R.drawable.ic_download,0xFFFF821E.toInt()){exportCsv()}
  root.addView(TextView(this).apply {text="Criado por Fábio Silva (95)99115-5595";textSize=13f;gravity=Gravity.CENTER;setTextColor(0xFF687589.toInt());setPadding(0,dp(32),0,0)})
  val appVersion=BuildConfig.VERSION_NAME.removeSuffix(".0")
  val versionLabel=TextView(this).apply {
   text="V$appVersion";textSize=12f;setTextColor(0xFF718198.toInt());gravity=Gravity.END or Gravity.CENTER_VERTICAL
   setPadding(dp(8),dp(4),dp(3),dp(4))
  }
  page.addView(versionLabel,FrameLayout.LayoutParams(-2,-2,Gravity.END or Gravity.BOTTOM).apply{marginEnd=dp(21);bottomMargin=dp(12)})
  setContentView(page)
  androidx.core.content.ContextCompat.registerReceiver(this,statusReceiver,IntentFilter("br.com.leitorencomendas.STOPPED"),androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED)
  reading=CaptureService.active
  refreshToggle();updateCount()
 }
 override fun onDestroy(){unregisterReceiver(statusReceiver);super.onDestroy()}
 override fun onResume(){super.onResume();toggleHandler.postDelayed(syncToggle,500);reading=CaptureService.active;if(::toggleBar.isInitialized)refreshToggle();if(::summary.isInitialized)updateCount()}
 private fun showSideMenu(){
  val drawer=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(18),dp(16),dp(18));setBackgroundColor(Color.WHITE) }
  drawer.addView(TextView(this).apply {text="Menu";textSize=23f;setTypeface(null,Typeface.BOLD);setTextColor(0xFF0A2B62.toInt());setPadding(dp(4),0,0,dp(22))})
  val choice=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=rounded(0xFFF2F5FA.toInt());setPadding(dp(14),dp(18),dp(14),dp(18))}
  choice.addView(TextView(this).apply {text="◷   Histórico de lista apagada    ›";textSize=17f;setTextColor(0xFF18375B.toInt())})
  drawer.addView(choice)
  val dialog=Dialog(this)
  dialog.setContentView(drawer)
  dialog.window?.apply {setBackgroundDrawableResource(android.R.color.transparent);setDimAmount(.48f);addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);setGravity(Gravity.END or Gravity.TOP);setLayout((resources.displayMetrics.widthPixels*.84f).toInt(),WindowManager.LayoutParams.MATCH_PARENT)}
  choice.setOnClickListener {dialog.dismiss();startActivity(Intent(this,HistoryActivity::class.java))}
  dialog.show()
  dialog.window?.setLayout((resources.displayMetrics.widthPixels*.84f).toInt(),WindowManager.LayoutParams.MATCH_PARENT)
 }
 private fun refreshToggle(){
  toggleBar.background=rounded(if(reading)0xFFE1272B.toInt() else 0xFF19B874.toInt())
  toggleImage.setImageResource(if(reading)R.drawable.ic_stop else R.drawable.ic_scan)
  (toggleBar.getChildAt(1) as TextView).text=if(reading)"PARA LEITURA BIPE" else "INICIAR BIPE"
 }
 private fun updateCount(){summary.text="Endereços salvos: ${Store.all(this).length()}"}
 private fun startCapture() {
  if (!Settings.canDrawOverlays(this)) {
   startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
   Toast.makeText(this,"Permita exibir sobre outros apps e volte para iniciar",Toast.LENGTH_LONG).show(); return
  }
  val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  val consent=if(Build.VERSION.SDK_INT>=34)mgr.createScreenCaptureIntent(android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()) else mgr.createScreenCaptureIntent()
  startActivityForResult(consent, projectionRequest)
 }
 @Deprecated("Legacy result API") override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
  super.onActivityResult(requestCode, resultCode, data)
  if (requestCode == 45 && resultCode == RESULT_OK && data?.data != null) {
   contentResolver.openOutputStream(data.data!!)?.use { it.write(("\uFEFF" + (pendingCsv ?: "")).toByteArray(Charsets.UTF_8)) }
   Toast.makeText(this,"CSV exportado",Toast.LENGTH_SHORT).show()
  }
  if (requestCode == projectionRequest && resultCode == RESULT_OK && data != null) {
   val i = Intent(this,CaptureService::class.java).putExtra("resultCode",resultCode).putExtra("resultData",data)
   if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
   reading = true; refreshToggle()
   Toast.makeText(this,"Abra a J&T e toque no botão flutuante",Toast.LENGTH_LONG).show()
  }
 }
 private fun csvCell(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""
 private fun routeFileName():String = when(LocalDate.now().dayOfWeek){
  DayOfWeek.MONDAY->"ROTA DE SEGUNDA.csv"
  DayOfWeek.TUESDAY->"ROTA DE TERÇA.csv"
  DayOfWeek.WEDNESDAY->"ROTA DE QUARTA.csv"
  DayOfWeek.THURSDAY->"ROTA DE QUINTA.csv"
  DayOfWeek.FRIDAY->"ROTA DE SEXTA.csv"
  DayOfWeek.SATURDAY->"ROTA DE SÁBADO.csv"
  DayOfWeek.SUNDAY->"ROTA DO DOMINGO.csv"
 }
 private fun exportCsv() {
  val a = Store.all(this)
  if (a.length() == 0) { Toast.makeText(this,"Nenhum endereço salvo",Toast.LENGTH_SHORT).show(); return }
  // Address and Notes are deliberately separate; the number belongs ONLY in Notes.
  val csv = StringBuilder("Address,Notes\r\n")
  for (i in 0 until a.length()) {
   val item = a.getJSONObject(i)
   csv.append(csvCell(item.optString("address"))).append(",")
    .append(csvCell("PACOTE ${item.optInt("number",i + 1)}")).append("\r\n")
  }
  pendingCsv = csv.toString()
  startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
   .setType("text/csv").putExtra(Intent.EXTRA_TITLE,routeFileName()),45)
 }
}
