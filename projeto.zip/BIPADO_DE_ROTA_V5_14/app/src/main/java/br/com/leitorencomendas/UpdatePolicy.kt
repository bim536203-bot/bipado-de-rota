package br.com.leitorencomendas

/** Background checks allow access unless a newer required version is already confirmed. */
object UpdatePolicy {
 enum class Decision { ALLOW, UPDATE, RETRY }
 fun decide(installed:Long, advertised:Long?, checkSucceeded:Boolean,knownRequired:Long=0):Decision = when {
  knownRequired>installed -> Decision.UPDATE
  !checkSucceeded || advertised==null || advertised<=0 -> Decision.ALLOW
  advertised>installed -> Decision.UPDATE
  else -> Decision.ALLOW
 }
 fun validHash(value:String)=value.matches(Regex("[a-fA-F0-9]{64}"))
 fun validRepository(value:String)=value.matches(Regex("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"))
 fun validApkUrl(url:String,repo:String)=validRepository(repo) && url.startsWith("https://github.com/$repo/releases/download/") && url.endsWith(".apk") && !url.contains("?") && !url.contains("#")
}
