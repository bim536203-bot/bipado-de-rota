package br.com.leitorencomendas

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

object Updater {
 data class Release(val code:Long,val name:String,val url:String,val hash:String,val size:Long,val minSdk:Int) {
  fun json()=JSONObject().put("versionCode",code).put("versionName",name).put("apkUrl",url).put("sha256",hash).put("size",size).put("minSdk",minSdk).put("applicationId","br.com.leitorencomendas").put("schema",1)
 }
 @Volatile private var verifiedAt=0L
 private fun prefs(c:Context)=c.getSharedPreferences("mandatory_update_v1",Context.MODE_PRIVATE)
 @Suppress("DEPRECATION") fun installed(c:Context)=code(c.packageManager.getPackageInfo(c.packageName,0))
 @Suppress("DEPRECATION") private fun code(info:android.content.pm.PackageInfo)=if(android.os.Build.VERSION.SDK_INT>=28)info.longVersionCode else info.versionCode.toLong()
 fun hasInternet(c:Context):Boolean {
  val cm=c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
  val caps=cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
  return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
 }
 fun pending(c:Context):Release?=try {parse(JSONObject(prefs(c).getString("pending","")!!)).takeIf{it.code>installed(c)}}catch(_:Exception){null}
 fun allowed(c:Context)=pending(c)==null
 fun checkDue()=verifiedAt==0L || SystemClock.elapsedRealtime()-verifiedAt>60000
 fun openGate(c:Context) { c.startActivity(Intent(c,UpdateActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP));c.stopService(Intent(c,CaptureService::class.java)) }
 fun parse(o:JSONObject):Release {
  require(o.getInt("schema")==1 && o.getString("applicationId")=="br.com.leitorencomendas")
  val r=Release(o.getLong("versionCode"),o.getString("versionName"),o.getString("apkUrl"),o.getString("sha256").lowercase(),o.getLong("size"),o.getInt("minSdk"))
  require(r.code>0 && r.name.length in 1..80 && r.size in 1..100_000_000 && r.minSdk in 26..100 && UpdatePolicy.validHash(r.hash) && UpdatePolicy.validApkUrl(r.url,BuildConfig.UPDATE_REPOSITORY))
  return r
 }
 private fun connection(url:String)= (URL(url).openConnection() as HttpURLConnection).apply {connectTimeout=7000;readTimeout=10000;setRequestProperty("User-Agent","BipadoDeRota-Updater");useCaches=false}
 /** Caller executes on a worker, never the UI thread. */
 fun check(c:Context):Release? {
  check(hasInternet(c)){"Conecte-se à internet para verificar a atualização."}
  val conn=connection("https://github.com/${BuildConfig.UPDATE_REPOSITORY}/releases/latest/download/update.json")
  val release=try {
   check(conn.responseCode==200){"Não foi possível verificar a versão. Tente novamente."}
   val bytes=conn.inputStream.use { input->val out=java.io.ByteArrayOutputStream();val b=ByteArray(4096);while(true){val n=input.read(b);if(n<0)break;check(out.size()+n<=16384);out.write(b,0,n)};out.toByteArray() }
   parse(JSONObject(String(bytes,Charsets.UTF_8)))
  }finally{conn.disconnect()}
  val known=pending(c)
  val selected=if(known!=null && known.code>release.code)known else release
  if(UpdatePolicy.decide(installed(c),release.code,true,known?.code ?: 0)==UpdatePolicy.Decision.UPDATE){
   prefs(c).edit().putString("pending",selected.json().toString()).commit()
   return selected
  }
  prefs(c).edit().remove("pending").commit();verifiedAt=SystemClock.elapsedRealtime();return null
 }
 fun file(c:Context)=File(c.cacheDir,"updates/BIPADO_DE_ROTA.apk")
 @Suppress("DEPRECATION") fun verify(c:Context,f:File,r:Release) {
  require(f.length()==r.size){"O download está incompleto."}
  val hash=f.inputStream().use { input->val md=MessageDigest.getInstance("SHA-256");val buf=ByteArray(65536);while(true){val n=input.read(buf);if(n<0)break;md.update(buf,0,n)};md.digest().joinToString(""){"%02x".format(it)}}
  require(hash==r.hash){"O arquivo não passou na verificação. Baixe novamente."}
  val pm=c.packageManager
  val flags=if(android.os.Build.VERSION.SDK_INT>=28)PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
  val candidate=pm.getPackageArchiveInfo(f.absolutePath,flags) ?: error("APK inválido.")
  val current=pm.getPackageInfo(c.packageName,flags)
  require(candidate.packageName==c.packageName && code(candidate)==r.code && code(candidate)>installed(c)){"Versão ou aplicativo incompatível."}
  val old=(if(android.os.Build.VERSION.SDK_INT>=28)current.signingInfo?.apkContentsSigners else current.signatures)?.map{it.toCharsString()}?.toSet()
  val fresh=(if(android.os.Build.VERSION.SDK_INT>=28)candidate.signingInfo?.apkContentsSigners else candidate.signatures)?.map{it.toCharsString()}?.toSet()
  require(!old.isNullOrEmpty() && old==fresh){"A assinatura do APK não corresponde ao aplicativo instalado."}
  require(candidate.applicationInfo?.minSdkVersion?.let{it<=android.os.Build.VERSION.SDK_INT}==true){"Esta atualização não é compatível com seu Android."}
 }
 fun download(c:Context,r:Release,progress:(Int)->Unit):File {
  require(r.minSdk<=android.os.Build.VERSION.SDK_INT){"Atualização incompatível com seu Android."}
  val dest=file(c);dest.parentFile!!.mkdirs()
  if(dest.exists())try{verify(c,dest,r);return dest}catch(_:Exception){dest.delete()}
  val part=File(dest.parentFile,"download.part");val conn=connection(r.url)
  try {
   check(conn.responseCode==200){"Não foi possível baixar. Confira a internet e tente novamente."}
   var total=0L;var percent=-1
   conn.inputStream.use{input->part.outputStream().use{output->val buf=ByteArray(65536);while(true){
    check(!Thread.currentThread().isInterrupted){"Download interrompido."}
    val n=input.read(buf);if(n<0)break;total+=n;require(total<=r.size){"Tamanho inválido."};output.write(buf,0,n)
    val next=(total*100/r.size).toInt();if(next!=percent){percent=next;progress(next)}
   }}}
   verify(c,part,r);require(part.renameTo(dest)){"Não foi possível guardar o APK."};return dest
  }finally{conn.disconnect();part.delete()}
 }
}
