import br.com.leitorencomendas.UpdatePolicy as P
fun main(){
 var n=0
 fun test(value:Boolean){check(value);n++}
 test(P.decide(65,66,true)==P.Decision.UPDATE)
 test(P.decide(65,65,true)==P.Decision.ALLOW)
 test(P.decide(66,65,true)==P.Decision.ALLOW)
 test(P.decide(65,null,false)==P.Decision.RETRY)
 test(P.decide(65,66,false)==P.Decision.RETRY)
 test(P.decide(65,null,true)==P.Decision.RETRY)
 test(P.decide(65,0,true)==P.Decision.RETRY)
 test(P.decide(65,65,true,66)==P.Decision.UPDATE)
 test(P.decide(65,null,false,66)==P.Decision.UPDATE)
 test(P.decide(66,66,true,66)==P.Decision.ALLOW)
 test(P.validHash("a".repeat(64)))
 test(!P.validHash("a".repeat(63)))
 test(!P.validHash("z".repeat(64)))
 test(P.validRepository("bim536203-bot/bipado-de-rota"))
 test(!P.validRepository("../repo/extra"))
 test(P.validApkUrl("https://github.com/a/b/releases/download/v1/app.apk","a/b"))
 test(!P.validApkUrl("http://github.com/a/b/releases/download/v1/app.apk","a/b"))
 test(!P.validApkUrl("https://github.com/a/evil/releases/download/v1/app.apk","a/b"))
 test(!P.validApkUrl("https://github.com/a/b/releases/download/v1/app.apk?x=1","a/b"))
 test(!P.validApkUrl("https://evil.com/a/b/releases/download/v1/app.apk","a/b"))
 test(!P.validApkUrl("https://github.com/a/b/releases/download/v1/app.zip","a/b"))
 println("$n mandatory update policy cases passed")
}
