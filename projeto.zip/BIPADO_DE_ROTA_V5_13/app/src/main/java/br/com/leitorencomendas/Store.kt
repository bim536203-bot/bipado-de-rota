package br.com.leitorencomendas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Todas as alterações de lista/histórico são gravadas em uma única transação de preferências. */
object Store {
 const val RETENTION_MS = 24L * 60L * 60L * 1000L
 private fun prefs(c:Context) = c.getSharedPreferences("deliveries",0)
 private fun initial(c:Context):JSONObject {
  val legacy=prefs(c).getString("items","[]") ?: "[]"
  return JSONObject().put("items",try{JSONArray(legacy)}catch(_:Exception){JSONArray()}).put("history",JSONArray())
 }
 @Synchronized private fun state(c:Context):JSONObject {
  val s=try{JSONObject(prefs(c).getString("state", "")!!)}catch(_:Exception){initial(c)}
  val h=s.optJSONArray("history") ?: JSONArray()
  val now=System.currentTimeMillis()
  val current=JSONArray()
  for(i in 0 until h.length()) {
   val item=h.optJSONObject(i) ?: continue
   val at=item.optLong("deletedAt",0)
   if(at>0 && at<=now && now-at<RETENTION_MS)current.put(item)
  }
  if(current.length()!=h.length()) {s.put("history",current);save(c,s)}
  return s
 }
 private fun save(c:Context,s:JSONObject):Boolean = prefs(c).edit().putString("state",s.toString()).commit()
 @Synchronized fun all(c:Context):JSONArray=JSONArray(state(c).optJSONArray("items")!!.toString())
 @Synchronized fun history(c:Context):JSONArray=JSONArray(state(c).optJSONArray("history")!!.toString())
 fun normalize(address:String)=AddressIdentity.normalize(address)
 fun matchingIndex(items:JSONArray,address:String,except:Int=-1):Int {
  val key=normalize(address)
  if(key.isBlank())return -1
  for(i in 0 until items.length())if(i!=except && AddressIdentity.same(items.optJSONObject(i)?.optString("address") ?: "",address))return i
  return -1
 }
 @Synchronized fun matching(c:Context,address:String):JSONObject? {
  val list=all(c);val index=matchingIndex(list,address)
  return if(index>=0)list.getJSONObject(index) else null
 }
 @Synchronized fun nextNumber(c:Context):Int {
  val a=all(c);val used=mutableSetOf<Int>()
  for(i in 0 until a.length())used.add(a.getJSONObject(i).optInt("number",i+1))
  var n=1;while(n in used)n++;return n
 }
 @Synchronized fun add(c:Context,address:String,number:Int):Boolean {
  val s=state(c);val a=s.optJSONArray("items")!!
  if(number<1 || address.isBlank() || matchingIndex(a,address)>=0)return false
  for(i in 0 until a.length())if(a.getJSONObject(i).optInt("number",i+1)==number)return false
  a.put(JSONObject().put("address",address.trim()).put("number",number).put("createdAt",System.currentTimeMillis()))
  return save(c,s)
 }
 /** Apagar tudo sempre faz snapshot antes de limpar. Exclusões individuais não entram no histórico. */
 @Synchronized fun clear(c:Context):Boolean {
  val s=state(c);val old=s.optJSONArray("items")!!
  if(old.length()==0)return true
  val h=s.optJSONArray("history")!!
  h.put(JSONObject().put("deletedAt",System.currentTimeMillis()).put("items",JSONArray(old.toString())))
  s.put("items",JSONArray());return save(c,s)
 }
 @Synchronized fun restore(c:Context,deletedAt:Long):Boolean {
  val s=state(c);val h=s.optJSONArray("history")!!
  val selected=(0 until h.length()).mapNotNull{h.optJSONObject(it)}.firstOrNull{it.optLong("deletedAt")==deletedAt} ?: return false
  val restoring=selected.optJSONArray("items") ?: return false
  if(restoring.length()==0)return false
  val old=s.optJSONArray("items")!!
  if(old.length()>0)h.put(JSONObject().put("deletedAt",System.currentTimeMillis()).put("items",JSONArray(old.toString())))
  s.put("items",JSONArray(restoring.toString()))
  return save(c,s)
 }
 @Synchronized fun deleteHistory(c:Context,deletedAt:Long):Boolean {
  val s=state(c);val h=s.optJSONArray("history")!!
  val newer=JSONArray()
  var removed=false
  for(i in 0 until h.length()) {
   val item=h.optJSONObject(i) ?: continue
   if(item.optLong("deletedAt") == deletedAt) removed=true else newer.put(item)
  }
  if(!removed)return false
  s.put("history",newer)
  return save(c,s)
 }

 @Synchronized fun remove(c:Context,index:Int):Boolean {
  val s=state(c);val a=s.optJSONArray("items")!!
  if(index !in 0 until a.length())return false
  val newer=JSONArray();for(i in 0 until a.length())if(i!=index)newer.put(a.getJSONObject(i))
  s.put("items",newer);return save(c,s)
 }
 @Synchronized fun edit(c:Context,index:Int,number:Int,address:String):Boolean {
  val s=state(c);val a=s.optJSONArray("items")!!
  if(index !in 0 until a.length()||number<1||address.isBlank()||matchingIndex(a,address,index)>=0)return false
  for(i in 0 until a.length())if(i!=index&&a.getJSONObject(i).optInt("number",i+1)==number)return false
  a.getJSONObject(index).put("number",number).put("address",address.trim())
  return save(c,s)
 }
}
