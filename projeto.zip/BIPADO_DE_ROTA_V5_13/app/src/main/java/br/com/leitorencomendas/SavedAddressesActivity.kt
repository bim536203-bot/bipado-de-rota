package br.com.leitorencomendas

import android.app.*
import android.os.Bundle
import android.text.InputType
import android.view.*
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

class SavedAddressesActivity : Activity() {
 private lateinit var list: LinearLayout
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,20,20,15) }
  val back = Button(this).apply { text = "← VOLTAR"; setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(0xFF216BE0.toInt());setOnClickListener { finish() } }
  // Barra horizontal: lixeira independente e visível, sem sobrepor um Button.
  val header = LinearLayout(this).apply {
   orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
   background=android.graphics.drawable.GradientDrawable().apply {setColor(0xFF216BE0.toInt());cornerRadius=dp(5).toFloat()}
  }
  header.addView(back, LinearLayout.LayoutParams(0,dp(58),1f))
  header.addView(ImageView(this).apply {
   setImageResource(R.drawable.ic_trash_white)
   setPadding(dp(13),dp(13),dp(13),dp(13))
   scaleType=ImageView.ScaleType.FIT_CENTER
   contentDescription="Apagar todos os endereços"
   setOnClickListener {
    AlertDialog.Builder(this@SavedAddressesActivity).setTitle("Apagar todos os endereços?")
     .setMessage("A lista será guardada por 24 horas em Histórico de lista apagada, para consulta e restauração.")
     .setNegativeButton("CANCELAR",null)
     .setPositiveButton("CONFIRMAR") { _,_ -> Store.clear(this@SavedAddressesActivity); render() }.show()
   }
  },LinearLayout.LayoutParams(dp(60),dp(58)))
  root.addView(header)
  root.addView(TextView(this).apply { text = "Endereços salvos"; textSize = 25f; setPadding(8,8,8,15) })
  list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
  root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1,0,1f))
  setContentView(root)
 }
 override fun onResume() { super.onResume(); render() }
 private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
 private fun render() {
  list.removeAllViews()
  val items = Store.all(this)
  if (items.length() == 0) { list.addView(TextView(this).apply { text = "Nenhum endereço salvo"; textSize = 18f }); return }
  for (i in (items.length()-1) downTo 0) {
   val item = items.getJSONObject(i)
   val n = item.optInt("number",i + 1)
   val address = item.optString("address")
   val card = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(12))
    background = android.graphics.drawable.GradientDrawable().apply {
     setColor(0xFFF2F5FA.toInt()); cornerRadius = dp(14).toFloat()
     setStroke(dp(1),0xFFD8DFE9.toInt())
    }
   }
   val topRow=FrameLayout(this)
   topRow.addView(TextView(this).apply { text = "Pacote $n"; textSize = 20f; setTextColor(0xFF162C4C.toInt()) },FrameLayout.LayoutParams(-1,-2))
   topRow.addView(ImageView(this).apply {setImageResource(R.drawable.ic_trash);setPadding(dp(10),dp(5),dp(10),dp(5));contentDescription="Excluir pacote $n";setOnClickListener {
    AlertDialog.Builder(this@SavedAddressesActivity).setTitle("Excluir Pacote $n?")
     .setMessage("Somente este endereço será apagado. Deseja continuar?")
     .setNegativeButton("CANCELAR",null).setPositiveButton("CONFIRMAR") {_,_->Store.remove(this@SavedAddressesActivity,i);render()}.show()
   }}, FrameLayout.LayoutParams(dp(48),dp(40),Gravity.END or Gravity.TOP))
   card.addView(topRow)
   card.addView(TextView(this).apply { text = address; textSize = 17f; setTextColor(0xFF333333.toInt()); setPadding(0,dp(10),0,dp(8)) })
   card.addView(Button(this).apply { text = "EDITAR"; setOnClickListener { editItem(i,n,address) } })
   list.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = dp(12) })
  }
 }
 private fun editItem(index: Int, number: Int, address: String) {
  val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),dp(10),dp(20),0) }
  val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
  row.addView(TextView(this).apply { text = "Pacote  "; textSize = 18f })
  val numberInput = EditText(this).apply { setText(number.toString()); inputType = InputType.TYPE_CLASS_NUMBER; selectAll() }
  row.addView(numberInput,LinearLayout.LayoutParams(0,-2,1f)); panel.addView(row)
  panel.addView(TextView(this).apply { text = "Endereço"; textSize = 16f })
  val addressInput = EditText(this).apply { setText(address); minLines = 2; maxLines = 5; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
  panel.addView(addressInput)
  val dialog = AlertDialog.Builder(this).setTitle("Editar encomenda").setView(panel)
   .setNegativeButton("CANCELAR",null).setPositiveButton("SALVAR",null).create()
  dialog.setOnShowListener {
   dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
    val newNumber = numberInput.text.toString().toIntOrNull()
    val newAddress = addressInput.text.toString().trim()
    if (newNumber == null || newNumber < 1 || newAddress.length < 5) {
     Toast.makeText(this,"Informe número válido e endereço completo",Toast.LENGTH_LONG).show(); return@setOnClickListener
    }
    if (!Store.edit(this,index,newNumber,newAddress)) {
     Toast.makeText(this,"Número ou endereço já usado por outro pacote",Toast.LENGTH_LONG).show(); return@setOnClickListener
    }
    dialog.dismiss(); render()
   }
  }
  dialog.show()
 }
}
