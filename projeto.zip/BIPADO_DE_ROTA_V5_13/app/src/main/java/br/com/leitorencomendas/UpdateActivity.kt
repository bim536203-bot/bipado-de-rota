package br.com.leitorencomendas

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.core.content.FileProvider
import java.util.concurrent.Executors

/** Mandatory gate: no dismiss/cancel that can open the app. Android still confirms installation. */
class UpdateActivity:Activity() {
 private lateinit var title:TextView
 private lateinit var detail:TextView
 private lateinit var button:Button
 private lateinit var progress:ProgressBar
 private val worker=Executors.newSingleThreadExecutor()
 private var release:Updater.Release?=null
 private var waitingPermission=false
 private var busy=false
 private var destroyed=false
 override fun onCreate(state:Bundle?) {
  super.onCreate(state)
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(32,48,32,48);setBackgroundColor(Color.WHITE)}
  title=TextView(this).apply{textSize=27f;gravity=Gravity.CENTER;setTextColor(0xFF0A2B62.toInt())}
  detail=TextView(this).apply{textSize=18f;gravity=Gravity.CENTER;setPadding(0,28,0,28)}
  progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;visibility=android.view.View.GONE}
  button=Button(this).apply{text="TENTAR NOVAMENTE";setOnClickListener{if(release!=null)download() else checkVersion()}}
  box.addView(title);box.addView(detail);box.addView(progress,LinearLayout.LayoutParams(-1,24));box.addView(button,LinearLayout.LayoutParams(-1,-2));setContentView(box)
  release=Updater.pending(this);checkVersion()
 }
 private fun ui(action:()->Unit){runOnUiThread{if(!destroyed)action()}}
 private fun showPending(){
  title.text="Atualização disponível";detail.text="Instale a versão ${release!!.name} para continuar usando o BIPADO DE ROTA.";button.text="ATUALIZAR";button.isEnabled=true
 }
 private fun checkVersion(){
  if(busy)return;busy=true;title.text="Verificando atualização";detail.text="Aguarde a verificação pela internet.";button.isEnabled=false
  worker.execute{
   try {
    val found=Updater.check(this)
    ui{busy=false;release=found;if(found==null){startActivity(Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));finish()}else showPending()}
   }catch(e:Exception){ui{busy=false;release=Updater.pending(this);title.text=if(release!=null)"Atualização disponível" else "Verificação necessária";detail.text=(e.message ?: "Não foi possível verificar a versão.")+"\nO uso será liberado após confirmar a versão atualizada.";button.text=if(release!=null)"ATUALIZAR" else "TENTAR NOVAMENTE";button.isEnabled=true}}
  }
 }
 private fun download(){
  val r=release ?: return;if(busy)return;busy=true;button.isEnabled=false;progress.visibility=android.view.View.VISIBLE;detail.text="Baixando atualização…"
  worker.execute{
   try {val f=Updater.download(this,r){value->ui{progress.progress=value}};ui{busy=false;progress.visibility=android.view.View.GONE;button.isEnabled=true;detail.text="APK verificado. Confirme a instalação no Android.";install(f)}}
   catch(e:Exception){ui{busy=false;progress.visibility=android.view.View.GONE;button.isEnabled=true;detail.text=e.message ?: "Falha no download. Tente novamente."}}
  }
 }
 private fun install(file:java.io.File){
  if(!packageManager.canRequestPackageInstalls()){
   waitingPermission=true;detail.text="Permita instalar atualizações deste aplicativo e volte para continuar."
   startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:$packageName")));return
  }
  try{
   val uri=FileProvider.getUriForFile(this,"$packageName.updates",file)
   startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
  }catch(_:Exception){detail.text="Não foi possível abrir o instalador. Toque em ATUALIZAR para tentar novamente."}
 }
 override fun onResume(){super.onResume();if(waitingPermission){waitingPermission=false;if(packageManager.canRequestPackageInstalls())install(Updater.file(this))}}
 @Deprecated("Mandatory update gate") override fun onBackPressed(){moveTaskToBack(true)}
 override fun onDestroy(){destroyed=true;worker.shutdownNow();super.onDestroy()}
}
