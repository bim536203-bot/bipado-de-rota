package br.com.leitorencomendas
import android.app.Activity
import android.app.Application
import android.os.Bundle

class BipadoApplication:Application(),Application.ActivityLifecycleCallbacks {
 private var foreground:java.lang.ref.WeakReference<Activity>?=null
 private val main=android.os.Handler(android.os.Looper.getMainLooper())
 override fun onCreate(){
  super.onCreate();registerActivityLifecycleCallbacks(this)
  val cm=getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
  cm.registerDefaultNetworkCallback(object:android.net.ConnectivityManager.NetworkCallback(){
   override fun onLost(network:android.net.Network){enforceNetwork()}
   override fun onCapabilitiesChanged(network:android.net.Network,caps:android.net.NetworkCapabilities){enforceNetwork()}
   private fun enforceNetwork(){main.post{if(!Updater.hasInternet(this@BipadoApplication)){
    stopService(android.content.Intent(this@BipadoApplication,CaptureService::class.java))
    foreground?.get()?.takeIf{it !is UpdateActivity && !it.isFinishing}?.let{Updater.openGate(it)}
   }}}
  })
 }
 override fun onActivityResumed(a:Activity){foreground=java.lang.ref.WeakReference(a);if(a !is UpdateActivity && !Updater.allowed(a))Updater.openGate(a)}
 override fun onActivityCreated(a:Activity,s:Bundle?){}
 override fun onActivityStarted(a:Activity){}
 override fun onActivityPaused(a:Activity){if(foreground?.get()===a)foreground=null}
 override fun onActivityStopped(a:Activity){}
 override fun onActivitySaveInstanceState(a:Activity,s:Bundle){}
 override fun onActivityDestroyed(a:Activity){}
}
