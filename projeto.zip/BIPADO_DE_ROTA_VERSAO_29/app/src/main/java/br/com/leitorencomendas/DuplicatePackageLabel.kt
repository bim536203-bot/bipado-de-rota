package br.com.leitorencomendas

object DuplicatePackageLabel {
 fun savedText(number:Int):String {require(number>0);return "PACOTE $number OK!!"}
 fun text(numbers:List<Int>):String {
  val ordered=numbers.filter {it>0}.distinct().sorted()
  val list=ordered.joinToString("-")
  return "MESMO ENDEREÇO PACOTE $list"
 }
}
