package br.com.leitorencomendas

import android.content.ActivityNotFoundException
import android.content.Intent

/** Uses the same CSV share contract; the receiving app still owns its import confirmations. */
object SpokeShare {
 const val PACKAGE_NAME="com.underwood.route_optimiser"

 /** Returns true after dispatch to Spoke, false after opening the normal Android chooser.
  * Starting the targeted Intent directly avoids package-visibility false negatives on Android 11+.
  * No explicit grantUriPermission: the existing Intent flags/ClipData grant temporary read access.
  */
 fun open(send:Intent,launch:(Intent)->Unit):Boolean {
  try {
   launch(Intent(send).setPackage(PACKAGE_NAME))
   return true
  } catch(_:ActivityNotFoundException) {
   // Spoke absent or this installed version has no compatible exported CSV receiver.
  } catch(_:SecurityException) {
   // Receiver unavailable to this caller: retain the manual sharing path.
  }
  launch(Intent.createChooser(Intent(send).setPackage(null),"Importar rota no Spoke"))
  return false
 }
}
