package br.com.leitorencomendas

/** A user-reviewed manual address does not depend on the original OCR or a map response. */
object ManualAddressValidation {
 private val house=Regex("""\b\d{1,5}\b""")
 private val city=Regex("""(?i)Boa\s+Vista[, ]+RR\b""")
 fun error(street:String,location:String):String? = when {
  street.trim().length<8 || !house.containsMatchIn(street) -> "Confira rua e número antes de salvar"
  !city.containsMatchIn(location) -> "Confira cidade e UF"
  else -> null
 }
}
