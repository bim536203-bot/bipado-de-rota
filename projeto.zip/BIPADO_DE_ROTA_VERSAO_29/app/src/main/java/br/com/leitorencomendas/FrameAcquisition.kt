package br.com.leitorencomendas

/** Runs on the image handler. Ownership of a delivered frame passes to onFrame. */
internal class FrameAcquisition<T : AutoCloseable>(
 private val acquireLatest: () -> T?,
 private val subscribe: (() -> Unit) -> Unit,
 private val unsubscribe: () -> Unit,
 private val onFrame: (T) -> Unit,
 private val onFailure: (Exception) -> Unit
) {
 private enum class State { NEW, PREPARED, WAITING, DELIVERED, CANCELLED, FAILED }
 private var state=State.NEW

 // Call while the overlay is still visible, before requesting a clean frame.
 fun prepare():Boolean {
  if(state!=State.NEW)return false
  return try {acquireLatest()?.close();state=State.PREPARED;true}
  catch(error:Exception){fail(error);false}
 }

 // A notification is not guaranteed for a frame already queued before subscription.
 fun awaitFrame(){
  if(state!=State.PREPARED)return
  state=State.WAITING
  try {subscribe {poll()};poll()}catch(error:Exception){fail(error)}
 }

 private fun poll(){
  if(state!=State.WAITING)return
  try {
   val frame=acquireLatest()?:return
   state=State.DELIVERED
   try {unsubscribe()}catch(error:Exception){frame.close();throw error}
   onFrame(frame)
  }catch(error:Exception){fail(error)}
 }

 fun cancel(){
  val wasWaiting=state==State.WAITING
  if(state==State.DELIVERED || state==State.FAILED || state==State.CANCELLED)return
  state=State.CANCELLED
  if(wasWaiting)try {unsubscribe()}catch(_:Exception){}
 }

 private fun fail(error:Exception){
  if(state==State.CANCELLED || state==State.FAILED)return
  state=State.FAILED
  try {unsubscribe()}catch(_:Exception){}
  onFailure(error)
 }
}
