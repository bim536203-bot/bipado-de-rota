# BIPADO DE ROTA — VERSÃO 16

Correção de seleção do endereço em telas com diferentes resoluções, proporções e fontes. Base: projeto V5.15.3 disponibilizado nesta conversa. Versão pública: 16. O código Android interno continua crescente para preservar atualizações de instalações existentes.

## Mudanças
- Removidos os cortes fixos de 72% da largura e 8%-96% da altura na seleção OCR.
- Seleção pelo conteúdo e pelas linhas do cartão: rastreio/destinatário, início do endereço, cidade/CEP e fim do cartão. Limites geométricos usam a altura local das letras.
- Ações de navegação/telefone são separadas pela sua posição. Tokens compactos destacados junto dessas ações podem ser excluídos como ícones; letras legítimas próximas ao nome da rua e números na margem do endereço são preservados.
- A captura inicial usa as dimensões físicas do display. Alterações de dimensões redimensionam o VirtualDisplay existente, sem criar outra sessão MediaProjection. Aquisição de imagem tolera o fechamento do leitor durante essa mudança.
- O movimento do botão flutuante considera as dimensões atuais do display.
- O último diagnóstico privado de falha passa a ser gravado também quando o endereço foi interpretado mas rejeitado pela validação, incluindo o motivo de seleção e dimensões. Mantém-se um único arquivo interno, sem transmissão.

## Edição manual após falha de OCR
O editor agora valida os campos antes de aplicar o rascunho. Ao salvar “rua Vega, 28” / “Boa Vista, RR”, por exemplo, a tela principal passa a mostrar CONFIRMAR, oculta PULAR e remove o aviso da falha OCR anterior. SALVAR do editor não grava o pacote; CONFIRMAR mantém o fluxo de gravação, duplicidade e numeração. Não há dependência de CEP ou resposta do mapa para edição manual válida. A validação da captura OCR permanece separada.

## Design de endereço não encontrado
Referência: Screenshot_20261016-223912.png. Na captura sem endereço validado, o mapa fica com faixa preta central, arredondada, e texto amarelo em negrito “ENDEREÇO NÃO ENCONTRADO!”. O aviso antigo de OCR, o status de busca e os controles de zoom ficam ocultos nesse estado. Permanecem Pacote N, lápis, endereço não identificado, Boa Vista/RR, CANCELAR e PULAR PARA PACOTE N+1. Atribuições do mapa são preservadas.
Ao salvar edição manual válida, o estado de falha sai: faixa removida, status e zoom normais restaurados, CONFIRMAR visível e PULAR oculto. O placeholder “Endereço não identificado” não é enviado à busca geográfica. O fluxo de repetidos não foi alterado.
A sintaxe JavaScript e transições de mapa foram verificadas com DOM/Leaflet simulados, inclusive erro de conexão no estado de falha. Não houve renderização em navegador: a instalação do navegador de teste falhou. O visual Android precisa de verificação no aparelho.

## Verificação executada
`sh run-regression.sh`, com Kotlin 2.0.21 e Java: 557 casos de layout sintético + 109 verificações existentes + 11 casos de validação manual, todos aprovados. O script também imprime a demonstração de falhas da base histórica, que não é o código desta versão.
- Largura, altura e fonte variadas independentemente, provocando novas quebras de linha.
- Quadros 720x1280, 1080x1920, 1080x2400, 1440x3200 e 1920x1080.
- Seis endereços das fotos, ordem aleatória dos elementos e presença/ausência de ações laterais.
- Cartão deslocado além de 72% da largura e próximo dos extremos verticais.
- Ícones simulados como T, 1, (T) e (ph); rua com T legítimo e residência com número 1.
- Fonte ampliada, falta de cidade/CEP e separação de dois cartões.

## Limites e pendências
Os testes usam as funções Kotlin reais e retângulos de elementos simulados. Não são execução de ML Kit nas fotos, testes em emulador, compilação Android ou uso no aparelho do colega. A compilação e o lint Android são executados no fluxo de publicação do GitHub, que verifica também a assinatura original. A captura, rotação e interação real com J&T precisam de teste em aparelhos antes de uso em entregas. Este pacote contém código-fonte, não APK, e não atualiza aplicativos instalados.

A validação continua exigindo evidências de cidade e CEP; nenhum dado ausente é inventado para aceitar a captura. Esta alteração não resolve todas as possibilidades de OCR, letras mescladas no mesmo elemento nem toda ambiguidade no número da residência. Leituras com números ambíguos ou T isolado suspeito no fim de uma rua exigem revisão manual; o app não escolhe nem apaga dados automaticamente. O fluxo de falha usa o design aprovado, sem o antigo aviso vermelho. A seleção espacial evita a contaminação por ícones identificáveis; não apaga todo T indiscriminadamente.

Não foi confirmada a causa de cada falha no celular do colega. A correção trata as limitações reproduzidas no código. As funções da base V5.15.3 foram preservadas, com a extensão de pacotes reais no mesmo endereço descrita abaixo. Os pulados continuam excluídos do CSV.

O usuário autorizou publicar a VERSÃO 16 no GitHub com o APK assinado necessário ao atualizador; entregar nesta conversa somente o ZIP. Não incluir chaves de assinatura no projeto.

## Entrega em preparação
Em 16/10/2026 às 23:15 (America/Boa_Vista), o usuário pediu consolidar, publicar no GitHub e enviar somente este ZIP. O APK é publicado no GitHub para o atualizador existente; o Android ainda solicita confirmação de instalação.

## Nomenclatura aprovada
Tela inicial: VERSÃO 16. Versão pública/Android versionName: 16. Próximas entregas: 17, 18, 19, sem pontos, traços ou sufixos. Na compilação automatizada, ciVersionName deve receber esse inteiro público. O versionCode interno continua independente e crescente para preservar compatibilidade de atualização; não aparece na etiqueta da tela inicial.
Nome do arquivo: BIPADO_DE_ROTA_VERSAO_16.zip (futuros: BIPADO_DE_ROTA_VERSAO_17.zip etc.). Enviar apenas quando o usuário pedir.

## Confirmação de pacotes reais no mesmo endereço
Na tela de repetidos, a opção abaixo de PULAR usa a frase MESMO ENDEREÇO PACOTE 1-2-3, com números reais em ordem e separados por hífen. Exibe uma única linha, com ajuste de fonte 8–16sp. Ao tocar, o usuário confirma o pacote atual como mais uma entrega real ao endereço já salvo; ele recebe seu próprio cartão e não vira pacote pulado. VOLTAR não salva nem consome número. PULAR continua criando somente a reserva/painel rosa, sem associar um endereço ao número pulado. O diálogo permite rolagem vertical para fontes maiores.

## Cartões com caixinhas dos outros pacotes
Referência Screenshot_20261016-230304.png. Entre o título e a lixeira de cada cartão, ícones 📦 com os números dos outros pacotes reais do mesmo endereço. Grupo 1-2-3: cartão 1 mostra 2/3; cartão 2 mostra 1/3; cartão 3 mostra 1/2. A própria numeração não aparece como par. Grupos extensos permitem rolagem horizontal dos ícones.
A relação deriva dos endereços efetivamente salvos, pelo critério de identidade já usado no app. Atualiza ao excluir, renumerar ou mudar o endereço de um cartão, e funciona após histórico/restauração ou importação. A edição de um endereço inalterado dentro de um grupo é permitida; a renumeração não pode ocupar número já salvo/pulado. Salvamento OCR normal continua bloqueando duplicação acidental: outro pacote real somente é salvo pela confirmação explícita MESMO ENDEREÇO.
O CSV exporta uma linha por endereço, reunindo todos os números reais nas Notes como PACOTE 1-2-3; não exporta pulados. Ao importar essa descrição, recupera os cartões individuais 1, 2 e 3 com o mesmo endereço. Importação também aceita CSV antigo com uma linha por pacote e endereços iguais com números distintos; rejeita número repetido. Não se criam pacotes reais com base em antigas associações de números pulados.
Testes: 38 asserções de pacotes/grupos/formatador e 22 da sequência do Store passaram, usando Store real com preferências Android em memória. Cobrem cartas 1→2/3, 2→1/3 e 3→1/2; confirmação explícita, cancelamento, skip sem grupo, renumeração, alteração, exclusão, histórico e importação de endereços iguais com números distintos. Reproduzir: `sh run-store-regression.sh /caminho/absoluto/json-20240303.jar`. Verificação visual Android continua pendente.

## Exportação agrupada para Spoke e reimportação
Regra: um destino por endereço. A coluna Address mantém o primeiro texto de endereço salvo do grupo, sem incluir números de pacote. A coluna Notes contém PACOTE 1-2-3 (ou PACOTE 1-2-7 para números não consecutivos), sem criar números intermediários. Pacote único: PACOTE N. Mesma regra de identidade dos cartões; rua igual com número residencial diferente continua em outra linha. Ordem dos destinos segue sua primeira ocorrência na lista; números em cada descrição ficam em ordem crescente. Não altera cartões, dados salvos ou nome de CSV por dia da semana.
Importar o CSV agrupado reconstitui um cartão por número listado. O parser valida todos os números/grupos e rejeita descrições malformadas ou numerações repetidas antes da substituição da lista. Valores sem Notes recebem números livres, sem ocupar IDs explícitos de outras linhas. Aspas, vírgulas e quebras de linha em campos seguem o escape CSV. A importação continua arquivando a lista anterior por 24 horas.
Verificação: 42 asserções de exportador/parser/Store, além de 38 de grupos e 22 de sequência passaram. Incluem CSV exato com uma linha agrupada, 1-2-7 sem expansão como intervalo, escape, erros sem mudança da lista ativa, recuperação dos cartões/ícones e ciclo exportar/importar/exportar estável. Comprovam conteúdo do CSV, não execução no Spoke. O teste real de importação no Spoke continua pendente.

## Proteção final de número e sufixo OCR
Nove casos adicionais passaram: a captura não aceita dois números antes do complemento/bairro como se o primeiro fosse certamente a residência; não aceita um T isolado suspeito ao fim de uma rua de múltiplas palavras. Encaminha à edição manual, preservando “Rua T” e números de complemento como apartamento quando explicitamente identificados. Não corrige silenciosamente dados já salvos.

## Publicação automática
Repositório: bim536203-bot/bipado-de-rota. O arquivo de automação externo projeto.zip recebe este projeto; publicar.py mantém versionName público inteiro (16), escolhe versionCode maior que a release anterior, compila e executa lint/testes, compara o certificado original e publica APK + update.json juntos somente após aprovação das verificações. O atualizador usa releases/latest/download/update.json. O aparecimento da atualização depende da release publicada, internet e verificação do app instalado; a instalação precisa ser confirmada no Android.
Verificações Kotlin locais: 686 da leitura/política/manual + 102 de Store/grupos/CSV = 788 aprovadas. Os relatórios locais são incluídos neste ZIP. A interface Android e o uso real no Spoke ainda dependem de teste no aparelho.
