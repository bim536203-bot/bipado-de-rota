# BIPADO DE ROTA — VERSÃO 23

- Android: confirmação verde PACOTE X OK!! sob o ícone flutuante somente depois de salvar com sucesso.
- Android e iPhone: numeração segue o maior número ativo na lista, inclusive pacotes pulados ainda visíveis; ignora contadores antigos após exclusões e renumerações.
- iPhone: botão verde ADICIONAR ENDEREÇO MANUALMENTE; SALVAR abre mini mapa e CONFIRMAR grava na lista. CANCELAR não grava. Sons originais do Android.
- Menu do iPhone com Histórico de lista apagada e Importar Rotas csv.
- O mini mapa precisa de internet e pode mostrar um ponto aproximado de rua quando não houver número na base. A mensagem informa essa diferença.
- Um único projeto.zip publica Android e iPhone pelo fluxo GitHub existente. Os endereços locais são preservados.
- Leaflet 1.9.4: licença em ios/dist/vendor/LICENSE. Mapas © OpenStreetMap; pesquisa Photon/Komoot, apenas após SALVAR.

# BIPADO DE ROTA — VERSÃO 19

Consulte LEIA_ME_V19.txt. Correção do artefato T) na captura do endereço.

# BIPADO DE ROTA — VERSÃO 18

Consulte LEIA_ME_V18.txt para as mudanças e limites de validação desta versão.

# BIPADO DE ROTA — VERSÃO 16

Projeto Android Kotlin com as correções consolidadas nesta conversa. O ZIP contém código-fonte; a atualização instalável é publicada no GitHub para o atualizador do app.

- Captura e seleção do cartão adaptadas às dimensões da tela e ao tamanho local do texto.
- Proteção contra ícones no endereço e leitura ambígua do número da casa.
- Edição manual recupera CONFIRMAR, remove aviso antigo e oculta PULAR ao salvar endereço válido.
- Tela de falha com faixa preta e texto amarelo ENDEREÇO NÃO ENCONTRADO!.
- Confirmação de pacotes reais no mesmo endereço, cartões individuais e caixinhas dos outros pacotes.
- Exportação de um destino por endereço com Notes PACOTE 1-2-3; reimportação recupera cartões individuais. Pulados não entram no CSV.
- Identificação pública VERSÃO 16, com próximas versões 17, 18, 19.

Leia LEIA_ME_VERSAO_16.md para regras e limites. Os demais relatórios LEIA_ME são históricos. São 788 verificações Kotlin locais aprovadas; compilação/lint/assinatura são validados no GitHub antes da release. O teste do fluxo real nos celulares e no Spoke ainda precisa ser feito.

Repositório de atualização: https://github.com/bim536203-bot/bipado-de-rota
