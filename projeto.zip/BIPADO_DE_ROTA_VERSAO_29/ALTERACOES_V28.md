# Versão 28 — envio direto ao Spoke no Android

Backup integral da versão 27 realizado antes da edição: BIPADO_DE_ROTA_VERSAO_27_BACKUP.zip, SHA-256 d10e0b71e12bf08dfb93bf4148729bec186dcf4912b6a1930d9a18ccde06bf7b.

O APK é um projeto Android nativo em Kotlin. O botão existente já produz o CSV e usa ACTION_SEND, text/csv e FileProvider. Agora o mesmo Intent é direcionado ao pacote com.underwood.route_optimiser, identificado na página oficial https://play.google.com/store/apps/details?id=com.underwood.route_optimiser . Não se presume uma Activity interna nem se usa abertura simples que descarte o arquivo.

Mantidos o content:// do FileProvider não exportado, ClipData e FLAG_GRANT_READ_URI_PERMISSION, sem concessão persistente. Se não houver Activity receptora compatível, ou ocorrer SecurityException, abre-se o mesmo seletor de compartilhamento da versão 27 com o mesmo CSV. Não há ações automáticas nas telas internas do Spoke: suas perguntas de importação continuam sob seu controle.

O relato de importação manual bem-sucedida na versão 27 demonstra o caminho CSV existente; não foi encontrado contrato público oficial específico de recebimento por Intent. A tentativa direcionada será resolvida pelo Android no aparelho. A aceitação do CSV e as confirmações internas do Spoke precisam ser validadas em celular com Spoke instalado; também testar sem Spoke para verificar o seletor alternativo.

Sem alteração do botão verde, geração/ordem/agrupamento CSV, números dos pacotes, mapa ou demais funções. Metadados Android e cache PWA avançados para 28 para compatibilidade com a publicação conjunta existente; integração nova somente Android.

Testes: verification/spoke compila o helper real com fronteira Intent simulada, cobrindo destino, payload/permissões, ausência/incompatibilidade/recusa do receptor e falha do seletor. A compilação Android, lint, assinatura e regressões de dados/CSV são verificadas pelo workflow de publicação. Testes simulados e build não substituem validação no celular.
