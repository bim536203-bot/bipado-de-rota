# BIPADO DE ROTA — VERSÃO 24

Busca durante a digitação no Android e no iPhone, por fragmentos da rua ou pelo nome do estabelecimento. Até cinco sugestões com endereço e CEP quando informado pelo serviço. Escolher a sugestão posiciona o pino com suas coordenadas e permite CONFIRMAR. O botão SALVAR foi retirado deste fluxo. A confirmação continua sendo o momento em que o pacote é gravado.

No Android, a edição dos endereços salvos também tem sugestões, mapa e CONFIRMAR. A pesquisa interativa usa Photon nos dois sistemas; o geocódigo automático de capturas Android preserva Geoapify. Não foram adicionadas chaves ao ZIP.

A seleção não faz nova geocodificação. Respostas antigas são ignoradas após nova digitação; consultas são canceladas ao fechar a tela. Reaproveitamento de resultados em memória. A espera de até três pesquisas sequenciais na captura Android foi substituída por uma consulta focada. Números que a base não confirmar permanecem marcados como aproximados. CEP ausente não é inventado.

Verificação local: 25 testes Node (incluindo fluxo por fragmentos, CEP, cancelamento, mapa com coordenadas selecionadas, confirmação, edição, CSV, banco e atualização); regressões Kotlin de captura, numeração, Store e CSV aprovadas. Compilação dos três arquivos Android alterados contra Android API 35 aprovada, usando substitutos das APIs ML Kit somente para checagem de tipos. A compilação completa Gradle/lint foi impedida pela resolução do plugin Android neste ambiente e precisa passar no CI antes de publicar.

Consulta real ao Photon encontrou o Supermercado Goiana na Cidade Satélite, Boa Vista, com CEP 69317-482. Consulta observada levou aproximadamente cinco segundos neste ambiente. A primeira pesquisa depende da rede e do serviço; não há promessa de latência ou cobertura iguais às do Spoke. Selecionar um resultado já recebido não espera outra consulta para posicionar o marcador. Não houve teste físico em iPhone/Safari ou Android.

Publicação não executada: a revisão automática rejeitou o envio do ZIP ao repositório público bim536203-bot/bipado-de-rota por exigir autorização explícita para divulgar o código desta atualização. Nenhum commit, release Android ou site iPhone foi alterado. Requer autorização do usuário, envio e sucesso do CI antes de orientar atualização nos aparelhos.
