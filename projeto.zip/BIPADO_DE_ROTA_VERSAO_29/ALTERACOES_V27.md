# Versão 27 — alterações da aba Endereços salvos

- Pacotes pulados: cartão neutro, texto PACOTE N pulado sem negrito, somente lixeira individual com confirmação.
- Endereços com dois ou mais pacotes: números amarelos em etiqueta preta ao lado de PACOTE; endereços com um único pacote preservam estilo original.
- Botão fixo acima da lista rolável IMPORTAR PARA SPOKE, com arte verde aprovada e ícones dos dois aplicativos.
- Compartilhamento de CSV UTF-8 com cabeçalhos Address,Notes e pacotes agrupados por endereço; o Android apresenta os aplicativos compatíveis via compartilhamento.
- Não há integração oficial de importação automática comprovada com o Spoke; a seleção/importação poderá exigir ação manual.
- A ordem da lista permanece definida pelo algoritmo original.

Arquivo-fonte atualizado; compilação e teste real com Spoke pendentes.
