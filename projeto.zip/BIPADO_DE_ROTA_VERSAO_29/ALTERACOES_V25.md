# BIPADO DE ROTA — VERSÃO 25

## Busca do lápis no Android
Tela em folha branca com cantos superiores arredondados, puxador, lupa, busca contornada em azul, limpar (X) e sugestões em linhas com ícone, título, bairro/cidade e CEP fornecido pela base. Não cria mapa/WebView na busca. Busca por fragmentos durante digitação; o número é mantido no endereço pretendido, mas não é usado para esconder ruas que ainda não tenham a casa cadastrada.

Selecionar mantém a tela aberta, destaca a linha em azul e mostra SALVAR verde. Tocar fora da linha selecionada e de SALVAR desmarca, remove o destaque e oculta SALVAR sem apagar busca/sugestões. Tocar outra linha troca a seleção; editar/limpar a busca invalida a seleção. CANCELAR não aplica o rascunho.

SALVAR aplica o endereço e volta à confirmação com mapa/pino. Somente CONFIRMAR grava o pacote e segue numeração/bip existentes. Captura, grupos e CSV preservados. O visual da busca do iPhone não foi trocado pela folha Android.

## Precisão do ponto
O número digitado no texto e o CEP não são prova de localização da casa. Pino laranja identifica resultado aproximado; pino vermelho identifica casa retornada pela base, estabelecimento ou ajuste manual do usuário. Avisos distinguem cada situação. Ao salvar uma sugestão aproximada com número no Android, o mapa tenta uma consulta completa ao Geoapify para localizar a casa. Resultado sem número correspondente não substitui o ponto como se fosse preciso. Ajustar manualmente cancela a consulta pendente, evitando que uma resposta atrasada mova o pino de volta.

Android e iPhone permitem tocar no mapa ou arrastar o marcador para ajustar o ponto. Esse ajuste é rotulado como manual, não como casa localizada automaticamente. Coordenadas confirmadas/ajustadas ficam salvas com o pacote; coordenadas aproximadas e inválidas não são gravadas como ponto confirmado. Edição para outro endereço limpa o ponto antigo. Pacote adicional para o mesmo endereço mantém o ponto verificado no Android. CSV mantém as colunas Address/Notes existentes: ajuste manual de coordenadas não acrescenta colunas de localização ao arquivo exportado.

Não há promessa de cobertura/precisão iguais ao Google Maps. A base pode continuar sem a casa 28 cadastrada, sendo necessário ajuste manual. CEP ausente não é inventado.

## Verificação
28 testes Node passaram, incluindo o JavaScript real do mapa Android em ambiente simulado, arraste/toque, cor aproximada, tokens, descarte de ponto inválido, persistência e limpeza na edição. Store/CSV: 160 verificações locais passaram. Arquivos Kotlin alterados compilados contra API35 com substitutos das APIs MLKit somente para checagem de tipos. Compilação completa/lint e demais regressões devem passar no CI antes de confirmar publicação. Não houve teste físico de teclado/overlay no Moto G8 Plus ou de Safari.

Consulta externa adicional ao serviço de mapas foi bloqueada pela revisão automática. Verificação desta mudança realizada com testes e respostas simuladas, sem tentar contornar o bloqueio ou reenviar endereços por outro caminho.

Publicação pendente: a revisão automática rejeitou o envio da versão25 ao repositório público por exigir consentimento explícito para publicar o código completo desta versão nesse destino. Nenhum commit/release/site da25 foi publicado. A versão24 continua instalada/disponível. Aguardar autorização do usuário e CI bem-sucedido antes de anunciar atualização disponível.
