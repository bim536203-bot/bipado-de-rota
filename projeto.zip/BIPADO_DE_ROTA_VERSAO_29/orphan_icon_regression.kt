import br.com.leitorencomendas.OcrLayout as O
import br.com.leitorencomendas.AddressExtractor as A
import br.com.leitorencomendas.CaptureAddressValidation as V
fun main(){
 var count=0
 fun expect(ok:Boolean,message:String){check(ok){message};count++}
 fun parcel(icon:String?,scale:Double=1.0,action:Boolean=true,closeToStreet:Boolean=false):List<O.Span>{
  fun s(t:String,x:Int,y:Int,r:Int,b:Int)=O.Span(t,(x*scale).toInt(),(y*scale).toInt(),(r*scale).toInt(),(b*scale).toInt())
  return listOfNotNull(
   s("999999999999999",68,298,440,335),s("Destinatário de Exemplo",68,419,730,455),s("Teste",68,485,275,520),
   s("Rua das Mozendras 194",68,568,530,608),
   icon?.let {s(it,if(closeToStreet)537 else 698,566,if(closeToStreet)578 else 744,609)},
   if(action)s("navegação",758,569,940,608) else null,
   s("casa PRICUMA Boa Vista-RR",68,622,618,659),
   if(action)s("telefone",758,657,930,698) else null,
   s("69309414",68,673,273,706),s("2026-10-16 13:12:38",68,756,471,786))
 }
 for(scale in listOf(.65,1.0,1.6,2.4))for(icon in listOf("T)","(T","T]","[T","1)","(1","(T)","T")){
  val selected=O.select(parcel(icon,scale),(970*scale).toInt(),(2048*scale).toInt())
  val r=A.parse(selected.text)
  expect(r.streetLine=="Rua das Mozendras, 194, Casa — Pricumã","Remove detached action glyph $icon at scale $scale: $selected => $r")
  expect(r.locationLine=="Boa Vista, RR, 69309-414" && V.valid(selected.text,r),"Preserve exact house/CEP and allow clean capture")
 }
 val orphan=O.select(parcel("T)",action=false),970,2048)
 expect(orphan.text.contains("T)"),"Do not delete without spatial action evidence")
 expect(!V.valid(orphan.text,A.parse(orphan.text)),"Reject remaining partial glyph instead of accepting corrupt address")
 val attached=O.select(parcel("T)",closeToStreet=true),970,2048)
 expect(attached.text.contains("T)"),"Do not erase glyph attached to address solely by its shape")
 expect(!V.valid(attached.text,A.parse(attached.text)),"Require manual review for attached suspicious glyph")
 val city="casa PRICUMA Boa Vista-RR 69309414"
 for(raw in listOf("Rua das Mozendras 194 T) $city","Rua das Mozendras T) 194 $city","Rua das Mozendras 194 (T $city")){
  expect(A.parse(raw).streetLine.isBlank() && !V.valid(raw,A.parse(raw)),"Fallback rejects orphan icon: $raw")
 }
 for(raw in listOf("Rua T 194 $city","Rua das Mozendras 194 Casa Bloco T PRICUMA Boa Vista-RR 69309414","Rua das Mozendras 194 Casa Bloco T) PRICUMA Boa Vista-RR 69309414","Rua dos Taxis 180 $city")){
  expect(A.parse(raw).streetLine.isNotBlank() && V.valid(raw,A.parse(raw)),"Preserve legitimate street/block letter: $raw")
 }
 val noIcon=O.select(parcel(null),970,2048)
 expect(A.parse(noIcon.text).streetLine=="Rua das Mozendras, 194, Casa — Pricumã","Normal parcel without icon unchanged")
 println("Orphan icon regression: $count checks passed (synthetic geometry, not live device ML Kit)")
}
