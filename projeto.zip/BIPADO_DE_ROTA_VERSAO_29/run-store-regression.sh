#!/usr/bin/env sh
set -eu
if [ "$#" -ne 1 ]; then
 echo 'Uso: sh run-store-regression.sh /caminho/absoluto/json-20240303.jar' >&2
 exit 2
fi
json_jar=$1
cd "$(dirname "$0")"
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
src=app/src/main/java/br/com/leitorencomendas
kotlinc "$src/Store.kt" "$src/AddressIdentity.kt" "$src/AddressText.kt" "$src/DuplicatePackageLabel.kt" "$src/RouteCsv.kt" verification/store/Context.kt verification/store/StoreSequenceRegression.kt verification/store/SameAddressRegression.kt verification/store/RouteCsvRegression.kt verification/store/GroupedCardsRegression.kt -classpath "$json_jar" -include-runtime -d "$work/store-tests.jar"
java -cp "$work/store-tests.jar:$json_jar" SameAddressRegressionKt
java -cp "$work/store-tests.jar:$json_jar" StoreSequenceRegressionKt
java -cp "$work/store-tests.jar:$json_jar" RouteCsvRegressionKt

java -cp "$work/store-tests.jar:$json_jar" GroupedCardsRegressionKt
