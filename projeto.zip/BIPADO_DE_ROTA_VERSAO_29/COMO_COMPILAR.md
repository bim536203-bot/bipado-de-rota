# Compilar a versão corrigida

Requisitos: JDK 17, Gradle 8.9, Android SDK plataforma 35 e Build Tools 34.0.0. Abrir esta pasta como projeto no Android Studio, configurar o SDK, ou criar local.properties com sdk.dir apontando para o SDK.

Executar `gradle assembleDebug lintDebug`. O APK aparece em app/build/outputs/apk/debug/app-debug.apk.

Para manter a assinatura das versões já instaladas, fornecer a chave original externamente: `gradle -PbipadoSigningKey=/caminho/BIPADO_DE_ROTA_Assinatura_Testes.jks assembleDebug lintDebug`. A chave não foi incluída neste ZIP. Sem essa propriedade, a compilação usa a chave debug local e NÃO poderá atualizar um aplicativo assinado com outra chave. Este pacote não inclui APK; a assinatura da futura compilação depende da chave fornecida externamente.

Rodar os testes com `./run-regression.sh` (requer kotlinc e Java). Consulte INVESTIGACAO_TECNICA.md para evidências e limites.
