import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import {readFile} from 'node:fs/promises';
const html=await readFile(new URL('../../app/src/main/assets/mapa.html',import.meta.url),'utf8');
test('Mapa Android diferencia ponto aproximado, aceita ajuste e envia coordenadas com geração da busca',()=>{
 const elements={},events={},calls=[];let marker,options;
 const node=id=>elements[id]??={textContent:'',style:{},classList:{toggle(){}}};
 const document={getElementById:node,createElement:()=>({}),body:{classList:{toggle(){}}}};
 const map={setView(){return this},on:(name,fn)=>events[name]=fn,removeLayer(){},invalidateSize(){}};
 const L={map:()=>map,tileLayer:()=>({on(){return this},addTo(){return this}}),divIcon:o=>o,marker:(coords,o)=>{
  options=o;marker={coords,addTo(){return this},bindPopup(){return this},on(name,fn){this[name]=fn;return this},setLatLng(c){this.coords=c},getLatLng(){return {lat:this.coords[0],lng:this.coords[1]}}};return marker;
 }};
 const window={BipadoPoint:{moved:(...args)=>calls.push(args)}};
 vm.runInNewContext(html.match(/<script>([\s\S]*?)<\/script>/)[1],{window,document,L,setTimeout:fn=>fn()});
 window.placePin(2.8,-60.6,'Rua Exemplo, 28',false,'Photon',false,7);
 assert.equal(options.draggable,true);assert.match(options.icon.html,/approximate-pin/);assert.match(elements.notice.textContent,/aproximado/);
 events.click({latlng:{lat:2.81,lng:-60.61}});assert.deepEqual(calls[0],[2.81,-60.61,7]);
 window.placePin(2.81,-60.61,'Rua Exemplo, 28',false,'Photon',true,8);assert.doesNotMatch(options.icon.html,/approximate-pin/);
 marker.coords=[2.82,-60.62];marker.dragend();assert.deepEqual(calls[1],[2.82,-60.62,8]);
 window.clearPin();events.click({latlng:{lat:2.83,lng:-60.63}});assert.equal(calls.length,2);
});
