import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import {readFile,access} from 'node:fs/promises';
import {APP_VERSION} from '../dist/version.js';import {setupUpdates} from '../dist/updates.js';
const root=new URL('../dist/',import.meta.url);
test('Worker instala todos os arquivos, preserva banco e usa cache da versão offline',async()=>{
 const source=await readFile(new URL('sw.js',root),'utf8');const listeners={};let skip=0,claimed=0;const removed=[],files=[];
 const cache={addAll:async requests=>{for(const r of requests){files.push(r.url);await access(new URL(r.url.replace('https://example.test/bipado/',root.href)));}},match:async req=>String(req.url||req).endsWith('index.html')?'offline-shell':'cached-asset'};
 const self={location:{href:'https://example.test/bipado/sw.js'},addEventListener:(name,fn)=>listeners[name]=fn,skipWaiting:()=>skip++,clients:{claim:()=>claimed++}};
 vm.runInNewContext(source,{self,URL,Request,Set,caches:{open:async()=>cache,keys:async()=>['other-app','bipado-de-rota-shell-19','bipado-de-rota-shell-'+APP_VERSION],delete:async k=>removed.push(k)},fetch:()=>{throw Error('offline');}});
 let waiting;listeners.install({waitUntil:p=>waiting=p});await waiting;assert.ok(files.length>=12);assert.equal(skip,0);
 listeners.activate({waitUntil:p=>waiting=p});await waiting;assert.deepEqual(removed,['bipado-de-rota-shell-19']);assert.equal(claimed,1);
 let response;listeners.fetch({request:{url:'https://example.test/bipado/',method:'GET',mode:'navigate'},respondWith:p=>response=p});assert.equal(await response,'offline-shell');
 listeners.message({data:{type:'SKIP_WAITING'}});assert.equal(skip,1);assert.ok(!source.includes('indexedDB'));
 const version=JSON.parse(await readFile(new URL('version.json',root),'utf8'));assert.equal(version.version,APP_VERSION);assert.ok(source.includes("const APP_VERSION = '"+APP_VERSION+"'"));
});
test('Atualização exige ação, protege edição e recarrega apenas uma vez',async()=>{
 const events={},domEvents={},windowEvents={};let posted=0,reloaded=0,dirty=true;
 const banner={hidden:true},button={addEventListener:(n,fn)=>events[n]=fn};
 const reg={waiting:{postMessage:()=>posted++},addEventListener:()=>{},update:async()=>{}};
 const sw={controller:{},register:async()=>reg,addEventListener:(n,fn)=>events[n]=fn};
 const win={navigator:{serviceWorker:sw},document:{getElementById:id=>id==='update-banner'?banner:button,addEventListener:(n,fn)=>domEvents[n]=fn},location:{reload:()=>reloaded++},addEventListener:(n,fn)=>windowEvents[n]=fn};
 const updates=setupUpdates(win,{isEditing:()=>dirty});await updates.check();assert.equal(banner.hidden,false);events.controllerchange();assert.equal(reloaded,0);
 events.click();assert.equal(posted,0);dirty=false;events.click();assert.equal(posted,1);events.controllerchange();events.controllerchange();assert.equal(reloaded,1);
});
