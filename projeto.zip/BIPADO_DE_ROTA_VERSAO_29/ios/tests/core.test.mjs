import test from 'node:test';
import assert from 'node:assert/strict';
import * as C from '../dist/core.js';
const A='Rua das Campainhas, 111, Casa Verde, Pricumã, Boa Vista, RR, 69309-470, Brasil';
const B='Rua dos Ipês, 221, Pricumã, Boa Vista, RR';
const now=1792281600000;
const item=(number,address=A)=>({number,address,createdAt:now});
const csv='\uFEFFAddress,Notes\r\n"'+A+'","PACOTE 1-2-7"\r\n"'+B+'","PACOTE 5;"\r\n';
test('CSV Android agrupado mantém IDs reais, sem interpretar hífen como intervalo',()=>{
 const items=C.parseCsv(csv,now);assert.deepEqual(items.map(i=>i.number),[1,2,7,5]);
 const gs=C.groups(items);assert.equal(gs.length,2);assert.equal(C.groupTitle(gs[0]),'PACOTE 1-2-7');assert.equal(gs[0].primaryNumber,1);
 assert.deepEqual(C.parseCsv(C.exportCsv(items),now),items);assert.ok(C.matchesGroup(gs[0],'7'));assert.ok(C.matchesGroup(gs[0],'pricuma'));
});
test('CSV preserva aspas, acentos e novas linhas em campo',()=>{
 const address='Rua das Rosas, 447, Casa "Azul"\nBoa Vista, RR';
 assert.equal(C.parseCsv(C.exportCsv([item(1,address)]))[0].address,address);
});
test('CSV sem descrição reserva antes os números explícitos e ignora pulados',()=>{
 const input='Address,Notes\n"'+A+'",\n"'+B+'",PACOTE 1\n"PACOTE 8 PULADO",PACOTE 8 PULADO\n';
 assert.deepEqual(C.parseCsv(input).map(i=>i.number),[2,1]);
});
for(const note of ['PACOTE 1-1','PACOTE 0','PACOTE 2147483648','PACOTE 1--2','PACOTE 1 e 2','PACOTE'])test('Rejeita descrição inválida: '+note,()=>assert.throws(()=>C.parseCsv('Address,Notes\n"'+A+'","'+note+'"')));
test('Erros de arquivo não alteram lista anterior',()=>{
 const state=C.importRoute(C.freshState(),[item(9,B)],now), copy=structuredClone(state);
 for(const bad of ['Address,Notes\n"sem fechar,', 'Notes\nPACOTE 1','Address,Notes\nabc,1,extra','Address,Notes\n"'+A+'",PACOTE 1\n"'+B+'",PACOTE 1'])assert.throws(()=>C.importRoute(state,C.parseCsv(bad),now));
 assert.deepEqual(state,copy);
});
test('Identidade aceita abreviação e ignora complemento mantendo número da casa',()=>{
 assert.ok(C.sameAddress(A,'R. das Campainhas, 111, Casa Azul, Boa Vista, RR'));
 assert.ok(!C.sameAddress(A,'Rua das Campainhas, 112, Boa Vista, RR'));
 assert.equal(C.groups([item(7),item(1),item(3)] )[0].primaryNumber,7);
});
test('Histórico salva lista substituída e restaura sem apagar a atual',()=>{
 let s=C.importRoute(C.freshState(),[item(1),item(2)],now);
 s=C.importRoute(s,[item(8,B)],now+1);assert.equal(s.history.length,1);
 const id=s.history[0].id;s=C.restoreRoute(s,id,now+2);assert.deepEqual(s.items.map(i=>i.number),[1,2]);assert.equal(s.history.length,2);
 assert.equal(C.prune(s,now+C.RETENTION).history.length,2);
 assert.equal(C.prune(s,now+C.RETENTION+2).history.length,0);
 assert.throws(()=>C.restoreRoute(s,id,now+C.RETENTION+2));
 s=C.clearRoute(s,now+3);assert.equal(s.items.length,0);assert.ok(s.history.length);
});
test('Edição e exclusão de grupos exigem números válidos e grupo completo',()=>{
 const s=C.importRoute(C.freshState(),[item(1),item(2),item(7),item(9,B)],now);
 assert.throws(()=>C.editItem(s,1,9,A,now));assert.throws(()=>C.removeGroup(s,[1,2],now));
 const edited=C.editItem(s,7,8,'Rua das Rosas, 447, Boa Vista, RR',now);assert.equal(C.groups(edited.items).length,3);
 const removed=C.removeGroup(s,[7,1,2],now);assert.deepEqual(removed.items.map(i=>i.number),[9]);assert.equal(s.items.length,4);
 assert.equal(C.addManual(s,A,now).items.at(-1).number,10);
});
test('Exportação exclui pulados e rejeita duplicidade de número',()=>{
 assert.equal(C.parseCsv(C.exportCsv([item(1),{...item(2,B),skipped:true}])).length,1);
 assert.throws(()=>C.exportCsv([item(1),item(1,B)]));
});

test('Importa o arquivo gerado pelo código Kotlin real do Android',async()=>{
 const {readFile}=await import('node:fs/promises');const real=await readFile(new URL('./fixtures/android-export.csv',import.meta.url),'utf8');
 const items=C.parseCsv(real,now);assert.deepEqual(items.map(i=>i.number),[1,2,7,5]);assert.equal(C.groups(items).length,2);
 assert.equal(C.groups(items)[0].address,A);assert.equal(items[3].address,'Rua dos Ipês, 221, casa "Azul", Boa Vista, RR');
 assert.equal(C.exportCsv(items),real);
});
