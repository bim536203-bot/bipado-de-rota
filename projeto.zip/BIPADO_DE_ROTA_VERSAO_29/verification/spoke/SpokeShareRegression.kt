import android.content.ActivityNotFoundException
import android.content.Intent
import br.com.leitorencomendas.SpokeShare

fun main() {
 val clip=Any()
 val send=Intent(Intent.ACTION_SEND).apply {
  type="text/csv"; flags=Intent.FLAG_GRANT_READ_URI_PERMISSION; clipData=clip
  extras[Intent.EXTRA_STREAM]="content://br.com.leitorencomendas.updates/spoke_exports/ROTA_PARA_SPOKE.csv"
 }
 fun checkPayload(actual: Intent) {
  check(actual.action==Intent.ACTION_SEND)
  check(actual.type=="text/csv")
  check(actual.flags==Intent.FLAG_GRANT_READ_URI_PERMISSION)
  check(actual.clipData===clip)
  check(actual.extras==send.extras)
 }
 val direct=mutableListOf<Intent>()
 check(SpokeShare.open(send){direct.add(it)})
 check(direct.size==1)
 check(direct.single().targetPackage=="com.underwood.route_optimiser")
 checkPayload(direct.single())
 check(send.targetPackage==null)
 for(failure in listOf(ActivityNotFoundException(), SecurityException())) {
  val attempts=mutableListOf<Intent>()
  check(!SpokeShare.open(send){
   attempts.add(it)
   if(it.targetPackage!=null) throw failure
  })
  check(attempts.size==2)
  check(attempts[0].targetPackage==SpokeShare.PACKAGE_NAME)
  val chooser=attempts[1]
  check(chooser.action==Intent.ACTION_CHOOSER)
  val fallback=chooser.extras[Intent.EXTRA_INTENT] as Intent
  check(fallback.targetPackage==null)
  checkPayload(fallback)
 }
 var propagated=false
 try {
  SpokeShare.open(send){throw ActivityNotFoundException()}
 } catch(_:ActivityNotFoundException) { propagated=true }
 check(propagated) // Existing Activity catch can display its error if even sharing is unavailable.
 check(send.targetPackage==null)
 println("SpokeShare: direct dispatch, missing/incompatible receiver, denied receiver, chooser failure and CSV/read grant preservation passed (JVM boundary simulation).")
}
