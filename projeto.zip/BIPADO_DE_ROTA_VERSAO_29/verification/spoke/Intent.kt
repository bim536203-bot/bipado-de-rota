// JVM-only boundary double. Not included in the Android application.
package android.content

class ActivityNotFoundException: RuntimeException()

class Intent {
 var action: String? = null
 var type: String? = null
 var flags: Int = 0
 var clipData: Any? = null
 var targetPackage: String? = null
 val extras = mutableMapOf<String, Any>()
 constructor(action: String) { this.action = action }
 constructor(other: Intent) {
  action=other.action; type=other.type; flags=other.flags
  clipData=other.clipData; targetPackage=other.targetPackage; extras.putAll(other.extras)
 }
 fun setPackage(value: String?): Intent { targetPackage=value; return this }
 companion object {
  const val ACTION_SEND="android.intent.action.SEND"
  const val ACTION_CHOOSER="android.intent.action.CHOOSER"
  const val EXTRA_INTENT="android.intent.extra.INTENT"
  const val EXTRA_STREAM="android.intent.extra.STREAM"
  const val FLAG_GRANT_READ_URI_PERMISSION=1
  fun createChooser(target: Intent, title: CharSequence): Intent = Intent(ACTION_CHOOSER).apply {
   extras[EXTRA_INTENT]=target; extras["title"]=title
  }
 }
}
