# Envio ao Spoke — regressão JVM

Compile o SpokeShare.kt real junto de Intent.kt e SpokeShareRegression.kt com o compilador Kotlin e execute SpokeShareRegressionKt. O Intent.kt desta pasta é uma fronteira simulada, fora de app/src e não entra no APK.

Verifica direcionamento ao pacote, preservação do payload CSV, ClipData e permissão de leitura, fallback por ActivityNotFoundException/SecurityException e propagação da falha do seletor ao tratamento já existente na Activity. Não comprova o funcionamento do Android nem a aceitação pelo Spoke instalado: validar no celular com e sem Spoke.
