import android.content.Context
import br.com.leitorencomendas.Store
import br.com.leitorencomendas.DuplicatePackageLabel
import org.json.JSONArray
import org.json.JSONObject

fun main(){
 var count=0
 fun expect(ok:Boolean,message:String){check(ok){message};count++}
 fun row(n:Int,address:String)=JSONObject().put("number",n).put("address",address)
 val c=Context()
 val address="Rua Vega, 28, Boa Vista, RR"
 expect(Store.add(c,address,1),"Save original package")
 expect(DuplicatePackageLabel.text(Store.sameAddressNumbers(c,1,2))=="MESMO ENDEREÇO PACOTE 1-2","Two real numbers in confirmation option")
 expect(Store.nextNumber(c)==2 && Store.all(c).length()==1,"Opening/cancelling duplicate does not save or consume")
 expect(!Store.add(c,address,2),"Ordinary OCR save still blocks accidental duplicates")
 expect(Store.addSameAddress(c,1,2),"Explicit same-address action creates package 2")
 expect(Store.addSameAddress(c,1,3),"Explicit same-address action creates package 3")
 expect(Store.all(c).length()==3,"Each real package has its own address card")
 val snapshot=Store.all(c)
 expect(Store.relatedNumbers(snapshot,1)==listOf(2,3),"Card 1 displays boxes 2 and 3")
 expect(Store.relatedNumbers(snapshot,2)==listOf(1,3),"Card 2 displays boxes 1 and 3")
 expect(Store.relatedNumbers(snapshot,3)==listOf(1,2),"Card 3 displays boxes 1 and 2")
 expect(Store.relatedNumbers(snapshot,99).isEmpty(),"No badges for missing card")
 expect(Store.skipped(c).length()==0,"Confirmed same-address packages are not skipped")
 expect(Store.skipNext(c,4),"PULAR reserves only its number")
 expect(Store.relatedNumbers(Store.all(c),1)==listOf(2,3),"Skipped 4 is not an address-group member")
 expect(!Store.addSameAddress(c,1,4),"Cannot reuse skipped number")
 expect(!Store.addSameAddress(c,999,5),"Cannot confirm a missing original")
 expect(Store.nextNumber(c)==5,"Failed confirmation cannot consume number")
 expect(DuplicatePackageLabel.text(Store.sameAddressNumbers(c,2,5))=="MESMO ENDEREÇO PACOTE 1-2-3-5","Next duplicate includes all real peers")
 expect(Store.edit(c,1,2,address),"Editing unchanged address inside the group succeeds")
 expect(!Store.edit(c,1,4,address),"Cannot renumber into a skipped number")
 expect(Store.edit(c,1,8,address),"Renumber a member")
 expect(Store.relatedNumbers(Store.all(c),1)==listOf(3,8),"Peer badges update when number changes")
 expect(Store.edit(c,1,8,"Rua das Rosas, 500, Boa Vista, RR"),"Change one package to a different address")
 expect(Store.relatedNumbers(Store.all(c),1)==listOf(3),"Peer badges detach changed address")
 expect(Store.relatedNumbers(Store.all(c),8).isEmpty(),"Changed card no longer shows old peers")
 expect(Store.remove(c,0),"Delete original card")
 expect(Store.relatedNumbers(Store.all(c),3).isEmpty(),"Remaining group does not show deleted number")
 val d=Context()
 expect(Store.add(d,address,1) && Store.addSameAddress(d,1,2) && Store.addSameAddress(d,2,3),"Create group through any member")
 expect(Store.clear(d),"Archive route")
 val at=Store.history(d).getJSONObject(0).getLong("deletedAt")
 expect(Store.restore(d,at),"Restore route")
 expect(Store.relatedNumbers(Store.all(d),2)==listOf(1,3),"Group survives history restoration")
 val exportedRows=Store.all(d)
 expect(exportedRows.length()==3 && (0 until exportedRows.length()).all{exportedRows.getJSONObject(it).getString("address")==address},"All three real packages remain available to existing CSV exporter")
 expect(Store.replaceWithImport(d,exportedRows),"CSV roundtrip can import distinct packages at the same address")
 expect(Store.relatedNumbers(Store.all(d),3)==listOf(1,2),"Imported matching addresses rebuild peer badges")
 expect(!Store.replaceWithImport(d,JSONArray().put(row(1,address)).put(row(1,address))),"CSV import still rejects duplicate package numbers")
 expect(Store.replaceWithImport(d,JSONArray().put(row(1,"Rua das Flores, 555, Boa Vista, RR"))),"Import different route")
 expect(Store.relatedNumbers(Store.all(d),1).isEmpty(),"No previous group leaks into different imported route")
 expect(DuplicatePackageLabel.text(listOf(7,1,2,2,0,-1))=="MESMO ENDEREÇO PACOTE 1-2-7","Sort/deduplicate actual positive numbers")
 println("$count same-address package/card/label assertions passed (real Store with in-memory Android preferences)")
}
