import br.com.leitorencomendas.RouteCsv
import org.json.JSONArray
import org.json.JSONObject
fun main(args:Array<String>){
 val rows=JSONArray()
 for(n in listOf(1,2,7))rows.put(JSONObject().put("number",n).put("address","Rua das Campainhas, 111, Casa Verde, Pricumã, Boa Vista, RR, 69309-470, Brasil"))
 rows.put(JSONObject().put("number",5).put("address","Rua dos Ipês, 221, casa \"Azul\", Boa Vista, RR"))
 rows.put(JSONObject().put("number",8).put("address","PACOTE 8 PULADO").put("skipped",true))
 java.io.File(args[0]).writeText(RouteCsv.export(rows))
}
