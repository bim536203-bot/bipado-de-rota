import android.content.Context
import br.com.leitorencomendas.Store
import org.json.JSONArray
import org.json.JSONObject

fun main(){
 var cases=0
 fun expect(value:Boolean,message:String){check(value){message};cases++}
 fun row(n:Int)=JSONObject().put("number",n).put("address","Rua Teste $n, ${100+n}, Centro, Boa Vista, RR")
 fun seed(c:Context,last:Int,items:JSONArray=JSONArray(),skips:JSONArray=JSONArray()){
  c.getSharedPreferences("deliveries",0).edit().putString("state",JSONObject().put("items",items).put("skipped",skips).put("history",JSONArray()).put("lastNumber",last).toString()).commit()
 }
 val c=Context()
 expect(Store.nextNumber(c)==1,"A fresh route must start at 1")
 expect(Store.add(c,row(1).getString("address"),1),"First scan saves package 1")
 expect(Store.add(c,row(2).getString("address"),2),"Second scan saves package 2")
 expect(Store.remove(c,1),"Deleting latest package succeeds")
 expect(Store.nextNumber(c)==2,"Deleting highest saved parcel recalculates from remaining list")
 expect(Store.remove(c,0),"Deleting last address succeeds")
 expect(Store.nextNumber(c)==1,"Deleting last address resets to 1")
 seed(c,14,JSONArray().put(row(14)))
 expect(Store.clear(c),"Clear archives and empties active route")
 expect(Store.nextNumber(c)==1,"Clear resets to 1")
 expect(Store.history(c).getJSONObject(0).getJSONArray("items").getJSONObject(0).getInt("number")==14,"Archived package number is preserved")
 seed(c,99)
 expect(Store.nextNumber(c)==1,"Empty states from older versions ignore stale counter")
 expect(Store.add(c,row(1).getString("address"),1),"Stale empty state accepts package 1")
 expect(Store.nextNumber(c)==2,"New sequence proceeds to 2")
 seed(c,99)
 expect(Store.clear(c),"Clearing an already empty stale state succeeds")
 expect(JSONObject(c.getSharedPreferences("deliveries",0).getString("state","")!!).getInt("lastNumber")==0,"Clear persists counter reset")
 expect(Store.skipNext(c,1),"Skipping first package reserves 1")
 expect(Store.nextNumber(c)==2,"Visible skipped package retains its reserved number")
 expect(Store.add(c,row(2).getString("address"),2),"First actual address after skip is package 2")
 expect(Store.clear(c),"Clear removes skipped placeholders too")
 expect(Store.skipped(c).length()==0 && Store.nextNumber(c)==1,"Cleared skipped route resets to 1")
 expect(Store.replaceWithImport(c,JSONArray().put(row(14)).put(row(15))),"Import keeps explicit package numbers")
 expect(Store.nextNumber(c)==16,"Imported route continues from its maximum")
 seed(c,999,JSONArray().put(row(1)).put(row(15)))
 expect(Store.nextNumber(c)==16,"Ignore stale historical counter on nonempty list")
 expect(Store.remove(c,1) && Store.nextNumber(c)==2,"Deleting maximum reuses next number after active maximum")
 expect(Store.edit(c,0,7,row(7).getString("address")) && Store.nextNumber(c)==8,"Renumbering updates next")
 expect(Store.edit(c,0,3,row(3).getString("address")) && Store.nextNumber(c)==4,"Renumbering down does not keep stale maximum")
 expect(Store.skipNext(c,4) && Store.nextNumber(c)==5,"Visible skipped parcel still reserves its own number")
 expect(Store.replaceWithImport(c,JSONArray().put(row(1)).put(row(2)).put(row(7))) && Store.nextNumber(c)==8,"Grouped real member maximum controls next")
 seed(c,0,JSONArray().put(row(Int.MAX_VALUE)))
 expect(Store.nextNumber(c)==0,"Exhausted sequence never wraps negative")
 expect(!Store.add(c,row(1).getString("address"),0) && !Store.skipNext(c,0),"Reject exhausted sequence writes")
 val points=Context()
 val address="Rua Exemplo, 28, Boa Vista, RR"
 expect(Store.add(points,address,1,2.8,-60.6,"manual"),"Save confirmed manual point")
 expect(Store.all(points).getJSONObject(0).optString("pointPrecision")=="manual","Manual point survives persistence")
 expect(Store.addSameAddress(points,1,2),"Add same-address parcel with confirmed point")
 expect(Store.all(points).getJSONObject(1).optDouble("latitude")==2.8,"Same-address parcel retains verified point")
 expect(Store.edit(points,0,1,"Rua Exemplo, 30, Boa Vista, RR"),"Edit to a different house")
 expect(!Store.all(points).getJSONObject(0).has("latitude"),"Different house cannot retain previous coordinates")
 val approximate=Context()
 expect(Store.add(approximate,address,1,2.8,-60.6,"approximate"),"Text address can still be saved when point is unknown")
 expect(!Store.all(approximate).getJSONObject(0).has("latitude"),"Approximate street point is never stored as a verified house")
 val invalid=Context()
 expect(Store.add(invalid,address,1,Double.NaN,-60.6,"manual"),"Invalid coordinate does not prevent saving address text")
 expect(!Store.all(invalid).getJSONObject(0).has("latitude"),"Non-finite coordinates are discarded")
 println("$cases Store sequence regression assertions passed")
}
