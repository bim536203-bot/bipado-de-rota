import android.content.Context
import br.com.leitorencomendas.Store
import br.com.leitorencomendas.RouteCsv
import org.json.JSONArray
import org.json.JSONObject

fun main(){
 var count=0
 fun expect(ok:Boolean,message:String){check(ok){message};count++}
 val a="Rua das Campainhas, 111, Casa Verde, Pricumã, Boa Vista, RR, 69309-470, Brasil"
 val b="Rua das Campainhas, 112, Pricumã, Boa Vista, RR, 69309-470, Brasil"
 fun item(n:Int,address:String)=JSONObject().put("number",n).put("address",address)
 fun numbers(items:JSONArray)=(0 until items.length()).map{items.getJSONObject(it).getInt("number")}
 val input=JSONArray().put(item(3,a)).put(item(1,a)).put(item(2,a)).put(item(4,b))
  .put(item(5,a).put("skipped",true)).put(item(6,""))
 val original=input.toString()
 val csv=RouteCsv.export(input)
 val expected="Address,Notes\r\n\"$a\",\"PACOTE 1-2-3\"\r\n\"$b\",\"PACOTE 4\"\r\n"
 expect(csv==expected,"Exactly one address per stop, combined Notes, numeric order and no skipped placeholders")
 expect(input.toString()==original,"Export never mutates saved package cards")
 val parsed=RouteCsv.parse(csv)
 expect(numbers(parsed)==listOf(1,2,3,4),"Grouped CSV restores individual package IDs")
 expect((0..2).all{parsed.getJSONObject(it).getString("address")==a},"Grouped parcels retain exact address text")
 val apart=RouteCsv.export(JSONArray().put(item(7,a)).put(item(2,a)).put(item(1,a)))
 expect(apart.contains("PACOTE 1-2-7"),"Non-consecutive package IDs preserved")
 expect(numbers(RouteCsv.parse(apart))==listOf(1,2,7),"Hyphens are a list, not a range")
 expect(!apart.contains("PACOTE 1-2-3-4-5-6-7"),"No invented package IDs")
 val numeric=RouteCsv.export(JSONArray().put(item(10,a)).put(item(2,a)))
 expect(numeric.contains("PACOTE 2-10"),"Numeric, not lexicographic order")
 expect(RouteCsv.export(JSONArray().put(item(1,a).put("skipped",true)))=="Address,Notes\r\n","Only-skipped data creates no phantom address row")
 val escaped="Rua \"Azul\", 28, Casa\nPricumã, Boa Vista, RR"
 expect(RouteCsv.parse(RouteCsv.export(JSONArray().put(item(8,escaped)))).getJSONObject(0).getString("address")==escaped,"CSV quotes, commas and newlines survive")
 val mixed=RouteCsv.parse("Address,Notes\r\n\"$b\",\"\"\r\n\"$a\",\"PACOTE 1-7;\"\r\n")
 expect(numbers(mixed)==listOf(2,1,7),"Unlabelled CSV rows cannot steal explicit IDs occurring later")
 expect(numbers(RouteCsv.parse("\uFEFFNotes,Address\n\"PACOTE 1-2-7.\",\"$a\"\n"))==listOf(1,2,7),"BOM, reversed columns, optional trailing dot")
 expect(numbers(RouteCsv.parse("Address,Notes\n\"$a\",\"PACOTE 9\"\n"))==listOf(9),"Legacy single-package CSV supported")
 val c=Context()
 expect(Store.add(c,a,1) && Store.addSameAddress(c,1,2) && Store.addSameAddress(c,1,3),"Create real same-address group")
 expect(Store.skipNext(c,4) && Store.add(c,b,5),"Add skipped parcel and distinct destination")
 val full=RouteCsv.export(Store.all(c))
 expect(full=="Address,Notes\r\n\"$a\",\"PACOTE 1-2-3\"\r\n\"$b\",\"PACOTE 5\"\r\n","End-to-end Store export groups real packages and omits skipped 4")
 val imported=RouteCsv.parse(full)
 expect(Store.replaceWithImport(c,imported),"Grouped CSV import accepted atomically")
 expect(Store.relatedNumbers(Store.all(c),2)==listOf(1,3),"Individual cards and peer badges reconstructed")
 expect(Store.nextNumber(c)==6,"Sequence continues beyond largest imported real package")
 expect(RouteCsv.export(Store.all(c))==full,"Export/import/export roundtrip is stable")
 expect(Store.history(c).length()==1,"Import archived previous active list")
 expect(Store.history(c).getJSONObject(0).getJSONArray("skipped").getInt(0)==4,"Previous skipped record remains in history, not route CSV")
 val before=Store.all(c).toString()
 fun rejected(text:String){
  var failed=false
  try{RouteCsv.parse(text)}catch(_:IllegalArgumentException){failed=true}
  expect(failed,"Malformed import must be rejected: $text")
  expect(Store.all(c).toString()==before,"Invalid parsing must not change active data")
 }
 for(note in listOf("PACOTE 1--2","PACOTE 1-","PACOTE -1","PACOTE 0-2","PACOTE 1-1","PACOTE 2147483648","PACOTE 1-2 e 3"))
  rejected("Address,Notes\n\"$a\",\"$note\"\n")
 rejected("Address,Notes\n\"$a\",\"PACOTE 1-2\"\n\"$b\",\"PACOTE 2-3\"\n")
 rejected("Address,Notes\n\"$a\",\"PACOTE 1-2\n")
 var invalidExport=false
 try{RouteCsv.export(JSONArray().put(item(1,a)).put(item(1,b)))}catch(_:IllegalArgumentException){invalidExport=true}
 expect(invalidExport,"Export must not silently assign one package number to two destinations")
 val skipImport=RouteCsv.parse("Address,Notes\n\"$a\",\"PACOTE 2 PULADO\"\n\"$b\",\"PACOTE 9\"\n")
 expect(numbers(skipImport)==listOf(9),"Legacy skipped rows ignored on import")
 println("$count grouped CSV/roundtrip/preservation assertions passed (actual exporter, parser and Store)")
}
