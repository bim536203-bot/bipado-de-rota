# Versão 26 — correção da busca por fragmentos

## Problemas comprovados no código
- O filtro antigo eliminava os termos de tipo de via e fragmentos de uma letra. “via” e “dos b” ficavam sem termos válidos e os resultados eram descartados.
- A consulta ao Photon buscava no país inteiro e só depois o app eliminava os resultados fora da região. O limite pequeno podia ser consumido por resultados fora de Boa Vista.
- O estado/cidade era adicionado após o fragmento, em vez de preservar a palavra incompleta no final.
- “28Ve” não separava o número; “Rua 13 de Maio” podia confundir número da rua com número da casa.

## Alterações
- Filtro próprio de autocomplete aceita uma letra no fragmento e mantém o tipo da rua quando só o tipo foi digitado; normaliza abreviações e acentos, exige correspondência dos termos significativos. Não transforma qualquer rua em sugestão válida.
- Photon: consulta por fragmento sem número da casa, filtro bbox fixo da região de Boa Vista + Brasil no servidor, camadas street/house quando há número, até20 candidatos para selecionar5 relevantes. Localização fixa é contexto da cidade, não GPS do aparelho.
- Android: se Photon retornar zero sugestões e existir chave Geoapify configurada, uma tentativa de autocomplete Geoapify com a mesma região dentro do prazo total de8,5s. Sem criar contas, alterar chaves ou contratar planos. Máximo duas tentativas por busca; conserva cancelamento, controle de frequência e cache. Cache v4 invalida dados antigos.
- iPhone: após mostrar imediatamente a rua selecionada, tenta buscar o número no Photon com nome completo. Só refina com número correspondente na resposta. Toque/arraste manual cancela a consulta; respostas atrasadas não sobrescrevem ajuste manual.
- Geoapify: número digitado/ecoado em resultado de rua não comprova casa. Casa exige resultado building/amenity e não pode trazer match_type de rua/CEP/cidade/estado.
- CEP continua vindo exclusivamente da base; pino aproximado permanece identificado. Nenhum CEP, posição da casa ou rua foi inventado/hardcoded para reproduzir screenshots.
- Mantém o fluxo Android aprovado: selecionar → SALVAR → mapa → CONFIRMAR. iPhone mantém seu fluxo vigente.

## Validação e limites
- 32 testes Node passaram localmente e1 teste online Geoapify foi reservado ao CI com a chave já configurada, incluindo montagem da requisição, fragmentos “46 dos b”, “46 dos bam”, “1003 via”, “1093 via”, separação “28Ve”, “Rua13deMaio”, refinamento e corrida contra ajuste manual. São respostas simuladas/offline; não comprovam cobertura real.
- Regressões Kotlin de consulta/filtro passaram; MapAssistant e dependências diretas compilados contra API35 usando BuildConfig substituto apenas para checagem de tipos, fora do ZIP.
- Build/lint Gradle completo local bloqueado por plugin Android8.7.3 ausente do cache. Ainda precisa do CI autorizado. Sem teste físico Android/iPhone.
- Usuário autorizou testes e publicação e estabeleceu autorização contínua para atualizações do projeto. Photon real testado: consulta “dos b” com camadasstreet/house encontra Alameda dos Bambus; “dos bam” encontra Alameda/Travessa dos Bambus; “via” encontra Via das Flores. Respostas reais preservadas sócomo fixturesdeteste, sem dados hardcoded na produção. Os CEPs variam por trecho da rua; não provam localização da casa. RuaVega28 retornou sóa rua, número não comprovado. Latência externa observada5,2–5,6s; prazoajustado para evitar falsoerro. Duplicatas da mesmarua/bairro colapsadas priorizando aresposta da base. Sem prova de precisão igualaoSpoke; não identificadofornecedor dele.
- Código26 autorizado para publicação; verificar CI/release antes de afirmar disponível. No fechamento deste ZIP a versão pública anterior era25. Se a cobertura das bases for insuficiente após testes reais, será necessário avaliar outro fornecedor e seu acesso/custo antes de integrar. Não existe garantia universal de localização de cada casa.

## Documentação consultada
- https://github.com/komoot/photon/blob/master/docs/api-v1.md — bbox, limite e foco geográfico.
- https://apidocs.geoapify.com/docs/geocoding/address-autocomplete/ — autocomplete por partes e filtros.
- https://apidocs.geoapify.com/docs/geocoding/forward-geocoding/ — tipo de resultado, match_type e confiança.
