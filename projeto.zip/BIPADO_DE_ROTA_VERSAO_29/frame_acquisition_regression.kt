package br.com.leitorencomendas

private class Frame(val id:Int):AutoCloseable {var closed=0;override fun close(){closed++}}
private class Screen {
 var queued:Frame?=null
 var listener:(()->Unit)?=null
 var error:Exception?=null
 var readCount=0
 fun acquire():Frame? {readCount++;error?.let {throw it};return queued.also {queued=null}}
 fun produce(frame:Frame){queued?.close();queued=frame;listener?.invoke()}
}
fun main(){
 var checks=0
 fun verify(condition:Boolean){check(condition);checks++}
 fun request(s:Screen,frames:MutableList<Frame>,errors:MutableList<Exception>)=FrameAcquisition(
  acquireLatest=s::acquire,subscribe={s.listener=it},unsubscribe={s.listener=null},
  onFrame={frames+=it;it.close()},onFailure={errors+=it})
 // Reproduce the former bug: discarding after hiding consumes the only clean frame.
 run {val s=Screen();val clean=Frame(1);s.produce(clean);s.acquire()?.close();var called=false;s.listener={called=true}
  verify(clean.closed==1);verify(!called);verify(s.acquire()==null)}
 // Frozen screen: clean image arrives before subscription; no new notification ever occurs.
 run {val s=Screen();val old=Frame(0);s.produce(old);val got=mutableListOf<Frame>();val errors=mutableListOf<Exception>();val r=request(s,got,errors)
  verify(r.prepare());verify(old.closed==1);val clean=Frame(1);s.produce(clean);r.awaitFrame()
  verify(got.map{it.id}==listOf(1));verify(clean.closed==1);verify(s.listener==null);verify(errors.isEmpty())
  r.awaitFrame();verify(got.size==1)}
 // Slow producer: listener can notify with no image; later image still completes once.
 run {val s=Screen();val got=mutableListOf<Frame>();val errors=mutableListOf<Exception>();val r=request(s,got,errors)
  verify(r.prepare());r.awaitFrame();val staleNotification=s.listener!!;staleNotification();verify(got.isEmpty());verify(errors.isEmpty())
  s.produce(Frame(2));staleNotification();verify(got.map{it.id}==listOf(2));verify(s.listener==null)}
 // Rotating/cancelling before settling must never deliver a stale screen or subscribe again.
 run {val s=Screen();val got=mutableListOf<Frame>();val errors=mutableListOf<Exception>();val r=request(s,got,errors)
  verify(r.prepare());r.cancel();s.produce(Frame(3));r.awaitFrame();verify(got.isEmpty());verify(s.listener==null);verify(errors.isEmpty())}
 run {val s=Screen();val got=mutableListOf<Frame>();val errors=mutableListOf<Exception>();val r=request(s,got,errors)
  verify(r.prepare());r.awaitFrame();val notification=s.listener!!;r.cancel();notification();verify(got.isEmpty());verify(s.listener==null)}
 // Closed reader and unsubscribe errors must not escape the worker or strand the bubble.
 run {val s=Screen();val errors=mutableListOf<Exception>();s.error=IllegalStateException("closed");val r=request(s,mutableListOf(),errors)
  verify(!r.prepare());r.awaitFrame();verify(errors.size==1);verify(s.listener==null)}
 run {val s=Screen();val errors=mutableListOf<Exception>();val r=request(s,mutableListOf(),errors);verify(r.prepare());r.awaitFrame();s.error=IllegalStateException("resized");s.listener!!();verify(errors.size==1);verify(s.listener==null)}
 // Repeated deliveries, including queued-before-subscribe and listener-after-subscribe.
 val s=Screen()
 repeat(20){n->val got=mutableListOf<Frame>();val errors=mutableListOf<Exception>();s.produce(Frame(-1));val r=request(s,got,errors)
  verify(r.prepare());val clean=Frame(100+n)
  if(n%2==0){s.produce(clean);r.awaitFrame()}else{r.awaitFrame();s.produce(clean)}
  verify(got.single()===clean);verify(clean.closed==1);verify(errors.isEmpty());verify(s.listener==null)
 }
 println("Frame acquisition: $checks checks passed")
}
