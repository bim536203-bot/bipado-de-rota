import br.com.leitorencomendas.ManualAddressValidation as V

fun main(){
 // Manual review is independent of OCR evidence, CEP availability and map/network results.
 val accepted=listOf(
  "rua Vega, 28" to "Boa Vista, RR",
  "Rua das Rosas, 447, Casa — Pricumã" to "Boa Vista, RR, 69309-630",
  "Rua A, 1" to "Boa Vista RR",
  "  Rua Vega, 28  " to "boa vista, rr"
 )
 for((street,location) in accepted)check(V.error(street,location)==null){"Manual address refused: $street, $location"}
 val rejected=listOf(
  "" to "Boa Vista, RR",
  "Rua Vega" to "Boa Vista, RR",
  "Rua Vega, 123456" to "Boa Vista, RR",
  "Rua Vega, 28" to "",
  "Rua Vega, 28" to "Boa Vista",
  "Rua Vega, 28" to "Manaus, AM",
  "Rua Vega, 28" to "Boa Vista, RRXXX"
 )
 for((street,location) in rejected)check(V.error(street,location)!=null){"Invalid manual address accepted: $street, $location"}
 println("${accepted.size+rejected.size} manual address validation cases passed; Android control visibility still requires device testing")
}
