# Versão 29 — ajustes da tela Endereços salvos

- Cabeçalho branco, sem título e sem texto VOLTAR; ícones azuis de voltar, pesquisar e excluir sempre fixos.
- Botão de importação ocupa a largura útil, cor verde opaca e texto IMPORTAR PARA ROTA SPOKE.
- Botão de importação rola junto com os cartões; cabeçalho fica fixo.
- Vibração de 70 ms ao tocar em importar, igual à do ícone flutuante em CaptureService.
- Efeito Ripple nos controles da tela de endereços, inclusive ícones, editar e importar.
- Preservada lógica de compartilhamento CSV e de pacotes.

Observação: a tematização Ripple foi aplicada aos controles Android padrão; ícones personalizados em outras telas e a compilação APK exigem validação adicional.
