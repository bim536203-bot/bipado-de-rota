package br.com.leitorencomendas

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.*

/** One-field correction; SALVAR changes only the existing confirmation draft. */
object QuickAddressDialog {
 fun show(context:Context,locality:CaptureLocality.Result,isCurrent:()->Boolean,onSave:(String)->Unit,onDismiss:()->Unit):Dialog {
  fun dp(n:Int)=(n*context.resources.displayMetrics.density+.5f).toInt()
  fun bg(color:Int)=GradientDrawable().apply{setColor(color);cornerRadius=dp(14).toFloat()}
  val dialog=Dialog(context)
  dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
  dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
  val panel=LinearLayout(context).apply{
   orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(24),dp(22),dp(22));background=bg(Color.WHITE)
  }
  panel.addView(TextView(context).apply{
   text="Digite apenas o nome da rua e o número da casa.";textSize=19f;setTextColor(Color.BLACK)
  },LinearLayout.LayoutParams(-1,-2))
  val input=EditText(context).apply{
   hint="Rua e número";textSize=18f;setTextColor(Color.BLACK);setHintTextColor(0xFF687788.toInt())
   inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
   setSingleLine(true);imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_DONE
   contentDescription="Nome da rua e número da casa"
  }
  panel.addView(input,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(20);bottomMargin=dp(20)})
  val save=Button(context).apply{
   text="SALVAR";setTextColor(0xFF173B65.toInt());background=bg(0xFFDCEBFF.toInt())
  }
  panel.addView(save,LinearLayout.LayoutParams(-1,dp(52)))
  save.setOnClickListener{
   if(!isCurrent()){dialog.dismiss();return@setOnClickListener}
   val street=input.text.toString().replace(Regex("""\s+""")," ").trim()
   val error=CaptureLocality.streetError(street,locality)
   if(error!=null){input.error=error;return@setOnClickListener}
   onSave(street);dialog.dismiss()
  }
  input.setOnEditorActionListener{_,_,_->save.performClick();true}
  dialog.setContentView(ScrollView(context).apply{addView(panel)})
  dialog.setCanceledOnTouchOutside(false)
  dialog.setOnDismissListener{onDismiss()}
  dialog.showWithFeedback()
  dialog.window?.apply{
   setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));setGravity(Gravity.CENTER)
   setLayout(context.resources.displayMetrics.widthPixels-dp(32),-2)
   clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM)
   setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
  }
  input.requestFocus()
  return dialog
 }
}
