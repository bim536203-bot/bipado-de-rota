import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {resultList} from '../dist/mini-map.js';

test('Respostas reais Photon de 18/10/2026: fragmentos retornam ruas e CEP; Vega28 continua aproximada',async()=>{
 for(const [name,q,street] of [['dos-b','46 dos b','Alameda dos Bambus'],['dos-bam','46 dos bam','Travessa dos Bambus'],['via','1003 via','Via das Flores']]){
  const body=JSON.parse(await readFile(new URL('./fixtures/photon-'+name+'.json',import.meta.url)));
  const hits=resultList(body.features,q+', Boa Vista, RR');
  assert.ok(hits.some(h=>h.streetLine.startsWith(street)&&h.postcode));
  assert.equal(new Set(hits.map(h=>h.streetLine)).size,hits.length);
  assert.ok(hits.every(h=>!h.exact));
 }
 const body=JSON.parse(await readFile(new URL('./fixtures/photon-vega-28.json',import.meta.url)));
 const hits=resultList(body.features,'Rua Vega, 28, Boa Vista, RR');
 assert.equal(hits.length,1);assert.match(hits[0].streetLine,/Rua Vega, 28/);assert.equal(hits[0].exact,false);
});

// CI uses the existing Geoapify secret. Never print the key or request URL.
test('Geoapify online: autocomplete encontra as ruas dos exemplos autorizados', {skip:!process.env.GEOAPIFY_API_KEY},async()=>{
 for(const [text,expected] of [['dos bam',/bambu/i],['via',/via das flores/i]]){
  const url=new URL('https://api.geoapify.com/v1/geocode/autocomplete');
  for(const [k,v] of Object.entries({text,format:'json',limit:'5',lang:'pt',filter:'rect:-61.2,2.4,-60.15,3.25|countrycode:br',bias:'proximity:-60.6758,2.8235',apiKey:process.env.GEOAPIFY_API_KEY}))url.searchParams.set(k,v);
  const response=await fetch(url,{signal:AbortSignal.timeout(15000)});
  assert.ok(response.ok,'Geoapify HTTP '+response.status);
  const body=await response.json();
  const found=(body.results||[]).filter(r=>expected.test(r.street||r.name||'')&&r.lat>=2.4&&r.lat<=3.25&&r.lon>=-61.2&&r.lon<=-60.15);
  assert.ok(found.length,'Geoapify não retornou a rua esperada para '+text);
  console.log('Geoapify validado:',text,found.map(r=>({street:r.street||r.name,postcode:r.postcode||'',type:r.result_type})));
 }
});
