import br.com.leitorencomendas.SavedMapGesture as G
fun main(){
 check(G.opens(-150f,20f,300));check(!G.opens(150f,20f,300));check(!G.opens(-50f,5f,200));check(!G.opens(-150f,180f,300));check(!G.opens(-150f,20f,900));check(!G.opens(-150f,20f,300,2))
 check(G.sameStreet("Rua das Acácias, 26, Pricumã, Boa Vista, RR","R. das Acacias, 26, Pricumã"))
 check(!G.sameStreet("Rua das Acácias, 26, Boa Vista, RR","Alameda das Acácias, 26, Pricumã"))
 check(!G.sameStreet("Rua das Rosas, 26, Boa Vista, RR","Rua das Rosas Brancas, 26, Pricumã"))
 println("Saved map: 9 gesture and full street/type identity checks passed")
}
