package br.com.leitorencomendas

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.LinearLayout
import android.widget.Button
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/** Read-only overview: resolves a snapshot and never changes saved parcels or their order. */
class SavedRouteMapActivity:Activity(){
 private lateinit var web:WebView
 private lateinit var assistant:MapAssistant
 private val main=Handler(Looper.getMainLooper())
 private var closed=false
 private var generation=0
 private var lastResolve=0L
 override fun onCreate(state:Bundle?){
  super.onCreate(state)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)}
  root.addView(Button(this).apply{text="← ENDEREÇOS SALVOS";setTextColor(0xFF1769DC.toInt());setOnClickListener{finish()}},LinearLayout.LayoutParams(-1,-2))
  web=WebView(this);root.addView(web,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
  assistant=MapAssistant(this,null,TextView(this))
  web.settings.javaScriptEnabled=true;web.settings.allowFileAccess=true;web.settings.allowContentAccess=false
  web.addJavascriptInterface(Bridge(),"RouteBridge")
  web.webViewClient=object:WebViewClient(){
   override fun shouldOverrideUrlLoading(view:WebView?,request:WebResourceRequest?):Boolean=true
   override fun onPageFinished(view:WebView?,url:String?){if(!closed && url=="file:///android_asset/route-overview.html")web.evaluateJavascript("openRoute(${snapshot()});",null)}
  }
  TouchFeedback.install(root);web.loadUrl("file:///android_asset/route-overview.html")
 }
 private fun snapshot():JSONArray{
  val items=Store.all(this);val stops=JSONArray()
  for(group in Store.addressGroups(items)){
   val stop=JSONObject().put("address",group.address).put("numbers",JSONArray(group.numbers))
   for(index in group.indices.reversed()){
    val item=items.getJSONObject(index);val lat=item.optDouble("latitude",Double.NaN);val lon=item.optDouble("longitude",Double.NaN);val precision=item.optString("pointPrecision")
    if(lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0 && precision in setOf("house","place","manual")){
     stop.put("point",JSONObject().put("lat",lat).put("lon",lon).put("precision",precision));break
    }
   }
   stops.put(stop)
  }
  return stops
 }
 private inner class Bridge{
  @JavascriptInterface fun resolve(id:Int,address:String){main.post {
   if(closed)return@post
   val token=generation
   // Sequential requests are scheduled by the overview; no caller can write to Store.
   val wait=(1000-(android.os.SystemClock.elapsedRealtime()-lastResolve)).coerceAtLeast(0)
   main.postDelayed({
   if(closed)return@postDelayed
   lastResolve=android.os.SystemClock.elapsedRealtime()
   assistant.lookup(address,false){hits->
    if(closed || token!=generation)return@lookup
    val hit=hits.firstOrNull{it.lat.isFinite() && it.lon.isFinite() && SavedMapGesture.sameStreet(address,it.streetLine)}
    val point=hit?.let{JSONObject().put("lat",it.lat).put("lon",it.lon).put("precision",it.precision).toString()} ?: "null"
    web.evaluateJavascript("routeResolved($id,$point);",null)
   }
   },wait)
  }}
 }
 override fun onDestroy(){closed=true;generation++;main.removeCallbacksAndMessages(null);if(::assistant.isInitialized)assistant.release();if(::web.isInitialized){web.removeJavascriptInterface("RouteBridge");web.stopLoading();web.destroy()};super.onDestroy()}
}
