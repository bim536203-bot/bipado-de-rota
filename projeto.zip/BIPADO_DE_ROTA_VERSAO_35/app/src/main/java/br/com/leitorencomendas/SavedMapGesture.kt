package br.com.leitorencomendas
object SavedMapGesture {
 fun sameStreet(address:String,offered:String):Boolean {
  val requested=AddressIdentity.normalize(GeoAddress.query(address).street)
  return requested.isNotBlank() && requested==AddressIdentity.normalize(GeoAddress.query(offered).street)
 }
 fun opens(dx:Float,dy:Float,elapsed:Long,pointers:Int=1):Boolean = pointers==1 && elapsed in 0 until 800 && dx<=-80f && kotlin.math.abs(dx)>kotlin.math.abs(dy)*1.6f
}
