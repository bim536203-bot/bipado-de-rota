// Saved-list overview. Addresses and labels are rendered as text; no contacts are sent.
function swipeToMap(dx,dy,elapsed,pointers=1){return pointers===1&&elapsed>=0&&elapsed<800&&dx<=-80&&Math.abs(dx)>Math.abs(dy)*1.6;}
function attachMapSwipe(window,container,open){
 let start=null;
 const down=e=>{if(e.touches.length!==1){start=null;return;}const t=e.touches[0];start={x:t.clientX,y:t.clientY,at:Date.now()};};
 const up=e=>{const s=start;start=null;if(!s||e.changedTouches.length!==1)return;const t=e.changedTouches[0];if(swipeToMap(t.clientX-s.x,t.clientY-s.y,Date.now()-s.at)){e.preventDefault();open();}};
 const cancel=()=>start=null;
 container.addEventListener('touchstart',down,{passive:true});container.addEventListener('touchend',up,{passive:false});container.addEventListener('touchcancel',cancel);
 return ()=>{container.removeEventListener('touchstart',down);container.removeEventListener('touchend',up);container.removeEventListener('touchcancel',cancel);};
}
function validRoutePoint(point){return !!point&&Number.isFinite(point.lat)&&Number.isFinite(point.lon)&&Math.abs(point.lat)<=90&&Math.abs(point.lon)<=180&&['house','place','manual','approximate'].includes(point.precision);}
function mountRouteOverview(window,container,{stops=[],resolve=async()=>null}={}){
 const d=window.document,controller=new window.AbortController();let closed=false,map=null,tilesFailed=false;
 const node=(tag,text,cls)=>{const n=d.createElement(tag);if(text)n.textContent=text;if(cls)n.className=cls;return n;};
 container.replaceChildren();container.classList.add('route-overview');
 const canvas=node('div','','route-canvas');canvas.setAttribute('aria-label','Mapa dos endereços salvos');
 const status=node('p','Preparando mapa…','route-status');status.setAttribute('role','status');container.append(canvas,status);
 const records=stops.map(s=>({address:String(s.address||''),numbers:[...new Set((s.numbers||[]).filter(n=>Number.isInteger(n)&&n>0))].sort((a,b)=>a-b),point:validRoutePoint(s.point)?{...s.point}:null,done:validRoutePoint(s.point)})).filter(s=>s.address&&s.numbers.length);
 const points=[];
 function fitAll(){if(!map||!points.length)return;try{if(points.length===1)map.setView(points[0],17);else map.fitBounds(points,{padding:[35,35],maxZoom:17});}catch{}}
 function update(){
  if(closed)return;
  const located=records.filter(s=>s.point).length,approx=records.filter(s=>s.point?.precision==='approximate').length,pending=records.filter(s=>!s.done).length,unlocated=records.filter(s=>s.done&&!s.point);
  status.textContent=!map?'Não foi possível abrir o mapa. Os endereços continuam salvos.':!records.length?'Nenhum endereço salvo':`${located} de ${records.length} endereços no mapa${approx?' • '+approx+' aproximado(s)':''}${pending?' • localizando '+pending:''}${tilesFailed?' • mapa sem conexão':''}${!map?' • mapa indisponível':''}`;
  if(unlocated.length)status.textContent+=' • '+unlocated.map(s=>`PACOTE ${s.numbers.join('-')}: localização não encontrada`).join('; ');
  canvas.setAttribute('aria-label',status.textContent);
 }
 try{
  if(window.L){
   map=window.L.map(canvas,{attributionControl:true}).setView([2.8235,-60.6758],13);
   window.L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).on('tileerror',()=>{tilesFailed=true;update();}).addTo(map);
  }
 }catch{map=null;}
 function add(s){
  if(!s.point||!map||closed)return;const p=s.point;points.push([p.lat,p.lon]);
  const pin=node('span',s.numbers.join('-'),'route-pin'+(p.precision==='approximate'?' route-approximate':''));
  const tooltip=node('div');tooltip.append(node('strong','PACOTE '+s.numbers.join('-')),node('span',s.address.split(',').slice(0,2).join(', ')));
  if(p.precision==='approximate')tooltip.append(node('small','Localização aproximada'));
  const details=node('div');details.append(node('strong','PACOTE '+s.numbers.join('-')),node('p',s.address));
  if(p.precision==='approximate')details.append(node('small','Localização aproximada da rua'));
  window.L.marker([p.lat,p.lon],{icon:window.L.divIcon({className:'route-marker',html:pin,iconSize:[42,36],iconAnchor:[21,36]}),interactive:true,keyboard:true,title:'PACOTE '+s.numbers.join('-')}).addTo(map).bindPopup(details,{closeButton:false,closeOnClick:true}).bindTooltip(tooltip,{className:'route-label',direction:'top',offset:[0,-34],permanent:true,interactive:false});
 }
 for(const s of records)if(s.point)add(s);fitAll();update();
 const ready=(async()=>{
  if(!map)return;
  for(const s of records){
   if(closed||controller.signal.aborted)break;if(s.done)continue;
   try{const p=await resolve(s.address,controller.signal);if(closed)break;if(validRoutePoint(p)){s.point={...p};add(s);}}catch{}
   if(closed)break;s.done=true;update();
  }
  if(!closed){fitAll();update();}
 })();
 return {ready,destroy(){closed=true;controller.abort();try{map?.remove();}catch{}}};
}

window.BipadoOverview={mountRouteOverview,swipeToMap};
