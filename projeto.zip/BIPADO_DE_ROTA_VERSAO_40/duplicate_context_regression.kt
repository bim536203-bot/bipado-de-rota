import br.com.leitorencomendas.*
fun main(){
 var count=0
 fun test(a:String,b:String,same:Boolean,possible:Boolean=false){
  check(AddressIdentity.same(a,b)==same){"same failed: $a / $b"}
  check(AddressIdentity.same(b,a)==same)
  check(AddressIdentity.possible(a,b)==possible){"possible failed: $a / $b"};count++
 }
 fun full(street:String,n:String="731",district:String="Pricumã",zip:String="69309-393")="$street, $n, Casa, $district, Boa Vista, RR, $zip, Brasil"
 for((a,b) in listOf("Av Via das Flores" to "Via das Flores","Rua Rua Exemplo" to "Rua Exemplo","Av. Alameda Teste" to "Alameda Teste","Tv Travessa Teste" to "Travessa Teste","Al Al. Alameda Teste" to "Alameda Teste"))test(full(a),full(b),true)
 test(full("Av. Via das Flores"),full("Via das Flores",zip="69309-394"),false)
 test(full("Via das Flores"),full("Via das Flores",district="Outro Bairro"),false)
 for(n in listOf("732","731A","731/2"))test(full("Via das Flores"),full("Via das Flores",n=n),false)
 test(full("Rua das Flores"),full("Alameda das Flores"),false,true)
 test(full("Via das Flores"),full("Via das Rosas"),false)
 test(full("Rua das das Flores"),full("Rua das Flores"),false,true)
 test("Rua Exemplo, 731","Alameda Exemplo, 731",false)
 test(full("Rua Exemplo"),full("Alameda Exemplo",zip="69309-394"),false)
 test("Rua Exemplo, 731, AP 01, Boa Vista, RR","R. Exemplo, 731, AP 02, Boa Vista, RR",true)
 test("Rua Via Láctea, 731","Via Láctea, 731",false)
 val parsed=AddressExtractor.parse(". 0 Av via das flores 731 Casa PRICUMA Boa Vista-RR 69309393")
 check(parsed.streetLine.startsWith("Via das Flores, 731")){parsed}
 check(CaptureAddressValidation.valid(". 0 Av via das flores 731 Casa PRICUMA Boa Vista-RR 69309393",parsed));count++
 check(CaptureScreenGuard.isOwnDialog("POSSÍVEL ENDEREÇO REPETIDO São locais diferentes VOLTAR"));count++
 check(CaptureScreenGuard.isOwnDialog("Digite apenas o nome da rua e o número da casa. SALVAR CANCELAR"));count++
 check(!CaptureScreenGuard.isOwnDialog("Rua Voltar 32 Boa Vista-RR 69317494"));count++
 println("Duplicate context: $count cases passed")
}
