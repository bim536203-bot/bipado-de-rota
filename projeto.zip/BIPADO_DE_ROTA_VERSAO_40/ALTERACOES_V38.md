# Versão 38 — interpretação da numeração J&T

Base V37 preservada.

- Repetições idênticas do número da residência são removidas após a leitura da rua; números diferentes continuam exigindo revisão.
- AP, APTO, apartamento, quarto e outros campos de unidade não são confundidos com o número da casa. Complementos antes da residência são separados da rua.
- Formatos como 78/3 são preservados na captura, busca, agrupamento e exportação/importação Android/iPhone, sem agrupá-los com 78 ou 78/4.
- O catálogo postal somente separa um complemento quando o nome completo da rua e o CEP coincidem; a regra genérica também funciona fora dele.
- Não altera layout, contas, sincronização, pacotes, contatos ou dados existentes.

## Verificação

Todos os sete textos enviados falhavam na V37. Com os ajustes, seis passam; o texto com 00 e outro número diferente continua pedindo revisão por ambiguidade real. Nenhuma tentativa de adivinhar o número. Testes públicos usam exemplos sintéticos, sem nomes/rastreios dos destinatários.

Adicionados testes Kotlin de leitura/segurança e teste JavaScript de identidade/busca/CSV com barra. Todas as regressões anteriores são executadas. A transcrição e geometria sintética não equivalem à execução de ML Kit num celular; essa validação física permanece pendente.
