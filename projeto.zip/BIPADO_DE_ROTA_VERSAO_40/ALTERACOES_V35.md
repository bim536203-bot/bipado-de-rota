# Versão 35 — recuperação da captura Android

Relato: após uma leitura com ENDEREÇO NÃO ENCONTRADO, as seguintes parecem falhar no Android de um amigo. O estado de endereço não encontrado é local à janela, e o parser não retém esse resultado entre chamadas. Sem diagnóstico do aparelho, não é possível confirmar a causa específica.

A investigação identificou um risco no fluxo de imagens: o listener do ImageReader era removido após cada captura, deixando imagens sem consumo entre bipes. A documentação Android alerta para atraso/parada quando as imagens não são obtidas e liberadas continuamente (https://developer.android.com/reference/android/media/ImageReader).

Correção: IdleFrameDrain libera imagens enquanto o serviço está ocioso, sem executar OCR nem salvar capturas. Pausa antes de preparar o próximo bipe e permanece pausado enquanto aguarda a imagem limpa; volta após entrega, cancelamento ou falha. Não descarta a única imagem limpa já enfileirada numa tela estática. Mantém uma única MediaProjection/VirtualDisplay e o descarte de respostas de sessões antigas.

CaptureScreenGuard reconhece combinações específicas dos avisos do próprio Bipado. Caso uma imagem antiga desses avisos chegue ao OCR, repete a captura uma única vez; se persistir, avisa sobre captura antiga em vez de criar outro ENDEREÇO NÃO ENCONTRADO. A evidência positiva de rua/número/cidade/CEP continua obrigatória; não converte endereço inválido em encontrado.

Regressões: fila limitada sem consumo reproduz backpressure; descarte ocioso evita acúmulo; callback antigo não consome imagem estática durante captura; sequência inválido→válido repetida 30 vezes no mesmo fluxo; identificação dos avisos do app e rejeição de textos normais; fechamento de leitor não derruba o worker.

Android/iOS mantêm o design aprovado, numeração e contatos. Spoke continua sem telefones; BAIXAR ROTAS continua com contatos. A correção de captura é exclusiva do Android porque iOS não captura outro aplicativo. Versões/cache seguem juntas em 35.

Aparelho físico, ML Kit real, tela J&T específica e o caso do amigo ainda requerem validação. Backup da versão 34 preservado no histórico/tag v34.

## Ampliação da leitura do cartão J&T

Recusas reproduzidas: CEP com espaços antes/depois do hífen, ponto ou traço Unicode; Roraima por extenso; ruas com data completa (Rua 13 de Setembro, Avenida 31 de Março); cidade/CEP em linhas alinhadas mais separadas. AddressOcrText normaliza somente apresentação, sem inventar dados, trocar letras por dígitos ou consultar rede. Ruas com data deixam de confundir o dia com o número da residência. OcrLayout permite uma distância extra limitada para localização alinhada, preservando fronteiras de rastreio, data e rodapé.

Kotlin/JVM real 1.9.24/Java 17: run-regression.sh completo passou, incluindo 557 layouts, 76 proteções de ícones, 128 verificações de aquisição de quadros e 232 de recuperação. A nova ocr_recall_regression.kt passou em 23 casos positivos/negativos; antes da correção, 11 positivos da primeira bateria reproduziam recusa. Inclui CEP etiquetado, estado por extenso, ruas com data, localização separada, ausência de dados, outro estado, letra no CEP, número ambíguo, segundo pacote, coluna diferente e bloco distante. São fixtures sintéticas, sem ML Kit real. Publicador inclui a nova suíte. Corrigidas as dependências do harness separado de recuperação.

Android assemble/lint, aparelho real e cartões específicos do amigo ainda não validados. Não é possível estimar taxa de acerto ou afirmar causa exata sem exemplos reais. Nenhuma publicação, APK, atualização remota ou commit GitHub da V35 foi feito; lote continua aberto para outros erros.

## Base postal de Pricumã indicada pelo usuário

Incorporados os 48 pares de logradouro/CEP do CEPs do Brasil nas sugestões offline Android/iOS e na conferência do OCR Android. Registro detalhado em PRICUMA_BASE_POSTAL.md e dados/proveniência em assets/pricuma-postcodes.json. Corrigidos metadados de 11 features locais com correspondência exata de nome/bairro; mantidos CEP OSM original, fonte postal e todas as 497 geometrias. Nenhuma coordenada de imóvel foi inventada. Resultados postais sem coordenadas não geram pins nem pontos confirmados.

PricumaPostal usa CEP observado para grafia/abreviação e no máximo uma letra diferente no nome, mantendo tipo da via e número do imóvel. Validação continua exigindo cidade/CEP efetivos; não preenche evidência ausente. iOS cacheia o novo módulo offline. Regressões específicas Kotlin: 160 verificações aprovadas; suíte JVM completa aprovada, preservando recuperação/ícones/limites de cartão. Regressões iOS cobrem 48 ruas offline e paridade com índice Kotlin, homônimos, geometrias/pontos e cache. Sem publicação e ainda requer aparelho real/build Android.
