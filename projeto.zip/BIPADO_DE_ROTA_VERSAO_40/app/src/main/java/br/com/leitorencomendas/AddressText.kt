package br.com.leitorencomendas

/** Removes only known OCR icon artefacts and adjacent repeated phrases. */
object AddressText {
 // Keep the last explicit road type: "Av Via ..." or "Rua Rua ...".
 // Never remove a lone type (Rua, Alameda and Via can name different roads).
 fun streetType(raw:String):String {
  val type=Regex("""(?i)^(?:ruas?|r\.?|avenidas?|av\.?|alamedas?|al\.?|travessas?|tv\.?|vias?)\s+(?=(?:ruas?|r\.?|avenidas?|av\.?|alamedas?|al\.?|travessas?|tv\.?|vias?)\s)""")
  var result=raw.trim()
  while(true){val m=type.find(result) ?: return result;result=result.substring(m.range.last+1)}
 }
 private val artefact=Regex("""\(\s*(?:t\s*\+?)?\s*\)""",RegexOption.IGNORE_CASE)
 private val business=Regex("""(?i)\b(?:sal[oó]n|sal[aã]o|oficina|hospital|resid[eê]ncia|casa|apartamento|loja)\b""")
 fun clean(raw:String):String {
  val tokens=artefact.replace(raw," ").trim().split(Regex("""\s+""")).filter {it.isNotBlank()}.toMutableList()
  var start=0
  while(start<tokens.size){
   var removed=false
   for(length in (tokens.size-start)/2 downTo 3){
    val a=tokens.subList(start,start+length).joinToString(" ")
    val b=tokens.subList(start+length,start+length*2).joinToString(" ")
    if(AddressIdentity.normalize(a)==AddressIdentity.normalize(b)){
     repeat(length){tokens.removeAt(start+length)};removed=true;break
    }
   }
   if(!removed)start++
  }
  return tokens.joinToString(" ").trim(' ',',')
 }
 fun splitStreet(prefix:String):Pair<String,String> {
  val cleaned=clean(prefix)
  val marker=business.find(cleaned)
  return if(marker!=null && marker.range.first>3)cleaned.substring(0,marker.range.first).trim(' ',',') to cleaned.substring(marker.range.first).trim()
   else cleaned to ""
 }
}
