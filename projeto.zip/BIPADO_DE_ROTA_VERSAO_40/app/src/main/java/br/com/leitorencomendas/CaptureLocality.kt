package br.com.leitorencomendas

/** Independent evidence retained from THIS parcel, even when its street cannot be parsed. */
object CaptureLocality {
 data class Result(val postcode:String="",val city:String="") {
  val locationLine:String get()=listOf(city,postcode).filter{it.isNotBlank()}.joinToString(", ")
  val displayLine:String get()=when {
   city.isNotBlank() && postcode.isNotBlank()->locationLine
   city.isNotBlank()->"$city • CEP não identificado"
   postcode.isNotBlank()->"CEP $postcode • cidade não identificada"
   else->"CEP e cidade não identificados — use o lápis"
  }
 }
 private val zip=Regex("""(?<!\d)(\d{5})-(\d{3})(?!\d)""")
 private val city=Regex("""(?i)\bBoa\s*Vista-RR\b""")
 fun from(ocr:String):Result {
  val text=AddressOcrText.normalize(ocr)
  val codes=zip.findAll(text).map{it.value}.distinct().toList()
  return Result(codes.singleOrNull().orEmpty(),if(city.containsMatchIn(text))"Boa Vista, RR" else "")
 }
 fun streetError(street:String,locality:Result):String? {
  if(locality.city.isBlank())return "Cidade não identificada. Use o lápis para revisar o endereço."
  if(street.none{it.isLetter()} || Regex("""(?<!\d)\d{5}[-.\s]?\d{3}(?!\d)""").containsMatchIn(street))
   return "Digite apenas o nome da rua e o número da casa"
  val house=Regex("""(?:^\d{1,5}(?:/\d{1,5})?[a-zA-Z]?\s*[, -]\s*.+|.+[\s,]\d{1,5}(?:/\d{1,5})?[a-zA-Z]?)$""")
  return if(street.length<8 || !house.matches(street))"Confira rua e número antes de salvar" else null
 }
}
