package br.com.leitorencomendas

import android.app.Dialog
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.EditText
import android.webkit.WebView

/** Only draw state changes; never intercept, postpone or replace a click listener. */
object TouchFeedback{
 fun install(root:View){
  fun scan(view:View){
   if(view.isClickable && view !is EditText && view !is WebView && view.getTag(R.id.touch_feedback_installed)!=true){
    view.setTag(R.id.touch_feedback_installed,true)
    view.foreground=StateListDrawable().apply{
     addState(intArrayOf(android.R.attr.state_pressed,android.R.attr.state_enabled),ColorDrawable(0x55216BE0))
     addState(intArrayOf(),ColorDrawable(Color.TRANSPARENT))
     setEnterFadeDuration(0);setExitFadeDuration(120)
    }
   }
   if(view is ViewGroup)for(i in 0 until view.childCount)scan(view.getChildAt(i))
  }
  scan(root)
  if(root.getTag(R.id.touch_feedback_root)==true)return
  root.setTag(R.id.touch_feedback_root,true)
  val listener=ViewTreeObserver.OnGlobalLayoutListener{scan(root)}
  root.viewTreeObserver.addOnGlobalLayoutListener(listener)
  root.addOnAttachStateChangeListener(object:View.OnAttachStateChangeListener{
   override fun onViewAttachedToWindow(v:View){}
   override fun onViewDetachedFromWindow(v:View){
    if(v.viewTreeObserver.isAlive)v.viewTreeObserver.removeOnGlobalLayoutListener(listener)
    v.setTag(R.id.touch_feedback_root,false);v.removeOnAttachStateChangeListener(this)
   }
  })
 }
}
fun <T:Dialog>T.showWithFeedback():T{show();window?.decorView?.let{TouchFeedback.install(it)};return this}
fun AlertDialog.Builder.showWithFeedback():AlertDialog=create().showWithFeedback()
