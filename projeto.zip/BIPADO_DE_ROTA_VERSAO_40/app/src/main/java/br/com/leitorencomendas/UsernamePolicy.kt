package br.com.leitorencomendas

/** Account names are literal identifiers: no trim, folding or normalization. */
object UsernamePolicy {
 fun valid(value:String):Boolean = value.length<=128 && value.any{!it.isWhitespace()} &&
  value.none{it.code in 0..31 || it.code in 127..159 || it.code in 0x200b..0x200f ||
   it.code in 0x202a..0x202e || it.code in 0x2060..0x206f || it.code==0xfeff}
 fun matches(actual:String,supplied:String):Boolean = valid(actual) && valid(supplied) && actual==supplied
 fun registration(first:String,repeated:String):String? = when {
  !valid(first)->"Informe um nome de usuário válido."
  !matches(first,repeated)->"Os nomes de usuário precisam ser exatamente iguais."
  else->null
 }
}
