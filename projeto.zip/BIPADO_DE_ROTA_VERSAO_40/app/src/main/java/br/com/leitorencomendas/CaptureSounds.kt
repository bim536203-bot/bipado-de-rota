package br.com.leitorencomendas

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import java.util.concurrent.ConcurrentHashMap

/** Load once at service start; showing a result never waits for audio preparation. */
class CaptureSounds(private val context:Context) {
 private val pool=SoundPool.Builder().setMaxStreams(1).setAudioAttributes(AudioAttributes.Builder()
  .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
 private val samples=mutableMapOf<Int,Int>()
 private val ready=ConcurrentHashMap.newKeySet<Int>()
 private var stream=0
 private var fallback:MediaPlayer?=null
 init {
  pool.setOnLoadCompleteListener{_,sample,status->if(status==0)ready.add(sample)}
  for(id in listOf(R.raw.bip_sucesso,R.raw.bip_erro,R.raw.bip_repetido))samples[id]=pool.load(context,id,1)
 }
 fun play(id:Int){
  try {
   fallback?.release();fallback=null
   val sample=samples[id]
   if(sample!=null && sample in ready){if(stream!=0)pool.stop(stream);stream=pool.play(sample,1f,1f,1,0,1f);return}
   // Rare first-tap fallback is asynchronous as well.
   val player=MediaPlayer();fallback=player
   val source=context.resources.openRawResourceFd(id) ?: run{player.release();fallback=null;return}
   source.use{player.setDataSource(it.fileDescriptor,it.startOffset,it.length)}
   player.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).build())
   player.setOnPreparedListener{if(fallback===it)it.start()}
   player.setOnCompletionListener{if(fallback===it)fallback=null;it.release()}
   player.setOnErrorListener{p,_,_->if(fallback===p)fallback=null;p.release();true}
   player.prepareAsync()
  }catch(_:Exception){fallback?.release();fallback=null}
 }
 fun release(){fallback?.release();fallback=null;pool.release();ready.clear()}
}
