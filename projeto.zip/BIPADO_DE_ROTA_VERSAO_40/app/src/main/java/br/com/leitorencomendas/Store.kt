package br.com.leitorencomendas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Todas as alterações de lista/histórico são gravadas em uma única transação de preferências. */
object Store {
 const val RETENTION_MS = 24L * 60L * 60L * 1000L
 var preferenceProvider:(Context)->android.content.SharedPreferences={it.getSharedPreferences("deliveries",0)}
 var persistOverride:((Context,JSONObject)->Boolean)?=null
 private fun prefs(c:Context) = preferenceProvider(c)
 private fun initial(c:Context):JSONObject {
  val legacy=prefs(c).getString("items","[]") ?: "[]"
  return JSONObject().put("items",try{JSONArray(legacy)}catch(_:Exception){JSONArray()}).put("history",JSONArray()).put("lastNumber",0)
 }
 @Synchronized private fun state(c:Context):JSONObject {
  val s=try{JSONObject(prefs(c).getString("state", "")!!)}catch(_:Exception){initial(c)}
  val h=s.optJSONArray("history") ?: JSONArray()
  val now=System.currentTimeMillis()
  val current=JSONArray()
  for(i in 0 until h.length()) {
   val item=h.optJSONObject(i) ?: continue
   val at=item.optLong("deletedAt",0)
   if(at>0 && at<=now && now-at<RETENTION_MS)current.put(item)
  }
  if(current.length()!=h.length()) {s.put("history",current);save(c,s)}
  return s
 }
 private fun save(c:Context,s:JSONObject):Boolean = persistOverride?.invoke(c,s) ?: prefs(c).edit().putString("state",s.toString()).commit()
 @Synchronized fun all(c:Context):JSONArray=JSONArray(state(c).optJSONArray("items")!!.toString())
 @Synchronized fun history(c:Context):JSONArray=JSONArray(state(c).optJSONArray("history")!!.toString())
 /** A token follows the captured parcel, not the largest number or imported route. */
 @Synchronized fun whatsappTarget(c:Context):JSONObject? {
  val s=state(c);val token=s.optString("lastCaptureToken");if(token.isBlank())return null
  val items=s.optJSONArray("items") ?: return null
  return (0 until items.length()).mapNotNull{items.optJSONObject(it)}.firstOrNull{it.optString("captureToken")==token}?.let{JSONObject(it.toString())}
 }
 @Synchronized fun saveWhatsappForLast(c:Context,phone:String,expectedToken:String?=null):String {
  val digits=WhatsappPolicy.normalize(phone) ?: return "Número inválido"
  val s=state(c);val token=s.optString("lastCaptureToken")
  if(token.isBlank())return "Nenhum pacote bipado nesta rota"
  if(expectedToken!=null && expectedToken!=token)return "O pacote mudou. Capture o WhatsApp novamente."
  val items=s.optJSONArray("items") ?: return "Nenhum pacote bipado"
  val item=(0 until items.length()).mapNotNull{items.optJSONObject(it)}.firstOrNull{it.optString("captureToken")==token}
   ?:return "Último pacote não encontrado"
  if(item.optString("whatsapp").isNotBlank())return "Whatsapp já foi salvo!!"
  item.put("whatsapp",digits)
  return if(save(c,s))"WhatsApp salvo no pacote ${item.optInt("number")}" else "Falha ao salvar WhatsApp"
 }
 private fun captured(s:JSONObject,item:JSONObject){
  val token=java.util.UUID.randomUUID().toString();item.put("captureToken",token);s.put("lastCaptureToken",token)
 }
 fun normalize(address:String)=AddressIdentity.normalize(address)
 fun matchingIndex(items:JSONArray,address:String,except:Int=-1):Int {
  val key=normalize(address)
  if(key.isBlank())return -1
  for(i in 0 until items.length())if(i!=except && AddressIdentity.same(items.optJSONObject(i)?.optString("address") ?: "",address))return i
  return -1
 }
 @Synchronized fun matching(c:Context,address:String):JSONObject? {
  val list=all(c);val index=matchingIndex(list,address)
  return if(index>=0)list.getJSONObject(index) else null
 }
 @Synchronized fun possibleMatch(c:Context,address:String):JSONObject? {
  val list=all(c)
  return (0 until list.length()).mapNotNull{list.optJSONObject(it)}.firstOrNull{AddressIdentity.possible(it.optString("address"),address)}
 }
 private fun highest(s:JSONObject):Int {
  val items=s.optJSONArray("items") ?: JSONArray()
  val skipped=s.optJSONArray("skipped") ?: JSONArray()
  // Empty active routes start again at 1, including states saved by older versions.
  if(items.length()==0 && skipped.length()==0)return 0
  var maximum=0 // Only numbers currently visible in the active saved list count.
  for(i in 0 until items.length()) maximum=maxOf(maximum,items.optJSONObject(i)?.optInt("number",0) ?: 0)
  for(i in 0 until skipped.length()) maximum=maxOf(maximum,skipped.optInt(i,0))
  return maximum
 }
 private fun next(s:JSONObject):Int {val highest=highest(s);return if(highest==Int.MAX_VALUE)0 else highest+1}
 @Synchronized fun nextNumber(c:Context):Int=next(state(c))
 /** Reserve exactly the current next number; never create a dummy address for a skipped package. */
 @Synchronized fun skipNext(c:Context,expected:Int):Boolean {
  val s=state(c)
  if(expected<=0 || expected!=next(s))return false
  val skips=s.optJSONArray("skipped") ?: JSONArray().also{s.put("skipped",it)}
  skips.put(expected)
  s.put("lastNumber",expected)
  return save(c,s)
 }
 @Synchronized fun removeSkipped(c:Context,number:Int):Boolean {
  val s=state(c);val old=s.optJSONArray("skipped") ?: return false
  val newer=JSONArray();var found=false
  for(i in 0 until old.length()){
   val n=old.optInt(i)
   if(n==number)found=true else newer.put(n)
  }
  if(!found)return false
  s.put("skipped",newer)
  if((s.optJSONArray("items")?.length() ?: 0)==0 && newer.length()==0)s.put("lastNumber",0)
  return save(c,s)
 }
 @Synchronized fun skipped(c:Context):JSONArray=JSONArray((state(c).optJSONArray("skipped") ?: JSONArray()).toString())
 /** Other saved parcels at this address, excluding this card and all skipped numbers. */
 fun relatedNumbers(items:JSONArray,number:Int):List<Int>{
  val entries=(0 until items.length()).mapNotNull {items.optJSONObject(it)}
  val anchor=entries.firstOrNull {it.optInt("number",0)==number} ?: return emptyList()
  val address=anchor.optString("address")
  return entries.filter {it.optInt("number",0)!=number && AddressIdentity.same(address,it.optString("address"))}
   .map {it.optInt("number",0)}.filter {it>0}.distinct().sorted()
 }
 /** A visible card keeps the first captured parcel as its anchor, even after renumbering. */
 data class AddressGroup(val indices:List<Int>,val numbers:List<Int>,val primaryNumber:Int,val address:String){
  val title:String get()="PACOTE "+numbers.joinToString("-")
 }
 fun addressGroups(items:JSONArray):List<AddressGroup>{
  data class Group(val address:String,val key:String?,val normalized:String,val indices:MutableList<Int>,val numbers:MutableList<Int>)
  val groups=mutableListOf<Group>()
  for(i in 0 until items.length()){
   val item=items.optJSONObject(i) ?: continue
   val address=item.optString("address")
   if(address.isBlank() || item.optBoolean("skipped",false))continue
   val n=item.optInt("number",i+1)
   if(n<=0)continue
   val key=AddressIdentity.key(address);val normalized=AddressIdentity.normalize(address)
   val group=groups.firstOrNull {g->g.indices.all{index->AddressIdentity.same(items.getJSONObject(index).optString("address"),address)}}
   if(group==null)groups.add(Group(address,key,normalized,mutableListOf(i),mutableListOf(n)))
   else {group.indices.add(i);group.numbers.add(n)}
  }
  return groups.map {AddressGroup(it.indices.toList(),it.numbers.distinct().sorted(),it.numbers.first(),it.address)}
 }
 /** The confirmation names the complete group; reject a stale dialog if membership changed. */
 @Synchronized fun removeGroup(c:Context,numbers:List<Int>):Boolean {
  if(numbers.isEmpty() || numbers.any{it<=0} || numbers.distinct().size!=numbers.size)return false
  val s=state(c);val items=s.optJSONArray("items") ?: return false
  val group=addressGroups(items).firstOrNull {it.numbers==numbers.sorted()} ?: return false
  val indices=group.indices.toSet();val newer=JSONArray()
  for(i in 0 until items.length())if(i !in indices)newer.put(items.getJSONObject(i))
  s.put("items",newer)
  if(newer.length()==0 && (s.optJSONArray("skipped")?.length() ?: 0)==0)s.put("lastNumber",0)
  return save(c,s)
 }
 @Synchronized fun sameAddressNumbers(c:Context,original:Int,current:Int):List<Int>{
  return (listOf(original,current)+relatedNumbers(all(c),original))
   .filter {it>0}.distinct().sorted()
 }
 /** Explicit user confirmation of another real parcel for a previously saved address. */
 @Synchronized fun addSameAddress(c:Context,original:Int,number:Int,bipped:Boolean=false):Boolean {
  val s=state(c);val items=s.optJSONArray("items") ?: return false
  if(number<=0 || number!=next(s))return false
  val anchor=(0 until items.length()).mapNotNull {items.optJSONObject(it)}
   .firstOrNull {it.optInt("number",0)==original} ?: return false
  val address=anchor.optString("address").trim()
  if(address.isBlank())return false
  items.put(JSONObject().put("address",address).put("number",number).put("createdAt",System.currentTimeMillis()).also{point(it,anchor.optDouble("latitude",Double.NaN),anchor.optDouble("longitude",Double.NaN),anchor.optString("pointPrecision"))})
  if(bipped)captured(s,items.getJSONObject(items.length()-1))
  s.put("lastNumber",number)
  return save(c,s)
 }

 private fun point(item:JSONObject,lat:Double,lon:Double,precision:String){
  if(lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0 && precision in setOf("house","place","manual")){
   item.put("latitude",lat).put("longitude",lon).put("pointPrecision",precision)
  }
 }
 @Synchronized fun add(c:Context,address:String,number:Int,lat:Double=Double.NaN,lon:Double=Double.NaN,precision:String="",bipped:Boolean=false):Boolean {
  val s=state(c);val a=s.optJSONArray("items")!!
  if(number<=0 || number!=next(s) || address.isBlank() || matchingIndex(a,address)>=0)return false
  for(i in 0 until a.length())if(a.getJSONObject(i).optInt("number",i+1)==number)return false
  a.put(JSONObject().put("address",address.trim()).put("number",number).put("createdAt",System.currentTimeMillis()).also{point(it,lat,lon,precision)})
  if(bipped)captured(s,a.getJSONObject(a.length()-1))
  s.put("lastNumber",number)
  return save(c,s)
 }
 /** Apagar tudo sempre faz snapshot antes de limpar. Exclusões individuais não entram no histórico. */
 @Synchronized fun clear(c:Context):Boolean {
  val s=state(c);val old=s.optJSONArray("items")!!
  if(old.length()==0 && (s.optJSONArray("skipped")?.length() ?: 0)==0){
   if(s.optInt("lastNumber",0)==0)return true
   s.put("lastNumber",0);return save(c,s)
  }
  val h=s.optJSONArray("history")!!
  h.put(JSONObject().put("deletedAt",System.currentTimeMillis()).put("items",JSONArray(old.toString())).put("skipped",JSONArray((s.optJSONArray("skipped") ?: JSONArray()).toString())))
  s.remove("lastCaptureToken");s.put("items",JSONArray());s.put("skipped",JSONArray());s.put("lastNumber",0);return save(c,s)
 }
 @Synchronized fun restore(c:Context,deletedAt:Long):Boolean {
  val s=state(c);val h=s.optJSONArray("history")!!
  val selected=(0 until h.length()).mapNotNull{h.optJSONObject(it)}.firstOrNull{it.optLong("deletedAt")==deletedAt} ?: return false
  val restoring=selected.optJSONArray("items") ?: return false
  if(restoring.length()==0 && (selected.optJSONArray("skipped")?.length() ?: 0)==0)return false
  val old=s.optJSONArray("items")!!
  if(old.length()>0 || (s.optJSONArray("skipped")?.length() ?: 0)>0)h.put(JSONObject().put("deletedAt",System.currentTimeMillis()).put("items",JSONArray(old.toString())).put("skipped",JSONArray((s.optJSONArray("skipped") ?: JSONArray()).toString())))
  s.remove("lastCaptureToken")
  s.put("items",JSONArray(restoring.toString()))
  s.put("skipped",JSONArray((selected.optJSONArray("skipped") ?: JSONArray()).toString()))
  s.put("lastNumber",highest(s))
  return save(c,s)
 }
 /** All-or-nothing CSV import. Old active list (and skipped placeholders) is retained in history. */
 @Synchronized fun replaceWithImport(c:Context,imported:JSONArray):Boolean {
  if(imported.length()==0)return false
  val seenNumbers=mutableSetOf<Int>()
  for(i in 0 until imported.length()) {
   val row=imported.optJSONObject(i) ?: return false
   val number=row.optInt("number",0)
   val address=row.optString("address","").trim()
   if(row.optString("whatsapp").isNotBlank() && WhatsappPolicy.normalize(row.optString("whatsapp"))==null)return false
   // Several real packages may intentionally share an address; only their numbers must be unique.
   if(number<=0 || !seenNumbers.add(number) || address.length<8)return false
  }
  val s=state(c)
  val old=s.optJSONArray("items") ?: JSONArray()
  val skips=s.optJSONArray("skipped") ?: JSONArray()
  if(old.length()>0 || skips.length()>0){
   val h=s.optJSONArray("history") ?: JSONArray().also{s.put("history",it)}
   h.put(JSONObject().put("deletedAt",System.currentTimeMillis()).put("items",JSONArray(old.toString())).put("skipped",JSONArray(skips.toString())))
  }
  s.remove("lastCaptureToken")
  s.put("items",JSONArray(imported.toString()))
  s.put("skipped",JSONArray())
  // A new imported route starts a new logical sequence.
  s.put("lastNumber",0)
  s.put("lastNumber",highest(s))
  return save(c,s)
 }

 @Synchronized fun deleteHistory(c:Context,deletedAt:Long):Boolean {
  val s=state(c);val h=s.optJSONArray("history")!!
  val newer=JSONArray()
  var removed=false
  for(i in 0 until h.length()) {
   val item=h.optJSONObject(i) ?: continue
   if(item.optLong("deletedAt") == deletedAt) removed=true else newer.put(item)
  }
  if(!removed)return false
  s.put("history",newer)
  return save(c,s)
 }

 @Synchronized fun remove(c:Context,index:Int):Boolean {
  val s=state(c);val a=s.optJSONArray("items")!!
  if(index !in 0 until a.length())return false
  val newer=JSONArray();for(i in 0 until a.length())if(i!=index)newer.put(a.getJSONObject(i))
  s.put("items",newer)
  if(newer.length()==0 && (s.optJSONArray("skipped")?.length() ?: 0)==0)s.put("lastNumber",0)
  return save(c,s)
 }
 @Synchronized fun edit(c:Context,index:Int,number:Int,address:String,lat:Double=Double.NaN,lon:Double=Double.NaN,precision:String="",expectedId:String?=null,expectedAddress:String?=null):Boolean {
  val s=state(c);val a=s.optJSONArray("items")!!
  if(index !in 0 until a.length())return false
  val current=a.getJSONObject(index)
  if(expectedId!=null&&current.optString("id")!=expectedId)return false
  if(expectedAddress!=null&&current.optString("address")!=expectedAddress)return false
  if(index !in 0 until a.length()||number<1||address.isBlank())return false
  val oldAddress=a.getJSONObject(index).optString("address")
  if(matchingIndex(a,address,index)>=0 && !AddressIdentity.same(oldAddress,address))return false
  val skips=s.optJSONArray("skipped") ?: JSONArray()
  if((0 until skips.length()).any{skips.optInt(it,0)==number})return false
  for(i in 0 until a.length())if(i!=index&&a.getJSONObject(i).optInt("number",i+1)==number)return false
  val item=a.getJSONObject(index)
  if(!AddressIdentity.same(oldAddress,address))for(key in listOf("latitude","longitude","pointPrecision","captureToken"))item.remove(key)
  point(item,lat,lon,precision)
  item.put("number",number).put("address",address.trim())
  s.put("lastNumber",highest(s))
  return save(c,s)
 }
}
