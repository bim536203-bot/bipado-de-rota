package br.com.leitorencomendas
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

object AccountDialog {
 fun show(a:Activity,register:Boolean=false){
  fun dp(n:Int)=(n*a.resources.displayMetrics.density).toInt()
  val panel=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),dp(12))}
  panel.addView(ImageView(a).apply{setImageResource(R.drawable.ic_account)},LinearLayout.LayoutParams(-1,dp(44)))
  val error=TextView(a).apply{setTextColor(0xFFD32929.toInt());visibility=View.GONE;setPadding(0,dp(8),0,dp(8))}
  val connected=AccountSync.name()
  val dialog=AlertDialog.Builder(a).setTitle(if(connected!=null&&!register)"Usuário conectado" else if(register)"Cadastrar novo usuário" else "Usuário").setView(panel).create()
  fun button(label:String,color:Int=0xFFE9EDF1.toInt(),action:()->Unit){panel.addView(Button(a).apply{text=label;backgroundTintList=android.content.res.ColorStateList.valueOf(color);setOnClickListener{action()}},LinearLayout.LayoutParams(-1,dp(50)).apply{topMargin=dp(7)})}
  if(connected!=null&&!register){
   panel.addView(TextView(a).apply{text=connected;textSize=21f;gravity=Gravity.CENTER;setTextColor(0xFF173768.toInt());setPadding(0,dp(10),0,dp(8))})
   panel.addView(TextView(a).apply{text=AccountSync.error.ifBlank{if(!AccountSync.online)"Sem conexão" else if(AccountSync.pending()>0)"Sincronizando alterações…" else "● Sincronizado"};gravity=Gravity.CENTER;setTextColor(0xFF197B45.toInt())})
   panel.addView(TextView(a).apply{text="${Store.all(a).length()} pacotes na conta\nHistórico de listas apagadas sincronizado";setPadding(0,dp(18),0,dp(15));textSize=16f})
   button("SAIR"){try{AccountSync.logout();dialog.dismiss()}catch(_:Exception){Toast.makeText(a,"Não foi possível sair. Tente novamente.",Toast.LENGTH_LONG).show()}}
   button("FECHAR"){dialog.dismiss()}
  }else{
   fun field(label:String):EditText{panel.addView(TextView(a).apply{text=label;setPadding(0,dp(12),0,dp(4));setTextColor(0xFF173768.toInt())});val e=EditText(a).apply{setSingleLine(true);inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;filters=arrayOf(android.text.InputFilter.LengthFilter(128))};panel.addView(e);return e}
   val first=field("Nome de usuário");val repeat=if(register)field("Repita o nome de usuário") else null
   panel.addView(error)
   button("CONFIRMAR",0xFFDDF3E5.toInt()){
    error.visibility=View.GONE;for(i in 0 until panel.childCount)panel.getChildAt(i).isEnabled=false
    dialog.setCancelable(false)
    AccountSync.enter(first.text.toString(),repeat?.text?.toString()){message->
     if(a.isFinishing)return@enter
     if(message==null)dialog.dismiss() else {error.text=message;error.visibility=View.VISIBLE;for(i in 0 until panel.childCount)panel.getChildAt(i).isEnabled=true;dialog.setCancelable(true)}
    }
   }
   if(!register)button("CADASTRAR NOVO USUÁRIO",0xFFDBEAFF.toInt()){dialog.dismiss();show(a,true)}
   button("CANCELAR"){dialog.dismiss()}
  }
  dialog.showWithFeedback()
 }
}
