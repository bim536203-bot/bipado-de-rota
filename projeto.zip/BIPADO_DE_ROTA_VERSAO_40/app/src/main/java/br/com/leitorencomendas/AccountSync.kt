package br.com.leitorencomendas
import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.CopyOnWriteArraySet

object AccountSync {
 private const val URL_BASE="https://fowgukvmtzldfhshevff.supabase.co"
 private const val API_KEY="sb_publishable_YXUT7_7VVKR8MAmYbl2FCA_j54dB235"
 private lateinit var app:Application
 private val ui=Handler(Looper.getMainLooper())
 private val worker=Executors.newSingleThreadScheduledExecutor()
 private val http=OkHttpClient.Builder().connectTimeout(7,TimeUnit.SECONDS).readTimeout(13,TimeUnit.SECONDS).callTimeout(15,TimeUnit.SECONDS).build()
 private var socket:WebSocket?=null
 private val listeners=CopyOnWriteArraySet<()->Unit>()
 @Volatile private var active:JSONObject?=null
 @Volatile private var generation=0
 @Volatile private var working=false
 @Volatile var online=false;private set
 @Volatile var error="";private set
 private var foreground=0
 private var lastRead=0L
 private var lastBeat=0L
 private fun config()=app.getSharedPreferences("bipado_account_session",0)
 private fun prefs(id:String)=app.getSharedPreferences("bipado_account_"+id,0)
 fun scope():Int=generation
 fun name():String?=active?.optString("name")
 fun pending():Int=active?.let{prefs(it.getString("id")).getString("pending","[]")?.let{raw->JSONArray(raw).length()}}?:0
 fun install(application:Application){
  app=application
  active=try{JSONObject(config().getString("session","")!!)}catch(_:Exception){null}
  Store.preferenceProvider={c->active?.let{prefs(it.getString("id"))}?:c.getSharedPreferences("deliveries",0)}
  Store.persistOverride={_,s->persist(s)}
  worker.scheduleWithFixedDelay({if(active!=null&&(foreground>0||CaptureService.active))flush()},1,3,TimeUnit.SECONDS)
  app.registerActivityLifecycleCallbacks(object:Application.ActivityLifecycleCallbacks{
   override fun onActivityStarted(a:Activity){foreground++;kick()}
   override fun onActivityStopped(a:Activity){foreground--;if(foreground<=0&&!CaptureService.active){socket?.close(1000,"background");socket=null;online=false}}
   override fun onActivityCreated(a:Activity,b:Bundle?){}
   override fun onActivityResumed(a:Activity){}
   override fun onActivityPaused(a:Activity){}
   override fun onActivitySaveInstanceState(a:Activity,b:Bundle){}
   override fun onActivityDestroyed(a:Activity){}
  })
 }
 fun bind(activity:Activity,refresh:()->Unit){
  listeners.add(refresh)
  val callback=object:Application.ActivityLifecycleCallbacks{
   override fun onActivityDestroyed(a:Activity){if(a===activity){listeners.remove(refresh);app.unregisterActivityLifecycleCallbacks(this)}}
   override fun onActivityCreated(a:Activity,b:Bundle?){}
   override fun onActivityStarted(a:Activity){}
   override fun onActivityResumed(a:Activity){if(a===activity)refresh()}
   override fun onActivityPaused(a:Activity){}
   override fun onActivityStopped(a:Activity){}
   override fun onActivitySaveInstanceState(a:Activity,b:Bundle){}
  };app.registerActivityLifecycleCallbacks(callback)
 }
 private fun emit(){ui.post{listeners.forEach{it()}}}
 private fun request(body:JSONObject,token:String?=null):JSONObject{
  val b=Request.Builder().url(URL_BASE+"/functions/v1/bipado-sync").header("apikey",API_KEY)
  if(token!=null)b.header("Authorization","Bearer $token")
  http.newCall(b.post(body.toString().toRequestBody("application/json".toMediaType())).build()).execute().use{r->
   val data=JSONObject(r.body?.string()?:"{}");if(!r.isSuccessful)throw IllegalStateException(data.optString("error","Não foi possível sincronizar."));return data
  }
 }
 private fun persist(s:JSONObject):Boolean{
  val who=active?:return app.getSharedPreferences("deliveries",0).edit().putString("state",s.toString()).commit()
  val p=prefs(who.getString("id"));val old=JSONObject(p.getString("state","{}")!!)
  val before=AccountWire.ensureIds(old);val after=AccountWire.ensureIds(s).put("revision",before.optLong("revision")+1)
  val queue=JSONArray(p.getString("pending","[]"));if(queue.length()>=500)return false
  queue.put(JSONObject().put("operation",UUID.randomUUID().toString()).put("before",AccountWire.toWire(before)).put("after",AccountWire.toWire(after)))
  val ok=p.edit().putString("state",after.toString()).putString("pending",queue.toString()).commit()
  if(ok){emit();kick()};return ok
 }
 fun enter(name:String,repeated:String?,done:(String?)->Unit){
  val validation=if(repeated==null)if(UsernamePolicy.valid(name))null else "Usuário incorreto." else UsernamePolicy.registration(name,repeated)
  if(validation!=null){done(validation);return}
  app.stopService(Intent(app,CaptureService::class.java))
  worker.execute{
   try{
    val body=JSONObject().put("action",if(repeated==null)"login" else "register").put("name",name);if(repeated!=null)body.put("repeat",repeated)
    val account=request(body);synchronized(Store){
     val p=prefs(account.getString("id"));val queue=JSONArray(p.getString("pending","[]"))
     if(queue.length()==0){val old=try{JSONObject(p.getString("state","{}")!!)}catch(_:Exception){JSONObject()};val state=AccountWire.fromWire(account.getJSONObject("state")).put("revision",old.optLong("revision")+1)
      check(p.edit().putString("state",state.toString()).putLong("serverRevision",account.getLong("revision")).putString("pending","[]").commit())}
     val session=JSONObject().put("id",account.getString("id")).put("name",account.getString("name")).put("topic",account.getString("topic")).put("token",account.getString("token"))
     check(config().edit().putString("session",session.toString()).commit());generation++;socket?.close(1000,"switch");socket=null;active=session;online=true;error=""
    };emit();ui.post{done(null)};flush()
   }catch(e:Exception){ui.post{done(e.message?:"Não foi possível entrar. Confira a conexão.")}}
  }
 }
 fun logout(){
  app.stopService(Intent(app,CaptureService::class.java))
  val old:JSONObject?;synchronized(Store){old=active;check(config().edit().remove("session").commit());generation++;active=null;online=false;error="";socket?.close(1000,"logout");socket=null}
  emit();old?.let{worker.execute{try{request(JSONObject().put("action","logout"),it.getString("token"))}catch(_:Exception){}}}
 }
 fun kick(){worker.execute{flush()}}
 private fun connect(who:JSONObject,epoch:Int){
  if(socket!=null||generation!=epoch)return
  val topic="realtime:bipado:"+who.getString("topic")
  socket=http.newWebSocket(Request.Builder().url(URL_BASE.replace("https:","wss:")+"/realtime/v1/websocket?apikey=$API_KEY&vsn=1.0.0").build(),object:WebSocketListener(){
   override fun onOpen(ws:WebSocket,r:Response){if(generation!=epoch){ws.close(1000,"old session");return};ws.send(JSONObject().put("topic",topic).put("event","phx_join").put("payload",JSONObject().put("config",JSONObject().put("broadcast",JSONObject().put("ack",false).put("self",false)).put("presence",JSONObject().put("enabled",false)).put("private",false))).put("ref","1").put("join_ref","1").toString())}
   override fun onMessage(ws:WebSocket,text:String){if(generation!=epoch)return;try{val data=JSONObject(text);if(data.optString("event")=="broadcast"){lastRead=0;kick()}}catch(_:Exception){}}
   override fun onClosed(ws:WebSocket,code:Int,reason:String){if(generation==epoch)socket=null}
   override fun onFailure(ws:WebSocket,t:Throwable,r:Response?){if(generation==epoch)socket=null}
  })
 }
 private fun flush(){
  if(working)return;val who=active?:return;val epoch=generation;working=true
  val oldOnline=online;val oldError=error;var changed=false
  try{
   connect(who,epoch);val now=System.currentTimeMillis()
   if(now-lastBeat>25000){socket?.send(JSONObject().put("topic","phoenix").put("event","heartbeat").put("payload",JSONObject()).put("ref",now.toString()).toString());lastBeat=now}
   var result:JSONObject?=null
   for(n in 0..49){
    if(epoch!=generation)return
    val p=prefs(who.getString("id"));val queue=synchronized(Store){JSONArray(p.getString("pending","[]"))}
    if(queue.length()==0){if(now-lastRead>15000||result!=null)result=request(JSONObject().put("action","read"),who.getString("token"));break}
    val op=queue.getJSONObject(0);result=request(JSONObject(op.toString()).put("action","change"),who.getString("token"))
    synchronized(Store){
     if(epoch!=generation)return
     val live=JSONArray(p.getString("pending","[]"));if(live.length()>0&&live.getJSONObject(0).getString("operation")==op.getString("operation")){
      live.remove(0);val editor=p.edit().putString("pending",live.toString()).putLong("serverRevision",result!!.getLong("revision"))
      if(live.length()==0){val old=JSONObject(p.getString("state","{}")!!);editor.putString("state",AccountWire.fromWire(result!!.getJSONObject("state"),old.optString("lastCaptureToken")).put("revision",old.optLong("revision")+1).toString())}
      check(editor.commit());changed=true
     }
    }
   }
   if(epoch!=generation)return
   result?.let{response->synchronized(Store){
    val p=prefs(who.getString("id"));if(epoch==generation&&JSONArray(p.getString("pending","[]")).length()==0&&response.getLong("revision")>p.getLong("serverRevision",-1)){
     val old=JSONObject(p.getString("state","{}")!!);check(p.edit().putString("state",AccountWire.fromWire(response.getJSONObject("state"),old.optString("lastCaptureToken")).put("revision",old.optLong("revision")+1).toString()).putLong("serverRevision",response.getLong("revision")).commit());changed=true
    }
   };lastRead=now}
   online=true;error="";if(changed||oldOnline!=online||oldError!=error)emit()
  }catch(e:Exception){if(epoch==generation){online=false;error=e.message?:"Sem conexão para sincronizar.";if(oldOnline!=online||oldError!=error)emit()}}
  finally{working=false}
 }
}
