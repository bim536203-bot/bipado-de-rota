package br.com.leitorencomendas
import java.text.Normalizer
import java.util.Locale
object AddressIdentity {
 fun normalize(address:String):String {
  var x=Normalizer.normalize(address.lowercase(Locale.forLanguageTag("pt-BR")),Normalizer.Form.NFD).replace(Regex("\\p{M}+"),"")
  x=x.replace(Regex("\\b(?:avenidas?|av)\\.?\\b")," avenida ")
   .replace(Regex("\\b(?:ruas?|r)\\.?\\b")," rua ")
   .replace(Regex("\\b(?:travessas?|tv)\\.?\\b")," travessa ")
   .replace(Regex("\\b(?:alamedas?|al)\\.?\\b")," alameda ")
   .replace(Regex("\\b(?:vias?)\\b")," via ")
   .replace(Regex("\\bbrasil\\b")," ")
  return x.replace(Regex("[^a-z0-9]")," ").replace(Regex("\\s+")," ").trim()
 }
 private data class KeyBox(val key:String?)
 private val keys=object:LinkedHashMap<String,KeyBox>(160,.75f,true){override fun removeEldestEntry(e:MutableMap.MutableEntry<String,KeyBox>)=size>512}
 fun key(address:String):String?=synchronized(keys){keys[address]?.key ?: computeKey(address).also{keys[address]=KeyBox(it)}}
 private fun computeKey(address:String):String? {
  val cleaned=AddressText.clean(address)
  val parts=cleaned.split(',')
  val house=Regex("""^\s*(\d{1,5}(?:/\d{1,5})?[a-zA-Z]?)\s*$""")
  if(parts.size>=2){
   val number=house.matchEntire(parts[1])?.groupValues?.get(1)
   if(number!=null){val street=normalize(AddressText.streetType(AddressText.splitStreet(parts[0]).first));if(street.any{it.isLetter()})return street+"|"+number.lowercase(Locale.ROOT)}
  }
  val segment=cleaned.substringBefore(',').trim()
  val found=Regex("""^(.+?)\s+(\d{1,5}(?:/\d{1,5})?[a-zA-Z]?)(?:\s|$)""").find(segment) ?: return null
  val street=normalize(AddressText.streetType(AddressText.splitStreet(found.groupValues[1]).first))
  if(street.length<4 || !street.any{it.isLetter()})return null
  return street+"|"+found.groupValues[2].lowercase(Locale.ROOT)
 }
 fun same(a:String,b:String):Boolean {
  if(conflicts(a,b))return false
  val ka=key(a);val kb=key(b)
  // A mixed prefix can also be part of a real road name. Require postal agreement
  // before equating a different spelling solely through that cleanup.
  val ma=locality(a).mixed;val mb=locality(b).mixed
  if(ka!=null && ka==kb && ma!=mb && (ma!=null || mb!=null)){
   val x=locality(a);val y=locality(b)
   if(x.postcode.isBlank() || x.postcode!=y.postcode)return false
  }
  return if(ka!=null && kb!=null)ka==kb else normalize(a).isNotBlank() && normalize(a)==normalize(b)
 }
 private data class Locality(val postcode:String,val district:String,val mixed:String?)
 private val localityCache=object:LinkedHashMap<String,Locality>(160,.75f,true){override fun removeEldestEntry(e:MutableMap.MutableEntry<String,Locality>)=size>512}
 private fun locality(address:String):Locality=synchronized(localityCache){localityCache[address] ?: run {
  val code=Regex("""(?<!\d)(\d{5})[-.\s]?(\d{3})(?!\d)""").find(address)?.let{it.groupValues[1]+it.groupValues[2]}.orEmpty()
  val city=Regex("""(?i)\bBoa\s+Vista\s*[,/-]?\s*RR\b""").find(address)
  val prefix=city?.let{address.substring(0,it.range.first).trim(' ',',','—','-')}.orEmpty()
  val district=if('—' in prefix)prefix.substringAfterLast('—').trim() else {
   val parts=prefix.split(',');if(parts.size>=3)parts.last().trim() else ""
  }
  val safe=if(Regex("""(?i)^(?:casa|ap\b|apto|apartamento|bloco|quadra|lote|quarto|sala|loja|oficina|resid[eê]ncia|fundos)""").containsMatchIn(district))"" else normalize(district)
  val words=normalize(address).split(' ');val types=setOf("rua","avenida","alameda","travessa","via")
  val mixed=if(words.size>1 && words[0] in types && words[1] in types && words[0]!=words[1])words.take(2).joinToString(" ") else null
  Locality(code,safe,mixed).also{localityCache[address]=it}
 }}
 private fun conflicts(a:String,b:String):Boolean {
  val x=locality(a);val y=locality(b)
  return (x.postcode.isNotBlank() && y.postcode.isNotBlank() && x.postcode!=y.postcode) ||
   (x.district.isNotBlank() && y.district.isNotBlank() && x.district!=y.district)
 }
 /** Only suggest review; never merge different road types automatically. */
 fun possible(a:String,b:String):Boolean {
  if(same(a,b) || conflicts(a,b))return false
  val ka=key(a) ?: return false;val kb=key(b) ?: return false
  if(ka.substringAfterLast('|')!=kb.substringAfterLast('|'))return false
  fun name(k:String)=k.substringBeforeLast('|').replace(Regex("""^(?:rua|avenida|alameda|travessa|via)\s+"""),"").replace(Regex("""\b([a-z]+)\s+\1\b"""),"$1")
  if(name(ka)!=name(kb))return false
  val x=locality(a);val y=locality(b)
  return (x.postcode.isNotBlank() && x.postcode==y.postcode) || (x.district.isNotBlank() && x.district==y.district)
 }
}
