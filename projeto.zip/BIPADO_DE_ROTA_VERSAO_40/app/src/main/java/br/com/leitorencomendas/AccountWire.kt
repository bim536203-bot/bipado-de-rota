package br.com.leitorencomendas
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object AccountWire {
 private fun rows(a:JSONArray?,wire:Boolean):JSONArray {
  val out=JSONArray()
  for(i in 0 until (a?.length()?:0)){
   val row=JSONObject(a!!.getJSONObject(i).toString())
   if(row.optString("id").isBlank())row.put("id",UUID.randomUUID().toString())
   if(wire){
    val lat=row.optDouble("latitude",Double.NaN);val lon=row.optDouble("longitude",Double.NaN);val precision=row.optString("pointPrecision")
    if(lat.isFinite()&&lon.isFinite()&&precision in setOf("house","place","manual"))row.put("point",JSONObject().put("lat",lat).put("lon",lon).put("precision",precision))
    row.remove("latitude");row.remove("longitude");row.remove("pointPrecision")
   }else{
    row.optJSONObject("point")?.let{point->row.put("latitude",point.getDouble("lat")).put("longitude",point.getDouble("lon")).put("pointPrecision",point.getString("precision"))}
    row.remove("point")
   }
   out.put(row)
  };return out
 }
 fun ensureIds(s:JSONObject):JSONObject{
  s.put("items",rows(s.optJSONArray("items"),false))
  val h=s.optJSONArray("history")?:JSONArray()
  for(i in 0 until h.length()){val snap=h.getJSONObject(i);if(snap.optString("id").isBlank())snap.put("id",UUID.randomUUID().toString());snap.put("items",rows(snap.optJSONArray("items"),false))}
  s.put("history",h);if(!s.has("skipped"))s.put("skipped",JSONArray());return s
 }
 fun toWire(s:JSONObject):JSONObject{
  val result=JSONObject(s.toString());result.put("schema",1).put("revision",s.optLong("revision",0)).put("items",rows(s.optJSONArray("items"),true))
  val history=JSONArray();val h=s.optJSONArray("history")?:JSONArray()
  for(i in 0 until h.length()){val snap=JSONObject(h.getJSONObject(i).toString());snap.put("items",rows(snap.optJSONArray("items"),true));history.put(snap)}
  result.put("history",history);if(!result.has("skipped"))result.put("skipped",JSONArray());result.remove("lastCaptureToken");return result
 }
 fun fromWire(s:JSONObject,lastToken:String=""):JSONObject{
  val result=JSONObject(s.toString()).put("items",rows(s.optJSONArray("items"),false));val h=s.optJSONArray("history")?:JSONArray();val history=JSONArray()
  for(i in 0 until h.length()){val snap=JSONObject(h.getJSONObject(i).toString());snap.put("items",rows(snap.optJSONArray("items"),false));history.put(snap)}
  result.put("history",history)
  val a=result.getJSONArray("items");if(lastToken.isNotBlank()&&(0 until a.length()).any{a.getJSONObject(it).optString("captureToken")==lastToken})result.put("lastCaptureToken",lastToken)
  return result
 }
}
