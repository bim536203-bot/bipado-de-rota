package br.com.leitorencomendas

/** Keep a screen producer flowing between captures. All calls use its image handler.
 * Pause BEFORE preparing a capture: a queued clean static frame must never be drained.
 */
internal class IdleFrameDrain<T:AutoCloseable>(
 private val acquireLatest:()->T?,
 private val subscribe:(()->Unit)->Unit,
 private val unsubscribe:()->Unit
){
 private var paused=true
 private var closed=false
 fun resume(){
  if(closed || !paused)return
  paused=false
  try{subscribe{drain()};drain()}catch(_:Exception){paused=true}
 }
 private fun drain(){if(!paused && !closed)try{acquireLatest()?.close()}catch(_:Exception){}}
 fun pause(){
  if(closed)return
  paused=true
  unsubscribe()
 }
 fun close(){
  if(closed)return
  paused=true;closed=true
  try{unsubscribe()}catch(_:Exception){}
 }
}
