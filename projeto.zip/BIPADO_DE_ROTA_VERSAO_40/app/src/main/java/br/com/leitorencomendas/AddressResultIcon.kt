package br.com.leitorencomendas

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Status graphic; no map or coordinate claim is needed to confirm address text. */
class AddressResultIcon(context:Context,found:Boolean):View(context){
 var found=found
  set(value){field=value;invalidate()}
 private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
 override fun onDraw(canvas:Canvas){
  super.onDraw(canvas)
  val size=minOf(width,height).toFloat();val save=canvas.save()
  canvas.translate((width-size)/2,(height-size)/2);canvas.scale(size/100,size/100)
  paint.style=Paint.Style.FILL;paint.color=if(found)0xFF198038.toInt() else 0xFFE51C32.toInt()
  if(found)canvas.drawCircle(50f,50f,48f,paint)
  paint.style=Paint.Style.STROKE;paint.strokeWidth=if(found)9f else 13f
  paint.strokeCap=Paint.Cap.SQUARE;paint.strokeJoin=Paint.Join.MITER
  if(found){
   paint.color=Color.WHITE
   canvas.drawPath(Path().apply{moveTo(28f,51f);lineTo(43f,66f);lineTo(73f,34f)},paint)
  }else{
   canvas.drawLine(18f,18f,82f,82f,paint);canvas.drawLine(82f,18f,18f,82f,paint)
  }
  canvas.restoreToCount(save)
 }
}
