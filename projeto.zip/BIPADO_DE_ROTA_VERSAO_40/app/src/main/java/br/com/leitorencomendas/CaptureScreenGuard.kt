package br.com.leitorencomendas

import java.text.Normalizer
import java.util.Locale

/** Detect our own stale dialog, never relax positive evidence for parcel addresses. */
object CaptureScreenGuard{
 fun isOwnDialog(text:String):Boolean{
  val s=Normalizer.normalize(text.lowercase(Locale.ROOT),Normalizer.Form.NFD)
   .replace(Regex("""\p{M}+"""),"").replace(Regex("""[^a-z0-9]+""")," ").trim()
  val parcel=Regex("""\bpacote\s+\d+\b""").containsMatchIn(s)
  val cancel=Regex("""\bcancelar\b""").containsMatchIn(s)
  return (parcel && cancel && (
   (s.contains("endereco nao encontrado") && s.contains("pular para pacote")) ||
   (s.contains("endereco encontrado com sucesso") && s.contains("confirmar"))
  )) || ((s.contains("esse endereco ja foi bipado") || s.contains("endereco ja bipado")) && s.contains("voltar") && s.contains("pular para pacote")) ||
   (s.contains("possivel endereco repetido") && s.contains("sao locais diferentes") && s.contains("voltar")) ||
   (s.contains("digite apenas o nome da rua e o numero da casa") && s.contains("salvar") && cancel) ||
   (cancel && s.contains("adicionar endereco") && s.contains("toque fora do endereco para desmarcar"))
 }
}
