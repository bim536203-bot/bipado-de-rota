package br.com.leitorencomendas

import java.text.Normalizer
import java.util.Locale

/** Postal facts only, no house coordinates. Generated from assets/pricuma-postcodes.json.
 * CEPs do Brasil / Pricumã, retrieved 2026-10-20; source revision February 2026.
 */
object PricumaPostal {
 data class Entry(val street:String,val postcode:String)
 val entries:List<Entry> = listOf(
  Entry("Alameda das Acácias","69309-360"),
  Entry("Alameda das Hortências","69309-510"),
  Entry("Alameda das Onze Horas","69309-570"),
  Entry("Alameda das Orquídeas","69309-580"),
  Entry("Alameda dos Girassóis","69309-490"),
  Entry("Avenida das Vitórias Régias","69309-710"),
  Entry("Rua Azaléias","69309-460"),
  Entry("Rua Botão-de-ouro","69309-365"),
  Entry("Rua das Acácias","69309-370"),
  Entry("Rua das Bacabas","69309-390"),
  Entry("Rua das Bromélias","69309-400"),
  Entry("Rua das Camélias","69309-410"),
  Entry("Rua das Campainhas","69309-470"),
  Entry("Rua das Dálias","69309-430"),
  Entry("Rua das Damas da Noite","69309-440"),
  Entry("Rua das Extremosas","69309-700"),
  Entry("Rua das Flores de Cera","69309-412"),
  Entry("Rua das Hortências","69309-500"),
  Entry("Rua das Margaridas","69309-550"),
  Entry("Rua das Mil Flores","69309-560"),
  Entry("Rua das Mozendras","69309-414"),
  Entry("Rua das Orquídeas","69309-590"),
  Entry("Rua das Palmas de Santa Rita","69309-415"),
  Entry("Rua das Palmeiras","69309-600"),
  Entry("Rua das Papoulas","69309-610"),
  Entry("Rua das Petúnias","69309-620"),
  Entry("Rua das Quaresmeiras","69309-450"),
  Entry("Rua das Rosas","69309-630"),
  Entry("Rua das Três Marias","69309-670"),
  Entry("Rua das Tulipas","69309-530"),
  Entry("Rua dos Cravos","69309-420"),
  Entry("Rua dos Crisântemos","69309-660"),
  Entry("Rua dos Gerânios","69309-416"),
  Entry("Rua dos Hibiscos","69309-411"),
  Entry("Rua dos Lírios","69309-540"),
  Entry("Rua dos Tajás","69309-640"),
  Entry("Rua dos Taxis","69309-650"),
  Entry("Rua dos Trevos-de-quatro-folhas","69309-680"),
  Entry("Rua Flor do Campo","69309-480"),
  Entry("Rua Jackson de Barros Villa","69309-385"),
  Entry("Rua Lady Laura","69309-520"),
  Entry("Rua Nelson Albuquerque","69309-330"),
  Entry("Rua Osman da Rocha Bríglia","69309-361"),
  Entry("Rua Pastor Almir Nogueira Guerra","69309-413"),
  Entry("Rua Risos-do-Prado","69309-373"),
  Entry("Rua Rosa Pardana","69309-514"),
  Entry("Travessa das Orquídeas","69309-593"),
  Entry("Via das Acácias","69309-380")
 )
 private fun normalized(s:String)=Normalizer.normalize(s.lowercase(Locale.ROOT),Normalizer.Form.NFD)
  .replace(Regex("""\p{M}+"""),"").replace(Regex("""[^a-z0-9]+""")," ").trim()
 private fun words(s:String)=normalized(s).split(' ').filter {it.isNotBlank()}.map {when(it){"r"->"rua";"av"->"avenida";"al"->"alameda";"tv"->"travessa";else->it}}
 private val types=setOf("rua","avenida","alameda","travessa","via")
 fun exact(street:String):Entry? = entries.singleOrNull {words(it.street)==words(street)}
 fun suggestions(fragment:String):List<Entry>{
  val tokens=words(fragment);val content=tokens.filter {it !in types && it !in setOf("de","da","do","das","dos")}
  val wanted=content.ifEmpty {tokens.filter {it in types}}.ifEmpty {tokens}
  if(wanted.isEmpty())return emptyList()
  return entries.filter {e->val available=words(e.street);wanted.all {w->available.any {it.startsWith(w)}}}
   .sortedWith(compareBy<Entry>{words(it.street).filter {w->w !in types && w !in setOf("de","da","do","das","dos")}.joinToString(" ")}.thenBy {normalized(it.street)})
 }
 private fun oneEdit(a:String,b:String):Boolean {
  if(kotlin.math.abs(a.length-b.length)>1)return false
  var i=0;var j=0;var edits=0
  while(i<a.length && j<b.length){
   if(a[i]==b[j]){i++;j++;continue}
   if(++edits>1)return false
   if(a.length>=b.length)i++
   if(b.length>=a.length)j++
  }
  return edits+(a.length-i)+(b.length-j)<=1
 }
 /** A visible exact CEP must agree; never infer the house number, city or missing CEP. */
 fun canonicalStreet(observed:String,postcode:String):String? {
  val target=entries.singleOrNull {it.postcode==postcode} ?: return null
  exact(observed)?.let {return if(it==target)it.street else null}
  val a=words(observed);val b=words(target.street)
  if(a.isEmpty())return null
  val typed=a.first() in types
  if(typed && a.first()!=b.first())return null // Rua != Alameda != Via
  val observedName=(if(typed)a.drop(1) else a).joinToString(" ")
  val expectedName=b.drop(1).joinToString(" ")
  if(observedName==expectedName || (observedName.length>=8 && oneEdit(observedName,expectedName)))return target.street
  return null
 }
}
