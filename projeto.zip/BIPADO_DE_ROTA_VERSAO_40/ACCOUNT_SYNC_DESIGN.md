# V37 — usuários e sincronização

Base V36 preservada. Novo projeto dedicado Bipado de Rota em São Paulo: fowgukvmtzldfhshevff. Nenhuma tabela do projeto Silva Locação foi alterada.

## Identidade
Entrada somente pelo nome literal, conforme solicitado: maiúsculas, espaços, acentos e símbolos são significativos. Cadastro repete o nome e a restrição única do PostgreSQL impede duplicatas concorrentes. Não há PIN ou senha: conhecer o nome permite acessar a conta, por escolha explícita do proprietário. Controles invisíveis e nomes vazios são recusados.

## Armazenamento e sincronização
Modo local e cada conta têm armazenamento separado em SharedPreferences/IndexedDB. Entrar não envia os dados locais à conta; sair restaura o modo local. Filas de operações duráveis, identificadores estáveis e confirmação idempotente preservam alterações diante de falhas de rede.

Servidor recebe diferenças de snapshots e combina alterações por pacote/campo. Capturas simultâneas ganham números distintos; exclusão remota vence edição antiga. Exclusão da lista arquiva também capturas concorrentes no histórico. Histórico conserva a retenção existente de 24 horas.

As alterações notificam clientes por WebSocket; consultas periódicas e reconexão recuperam notificações perdidas. Sem internet, dados locais da conta continuam disponíveis e mudanças ficam pendentes. Não é possível cadastrar/entrar pela primeira vez sem conexão.

Tokens opacos internos são armazenados pelo cliente e apenas seus hashes no servidor. As tabelas possuem RLS sem acesso direto público; somente a função intermediária, com validação da sessão, lê/escreve os dados. A chave administrativa existe apenas nas variáveis do servidor. O canal aleatório de notificações carrega apenas a revisão, sem endereços ou contatos.

## Validação
Testes locais de isolamento local40/conta30, modo offline, nomes literais e concorrência. Teste no servidor real de cadastro, duplicação, dois acessos, pacote, histórico, restauração, repetição idempotente e revogação na saída. Testes Kotlin verificam conversão de pontos/contatos/histórico e isolamento do último bipe por aparelho. Compilação e lint Android pelo fluxo de publicação. Validação em Android/iPhone físicos ainda necessária.
