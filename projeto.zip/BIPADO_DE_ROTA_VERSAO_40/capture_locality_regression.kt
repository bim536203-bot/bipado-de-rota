import br.com.leitorencomendas.*

fun main(){
 var count=0
 fun checkCase(ok:Boolean){check(ok){"Locality case ${count+1} failed"};count++}
 for(text in listOf("texto misturado Boa Vista-RR 69317494","Boa Vista / RR CEP 69317-494","Boa\nVista-RR\n69317\n494")){
  val result=CaptureLocality.from(text)
  checkCase(result.locationLine=="Boa Vista, RR, 69317-494")
 }
 val good=CaptureLocality.from("Boa Vista-RR 69317-494")
 checkCase(CaptureLocality.from("Rua ilegível Boa Vista-RR").postcode.isEmpty())
 checkCase(CaptureLocality.from("69317-494").city.isEmpty())
 checkCase(CaptureLocality.from("Boa Vista-RR 69317494 69314218").postcode.isEmpty())
 checkCase(CaptureLocality.from("Boa Vista-RR 69317494 69317-494").postcode=="69317-494")
 checkCase(CaptureLocality.from("888002664420697").postcode.isEmpty())
 checkCase(CaptureLocality.from("").locationLine.isEmpty())
 checkCase(CaptureLocality.from("Boa Vista-RR").displayLine.contains("CEP não identificado"))
 for(street in listOf("Rua Capricórnio, 250","Capricórnio 250","250 Rua Capricórnio","Rua Exemplo, 98/2","Rua Exemplo, 18A"))
  checkCase(CaptureLocality.streetError(street,good)==null)
 for(street in listOf("","Rua Capricórnio","250","Rua 7 de Setembro","Rua Exemplo 69317-494"))
  checkCase(CaptureLocality.streetError(street,good)!=null)
 checkCase(CaptureLocality.streetError("Rua Exemplo 25",CaptureLocality.Result("69317-494"))!=null)
 fun row(t:String,y:Int)=OcrLayout.Span(t,20,y,600,y+20)
 val spans=listOf(row("888002664420697",20),row("Destinatário",55),row("ilegível",90),row("Boa Vista-RR 69317494",125),row("2026-10-22 09:00:00",165),row("888002664420698",210),row("Outro destinatário",245),row("Boa Vista-RR 69314218",280))
 checkCase(CaptureLocality.from(OcrLayout.selectLocality(spans,800,1000))==good)
 checkCase(OcrLayout.selectLocality(spans.drop(1).take(3),800,1000).isEmpty())
 val boundary=listOf(row("888002664420697",20),row("Destinatário",55),row("2026-10-22 09:00:00",90),row("Boa Vista-RR 69317494",150))
 checkCase(CaptureLocality.from(OcrLayout.selectLocality(boundary,800,1000)).postcode.isEmpty())
 checkCase(OcrLayout.selectLocality(spans,0,1000).isEmpty())
 println("Capture locality: $count cases passed")
}
