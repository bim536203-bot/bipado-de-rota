# Versão 33

- Confirmação de endereço encontrado: mini mapa substituído por check verde e “ENDEREÇO ENCONTRADO COM SUCESSO!”. Endereço, CEP, lápis, CANCELAR e CONFIRMAR preservados; somente confirmar salva.
- Endereço não encontrado: X vermelho e “ENDEREÇO NÃO ENCONTRADO!” em vermelho; sem mapa, caixa preta ou frase explicativa duplicada. Lápis, cidade/UF, CANCELAR e PULAR PARA PACOTE mantidos, com numeração dinâmica.
- Endereços salvos: botão EXPORTAR PARA ROTA SPOKE em cinza escuro; ícones/texto e integração CSV preservados.
- WhatsApp: vetor contido na área de desenho e espaço para o deslocamento superior, corrigindo o topo cortado.
- Android e iOS: resposta visual imediata ao pressionar, com retorno rápido à cor original. Não espera a animação para executar a ação; controles desativados não respondem. Diálogos e controles adicionados dinamicamente incluídos.
- Busca de endereço e consulta de coordenadas continuam; confirmação sem mapa não carrega tiles. Somente coordenadas verificadas (casa/local/ajuste manual) podem ser salvas; ponto aproximado da rua não é inventado como casa.
- Android mantém captura/arraste conjunto do bipador e WhatsApp; iOS mantém contatos importados por CSV, sem captura Android.

Backup: fonte e release da versão 32 preservados no histórico/tag v32. Testes DOM/CSV/histórico/toque e regressões de Android executados na publicação. Aparência, teclado, OCR e comportamento em Android/iPhone físicos ainda exigem validação nos aparelhos.
