import br.com.leitorencomendas.AddressExtractor as A
import br.com.leitorencomendas.CaptureAddressValidation as V
fun main(){
 val city="PRICUMA Boa Vista-RR 69309500"
 val uncertain=listOf("Rua das Hortências 1 512 Casa $city","Rua das Mil Flores 1\n444 Casa $city","Rua das Hortências T 512 Casa $city")
 for(raw in uncertain){val r=A.parse(raw);check(r.streetLine.isBlank() && !V.valid(raw,r)){"Ambiguous capture accepted: $raw => $r"}}
 val valid=listOf("Rua 13 de Setembro 100 Casa $city","Rua das Hortências 512 Casa $city","Rua das Mil Flores 444 Casa $city","Rua T 512 Casa $city","Rua das Rosas 1 Casa $city","Rua das Rosas 447 Apartamento 2 $city")
 for(raw in valid){val r=A.parse(raw);check(r.streetLine.isNotBlank() && V.valid(raw,r)){"Valid capture refused: $raw => $r"}}
 println("${uncertain.size+valid.size} OCR house-number/suffix safety cases passed")
}
