# Versão 40

- Compara variações gerais de prefixos de rua, como Av Via, Rua Rua e Av Alameda. Prefixos mistos exigem CEP concordante para equivalência automática; não remove indiscriminadamente o tipo da rua. Número, sufixo e barra da residência continuam distintos. Bairro/CEP explícitos incompatíveis não são agrupados.
- Quando apenas o tipo da rua ou uma palavra repetida difere e o contexto concorda, mostra POSSÍVEL ENDEREÇO REPETIDO para revisão. O usuário decide se é o mesmo local. Cada pacote mantém seu número; cartões e CSV usam a mesma regra nas duas plataformas.
- CANCELAR ao lado de SALVAR na correção rápida Android fecha somente a entrada e mantém a confirmação original, pacote, cidade e CEP.
- Som próprio para repetição: três notas ascendentes curtas, diferente de sucesso/erro. Áudio também disponível no pacote offline iOS.
- Agilidade Android: SoundPool pré-carregado, fallback assíncrono; cache limitado de identidades; segunda seleção de localidade só quando necessária; diagnóstico de falha não segura a apresentação do resultado. Mantém os pixels originais, ML Kit, espera pelo quadro limpo e as validações de OCR.

## Verificação

Regressões Kotlin anteriores aprovadas; 21 casos novos de repetição/contexto; 49 verificações de cartões/agrupamentos; Store, CSV, contatos e AccountWire aprovados. Node local: 63 testes, 61 aprovados e dois testes online dependentes de ambiente pulados; o CI roda os testes online. Dez testes do publicador aprovados.

Benchmark local de 4.800 comparações repetidas de endereço: V39 665,4 ms e V40 2,84 ms, com 30 correspondências em ambas. Mede apenas comparação aquecida, não captura de tela nem ML Kit. Não representa o ganho do bipe inteiro no celular.

A leitura, teclado, volume e reprodução do novo som precisam de conferência em celular físico. Não foi possível reproduzir ML Kit num aparelho real neste ambiente. Servidor e banco não alterados; dados antigos preservados.
