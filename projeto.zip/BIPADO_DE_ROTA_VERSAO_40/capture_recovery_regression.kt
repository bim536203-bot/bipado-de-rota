package br.com.leitorencomendas

private class ScreenFrame(val label:String):AutoCloseable{
 var closed=0
 override fun close(){check(closed==0){"Frame closed twice"};closed++}
}
private class ScreenQueue{
 val queue=mutableListOf<ScreenFrame>()
 var listener:(()->Unit)?=null
 var stalls=0
 fun produce(frame:ScreenFrame){
  if(queue.size>=3){stalls++;frame.close();return}
  queue+=frame;listener?.invoke()
 }
 fun latest():ScreenFrame?{
  if(queue.isEmpty())return null
  val last=queue.removeAt(queue.lastIndex)
  queue.forEach{it.close()};queue.clear();return last
 }
}
fun main(){
 var checks=0
 fun verify(v:Boolean){check(v);checks++}
 // Reproduce a bounded producer queue without a consumer between taps.
 run{
  val screen=ScreenQueue();repeat(8){screen.produce(ScreenFrame("old warning $it"))}
  verify(screen.stalls==5);verify(screen.queue.size==3)
  val idle=IdleFrameDrain(screen::latest,{screen.listener=it},{screen.listener=null})
  idle.resume();verify(screen.queue.isEmpty()) // also consumes images queued before listener
  repeat(20){screen.produce(ScreenFrame("current parcel $it"))}
  verify(screen.stalls==5);verify(screen.queue.isEmpty());idle.close()
 }
 // A stale idle callback must not consume the only queued clean frame on a frozen screen.
 run{
  val screen=ScreenQueue();val idle=IdleFrameDrain(screen::latest,{screen.listener=it},{screen.listener=null});idle.resume()
  val queuedIdleCallback=screen.listener!!;idle.pause()
  var got:ScreenFrame?=null
  val request=FrameAcquisition(screen::latest,{screen.listener=it},{idle.resume()},{got=it;it.close()},{throw it})
  verify(request.prepare());val clean=ScreenFrame("VALID ADDRESS");screen.produce(clean)
  queuedIdleCallback();verify(clean.closed==0)
  request.awaitFrame();verify(got===clean);verify(clean.closed==1)
  screen.produce(ScreenFrame("warning after capture"));verify(screen.queue.isEmpty());idle.close()
 }
 // Same stream and recognizer selection: failed parcel then valid parcel, repeated many times.
 run{
  val screen=ScreenQueue();val idle=IdleFrameDrain(screen::latest,{screen.listener=it},{screen.listener=null});idle.resume()
  repeat(30){i->
   val invalid="Não há endereço neste pacote"
   val valid="Rua das Rosas 447 Casa PRICUMA Boa Vista-RR 69309500"
   for(text in listOf(invalid,valid)){
    screen.produce(ScreenFrame("idle old dialog"));idle.pause();var accepted=false
    val request=FrameAcquisition(screen::latest,{screen.listener=it},{idle.resume()},{frame->
     accepted=CaptureAddressValidation.valid(frame.label,AddressExtractor.parse(frame.label));frame.close()
    },{throw it})
    verify(request.prepare());screen.produce(ScreenFrame(text));request.awaitFrame()
    verify(accepted==(text==valid));verify(screen.queue.isEmpty())
   }
   verify(screen.stalls==0)
  }
  val old=screen.listener!!;idle.close();old();val f=ScreenFrame("after stop");screen.produce(f);verify(f.closed==0);screen.latest()?.close()
 }
 // A reader closed by rotation/stop must not crash the capture worker.
 run{
  var subscriptions=0
  val idle=IdleFrameDrain<ScreenFrame>({null},{subscriptions++;throw IllegalStateException("closed reader")},{throw IllegalStateException("closed reader")})
  idle.resume();idle.resume();verify(subscriptions==2);idle.close();idle.resume();verify(subscriptions==2)
 }
 val own=listOf(
  "Pacote 3 Boa Vista, RR ENDEREÇO NÃO ENCONTRADO! CANCELAR PULAR PARA PACOTE 4",
  "Pacote 4 Rua Exemplo 28 ENDEREÇO ENCONTRADO COM SUCESSO! CANCELAR CONFIRMAR",
  "ESSE ENDEREÇO JÁ FOI BIPADO! VOLTAR PULAR PARA PACOTE 9",
  "Adicionar endereço Toque fora do endereço para desmarcar CANCELAR SALVAR"
 )
 for(text in own)verify(CaptureScreenGuard.isOwnDialog(text))
 for(text in listOf("Rua das Rosas 447 Casa Pricumã Boa Vista-RR 69309500","Endereço não encontrado","Pacote 3 Rua Cancelar 12 Boa Vista-RR 69309500","J&T cancelar pedido confirmar entrega","Rua do Sucesso 4 Boa Vista RR 69300000"))verify(!CaptureScreenGuard.isOwnDialog(text))
 println("Capture recovery: $checks checks passed (bounded queue, paused drain/static frame, invalid then valid repeatedly, own-dialog detection; not a physical-device reproduction)")
}
