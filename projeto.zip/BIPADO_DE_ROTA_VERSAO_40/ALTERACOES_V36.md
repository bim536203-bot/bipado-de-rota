# Versão 36 — remoção do mapa dos salvos

Removida a nova aba demonstrativa, o botão MAPA e o gesto de arrastar a tela no Android e iOS, conforme pedido. Removidos Activity, bridge, resolver exclusivo, recursos JS/CSS/HTML e testes exclusivos da função retirada. O service worker usa cache 36 sem esses recursos. Links antigos #map voltam à tela inicial.

Preservados reconhecimento J&T, recuperação entre bipes, base postal de Pricumã, busca por fragmentos, dados, numeração, contatos e exportação Spoke sem telefones. Os componentes de busca e edição de endereços permanecem. A retirada não constitui medição de desempenho nem confirma que a tela causava travamentos.

V35 permanece no histórico como backup. As notas da V35 descrevem a função antiga, removida nesta V36. Build e publicação passam pelo workflow antes da entrega. Validação em aparelhos físicos pendente.
