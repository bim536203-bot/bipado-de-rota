import br.com.leitorencomendas.AddressExtractor as A
import br.com.leitorencomendas.CaptureAddressValidation as V
import br.com.leitorencomendas.OcrLayout as L
import kotlin.math.roundToInt

// Simulated ML Kit element rectangles. These are layout replays, not live OCR/emulator tests.
private data class Example(val words:String,val expected:String,val postcode:String)
private fun card(e:Example,width:Int,height:Int,font:Int,left:Int,top:Int,side:Boolean,icon:String="T"):List<L.Span>{
 val spans=mutableListOf<L.Span>()
 val lineHeight=(font*1.6).roundToInt()
 fun add(t:String,x:Int,y:Int,w:Int=(t.length*font*.52).roundToInt().coerceAtLeast(1)) {
  spans.add(L.Span(t,x,y,x+w,y+font))
 }
 val actionWidth=if(side)(font*8) else 0
 val edge=width-font-actionWidth
 require(edge-left>font*5)
 var x=left;var y=top
 add("999882349674385",left,top-lineHeight*4)
 add("Cliente",left,top-lineHeight*2)
 add("Teste",left+font*4,top-lineHeight*2)
 for(word in e.words.split(' ')){
  val w=(word.length*font*.52).roundToInt()
  if(x>left && x+w>edge){x=left;y+=lineHeight}
  add(word,x,y,w);x+=w+(font*.3).roundToInt()
 }
 if(side){
  val iconX=edge+font
  add(icon,iconX,top+lineHeight,font)
  add("navegação",iconX+font*2,top+lineHeight)
  add("(®)",iconX,top+lineHeight*3,font)
  add("telefone",iconX+font*2,top+lineHeight*3)
 }
 add("2026-10-16",left,y+lineHeight)
 add("08:45:02",left+font*6,y+lineHeight)
 add("WhatsApp",left,y+lineHeight*3)
 add("Assinar",width-font*5,y+lineHeight*3)
 require(spans.maxOf {it.bottom}<height){"Fixture doesn't fit $width x $height font=$font"}
 return spans
}
fun main(){
 var n=0
 val examples=listOf(
  Example("Rua dos Narcisos 141 PRICUMA Boa Vista-RR 69309397","Rua dos Narcisos, 141 — Pricumã","69309-397"),
  Example("Rua das Rosas 447 Casa PRICUMA Boa Vista-RR 69309630","Rua das Rosas, 447, Casa — Pricumã","69309-630"),
  Example("Rua dos Taxis 180 Casa PRICUMA Boa Vista-RR 69309650","Rua dos Taxis, 180, Casa — Pricumã","69309-650"),
  Example("rua das rosas 356 casa PRICUMA Boa Vista-RR 69309630","Rua das Rosas, 356, Casa — Pricumã","69309-630"),
  Example("Rua das Mil Flores 444 Casa PRICUMA Boa Vista-RR 69309560","Rua das Mil Flores, 444, Casa — Pricumã","69309-560"),
  Example("Rua das Hortências 512 Casa PRICUMA Boa Vista-RR 69309500","Rua das Hortências, 512, Casa — Pricumã","69309-500")
 )
 fun verify(spans:List<L.Span>,w:Int,h:Int,e:Example,label:String){
  val s=L.select(spans,w,h);val p=A.parse(s.text)
  check(p.streetLine==e.expected && p.locationLine.endsWith(e.postcode) && V.valid(s.text,p)) {"$label => $s => $p"}
  check(!s.text.contains("Cliente") && !s.text.contains("navegação") && !s.text.contains("telefone"))
  n++
 }
 // Independent width, height and FONT changes cause different wrapping, not just scaled rectangles.
 for((w,h) in listOf(720 to 1280,1080 to 1920,1080 to 2400,1440 to 3200,1920 to 1080)){
  for(font in listOf(20,28,40))for(e in examples)for(side in listOf(false,true)){
   val spans=card(e,w,h,font,font,(font*8),side)
   for(seed in 0..2)verify(spans.shuffled(kotlin.random.Random(seed)),w,h,e,"$w x $h font=$font side=$side seed=$seed")
  }
 }
 // A shifted/mirrored card whose text starts beyond the old 72% boundary remains readable.
 val shifted=card(examples[1],1080,2400,20,810,350,false)
 verify(shifted,1080,2400,examples[1],"right-aligned card beyond 72%")
 // An address near the top/bottom of a tall frame, outside the old 8%-96% strip.
 val normal=card(examples[0],1080,2400,24,50,300,false)
 for(offset in listOf(-280,1950)){
  val moved=normal.map {it.copy(top=it.top+offset,bottom=it.bottom+offset)}
  verify(moved,1080,2600,examples[0],"vertical offset $offset")
 }
 // Compact side icons read as T or 1 must not become street suffixes or house numbers.
 for(icon in listOf("T","1","(T)","(ph)")){
  verify(card(examples[5],1080,2400,28,60,400,true,icon),1080,2400,examples[5],"side icon $icon")
 }
 // A legitimate T in the street itself is preserved, even with a navigation action on the same row.
 val legit=Example("Rua T 512 Casa PRICUMA Boa Vista-RR 69309500","Rua T, 512, Casa — Pricumã","69309-500")
 verify(card(legit,1080,2400,28,60,400,true),1080,2400,legit,"legitimate letter T")
 // Abbreviations and untyped streets still use the parcel card, not header/name text.
 for(e in listOf(
  Example("R. das Rosas 447 Casa PRICUMA Boa Vista-RR 69309630","Rua das Rosas, 447, Casa — Pricumã","69309-630"),
  Example("das Tres Marias 707 Vila PRICUMA Boa Vista-RR 69309670","Rua das Três Marias, 707, Vila — Pricumã","69309-670")
 )){
  val spans=card(e,1080,2400,28,60,400,false)
  verify(spans,1080,2400,e,"untyped/abbreviated")
 }
 // A real single-digit house number at the address margin must not be mistaken for an icon.
 val single=Example("Rua das Rosas 1 Casa PRICUMA Boa Vista-RR 69309630","Rua das Rosas, 1, Casa — Pricumã","69309-630")
 val singleSpans=listOf(
  L.Span("Rua das Rosas",60,400,350,428),L.Span("1",60,445,78,473),
  L.Span("navegação",145,445,315,473),
  L.Span("Casa PRICUMA Boa",60,490,400,518),L.Span("Vista-RR 69309630",60,535,400,563))
 verify(singleSpans,1080,2400,single,"single-digit house beside action without OCR icon")
 // Large accessibility text can reflow the address into many short rows.
 verify(card(examples[5],720,2560,80,30,600,false),720,2560,examples[5],"large accessibility font")
 // Missing actual city or CEP never becomes positive evidence just because parsing supplies defaults.
 for(missing in listOf("Boa Vista-RR","69309630")){
  val bad=examples[1].copy(words=examples[1].words.replace(missing,""))
  val s=L.select(card(bad,1080,2400,28,60,400,false),1080,2400)
  check(!V.valid(s.text,A.parse(s.text)));n++
 }
 // A second parcel cannot supply the missing first parcel address/CEP.
 val first=listOf(L.Span("999882349674385",60,200,500,230),L.Span("Cliente",60,260,220,290),L.Span("2026-10-16",60,310,270,340))
 val second=card(examples[1],1080,2400,28,60,650,false)
 check(L.select(first+second,1080,2400).text.isBlank());n++
 check(L.select(emptyList(),1080,2400).text.isBlank());n++
 check(L.select(normal,0,2400).text.isBlank());n++
 println("$n responsive parcel layout cases passed (synthetic geometry; not live ML Kit)")
}
