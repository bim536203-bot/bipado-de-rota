import br.com.leitorencomendas.AddressExtractor as A
import br.com.leitorencomendas.CaptureAddressValidation as V
import br.com.leitorencomendas.OcrLayout as L

// Synthetic OCR text/geometry fixtures, not real ML Kit captures or a device acceptance test.
fun main(){
 var count=0
 val failures=mutableListOf<String>()
 fun verify(raw:String,street:String,label:String){
  val r=A.parse(raw)
  if(r.streetLine!=street || !r.locationLine.endsWith("69309-360") || !V.valid(raw,r))failures+="$label => $r"
  count++
 }
 val expected="Rua das Acácias, 587, Casa — Pricumã"
 for(sep in listOf("-"," - "," . "," – ","\n-\n","\u00a0-\u00a0")){
  verify("Rua das Acácias 587 Casa PRICUMA Boa Vista-RR 69309${sep}360",expected,"CEP separator [$sep]")
 }
 verify("Rua das Acácias 587 Casa PRICUMA Boa Vista-RR CEP: 69309 - 360",expected,"explicit CEP label")
 for(city in listOf("Boa Vista - Roraima","BOA VISTA / RORAIMA","Boa Vista,\nRR","Boa Vista – RR")){
  verify("Rua das Acácias 587 Casa PRICUMA $city 69309360",expected,"city [$city]")
 }
 verify("Rua 13 de Setembro 100 Casa PRICUMA Boa Vista-RR 69309360","Rua 13 de Setembro, 100, Casa — Pricumã","numeric date street")
 verify("Avenida 31 de Março 28 Casa PRICUMA Boa Vista-RR 69309360","Avenida 31 de Março, 28, Casa — Pricumã","numeric date avenue")
 // City/CEP on separate, aligned rows within the same parcel card.
 fun row(s:String,y:Int,left:Int=60)=L.Span(s,left,y,left+s.length*12,y+24)
 val parcel=listOf(row("999882349674385",160),row("Cliente Teste",210),row("Rua das Acácias 587 Casa PRICUMA",260),row("Boa Vista - Roraima",400),row("69309 - 360",440),row("2026-10-20",490),row("WhatsApp",550))
 val selection=L.select(parcel,1080,1920)
 verify(selection.text,expected,"spaced location rows")
 // A later parcel must never repair the earlier one, even when location is aligned.
 val boundary=listOf(row("999882349674385",160),row("Cliente Teste",210),row("Rua das Acácias 587 Casa PRICUMA",260),row("2026-10-20",310),row("999882349674386",350),row("Boa Vista RR 69309360",400))
 val invalids=listOf(
  "Rua das Acácias 587 Casa PRICUMA 69309360", // absent actual city/state
  "Rua das Acácias 587 Casa PRICUMA Boa Vista RR", // absent CEP
  "Rua das Acácias 587 Casa PRICUMA Boa Vista AM 69309360", // different state
  "Rua das Acácias 587 Casa PRICUMA Boa Vista RR 693O9-360", // letter is not a digit
  "Rua das Acácias 1 587 Casa PRICUMA Boa Vista RR 69309360", // possible icon/number ambiguity
  "Rua 13 de Setembro Casa PRICUMA Boa Vista RR 69309360", // street date is not house number
  L.select(boundary,1080,1920).text,
  L.select(parcel.map {if(it.text.contains("Boa Vista") || it.text.contains("69309"))it.copy(left=700,right=1000) else it},1080,1920).text, // unrelated column
  L.select(parcel.map {if(it.top>=400)it.copy(top=it.top+150,bottom=it.bottom+150) else it},1080,1920).text // distant block
 )
 for(raw in invalids){if(V.valid(raw,A.parse(raw)))failures+="Unsafe acceptance: $raw";count++}
 check(failures.isEmpty()){failures.joinToString("\n")}
 println("OCR recall: $count text/layout and negative safety cases passed (synthetic fixtures; no physical device)")
}
