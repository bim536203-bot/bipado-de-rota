# Versão 39

Na captura Android, CEP e cidade são identificados separadamente da rua no mesmo cartão J&T. Quando o endereço não é reconhecido, a linha de localidade fica clicável e preserva os dados identificados.

Ao tocar, aparece apenas a instrução “Digite apenas o nome da rua e o número da casa.”, um campo e o botão SALVAR. SALVAR modifica somente o rascunho da confirmação existente: mantém o número do pacote, mostra o endereço corrigido, CEP e cidade, símbolo verde e botão CONFIRMAR. Somente CONFIRMAR grava o pacote.

Não inventa CEP ausente ou ambíguo. A busca pelo lápis continua disponível. A leitura de localidade respeita limites de cartão, datas e rastreios para não usar o CEP do próximo pacote. Trocas de usuário invalidam a janela antiga.

O iPhone recebe a identificação da versão 39, mantendo as funções existentes; captura de tela J&T continua exclusiva Android. Não altera servidor, banco, sincronização nem formato de exportação.

Verificação: regressões de localidade/CEP, limites entre cartões e entrada manual, além dos testes anteriores. O fluxo de teclado e captura real ainda precisa ser conferido em celular físico.
