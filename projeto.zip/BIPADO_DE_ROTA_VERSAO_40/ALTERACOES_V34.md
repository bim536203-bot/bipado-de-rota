# Versão 34

Corrige a exportação destinada ao Spoke no Android e iOS: ROTA_PARA_SPOKE.csv contém apenas Address e Notes com os números reais dos pacotes. Não inclui os campos WA/telefones.

BAIXAR ROTAS mantém o formato completo e os contatos WhatsApp para transferência/importação entre aparelhos. Os dados salvos não são alterados, e agrupamento, ordem, numeração, design e integração de compartilhamento são preservados.

Validação: regressões Kotlin, fixture CSV gerada pelo Android comparada ao iOS, testes de exportação com vários contatos/grupos e teste dos dois botões usando a implementação DOM e compartilhamento simulado. Validar no celular a importação do novo arquivo no Spoke. Rotas já importadas anteriormente no Spoke não são modificadas automaticamente; para remover as notas antigas, importe o novo arquivo sem contatos.

Backup: versão 33 preservada no histórico/tag v33.
