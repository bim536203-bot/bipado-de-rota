import br.com.leitorencomendas.AddressExtractor
fun main() {
 val samples=listOf(
  Triple("Carla Souza\nBuritis . Avenidas dos a bandeirante\n189 BURITIS Boa Vista-RR\n69309186\n2026-10-10 17:30:52", "Avenidas dos a Bandeirante, 189 — Buritis","69309-186"),
  Triple("Amanda Ferreira\nBuritis . Antônio Pimheiro Galvão\n1762 Residencia BURITIS Boa Vista-RR 69309209", "Antônio Pimheiro Galvão, 1762, Residencia — Buritis","69309-209"),
  Triple("gaby\nVia das Flores 261 casa PRICUMA\nBoa Vista-RR 69309393", "Via das Flores, 261, Casa — Pricumã","69309-393"),
  Triple("claudia surez\ndas tres marias 707 vila PRICUMA\nBoa Vista-RR 69309670", "Rua das Três Marias, 707, Vila — Pricumã","69309-670"),
  Triple("Rua das Palmeiras 50 BURITIS Boa Vista-RR 69309186", "Rua das Palmeiras, 50 — Buritis","69309-186")
 )
 samples.forEachIndexed { index, (raw,street,code)->
  val found=AddressExtractor.parse(raw)
  check(found.streetLine==street) {"Sample $index street: $found"}
  check(found.locationLine.endsWith(code)) {"Sample $index CEP: $found"}
 }
 val header="Número único\n9471866\nprocurar\n888002609471866\n"+samples[0].first
 check(AddressExtractor.parse(header)==AddressExtractor.parse(samples[0].first)) {"Search leaked into street"}
 val fullCard="""Número único
9471866
procurar
888002609471866
Carla Souza
Buritis . Avenidas dos a bandeirante
189 BURITIS Boa Vista-RR
69309186
2026-10-10 17:30:52
WhatsApp"""
 val parsed=AddressExtractor.parse(fullCard)
 check(parsed.streetLine=="Avenidas dos a Bandeirante, 189 — Buritis") {"Customer name leaked: $parsed"}
 check(!parsed.streetLine.contains("Carla Souza"))
 val noisy="""999882266218143
gaby
Via das Flores 261 casa PRICUMA
Boa Vista-RR 69309393
navegação"""
 check(AddressExtractor.parse(noisy).streetLine.startsWith("Via das Flores, 261"))
 val alameda="""Número único
3632212
procurar
999882273632212
Anderson de Souza
Alameda das Acácias 587 Casa de
esquina PRICUMA Boa Vista-RR
69309360
2026-10-12 08:26:14
WhatsApp"""
 val a=AddressExtractor.parse(alameda)
 check(a.streetLine=="Alameda das Acácias, 587, Casa de Esquina — Pricumã") {"Alameda: $a"}
 check(a.locationLine=="Boa Vista, RR, 69309-360") {"Alameda CEP: $a"}
 println("Passed: 9 tests (5 addresses, search header, complete J&T card and recipient exclusion)")
}
