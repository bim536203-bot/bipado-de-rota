import br.com.leitorencomendas.AccountWire
import br.com.leitorencomendas.UsernamePolicy
import org.json.JSONObject
import org.json.JSONArray
fun main(){
 check(UsernamePolicy.valid(" Nome-Á "))
 check(UsernamePolicy.registration("Nome","nome")!=null)
 check(UsernamePolicy.registration("Nome","Nome")==null)
 val state=JSONObject().put("schema",1).put("revision",2).put("lastNumber",3).put("lastCaptureToken","local-capture").put("skipped",JSONArray().put(2))
 state.put("items",JSONArray().put(JSONObject().put("number",3).put("address","Rua de Teste, 3").put("whatsapp","5595999999999").put("latitude",2.8).put("longitude",-60.7).put("pointPrecision","house").put("captureToken","local-capture")))
 state.put("history",JSONArray().put(JSONObject().put("deletedAt",System.currentTimeMillis()).put("skipped",JSONArray()).put("items",JSONArray())))
 val identified=AccountWire.ensureIds(state)
 val wire=AccountWire.toWire(identified)
 check(!wire.has("lastCaptureToken"))
 val item=wire.getJSONArray("items").getJSONObject(0)
 check(item.getString("id").isNotEmpty()&&item.getString("whatsapp")=="5595999999999")
 check(item.getJSONObject("point").getDouble("lat")==2.8&&!item.has("latitude"))
 val restored=AccountWire.fromWire(wire,"local-capture")
 check(restored.getString("lastCaptureToken")=="local-capture")
 check(!AccountWire.fromWire(wire,"other-device").has("lastCaptureToken"))
 check(restored.getJSONArray("history").getJSONObject(0).getString("id").isNotEmpty())
 check(restored.getJSONArray("items").getJSONObject(0).getDouble("longitude")==-60.7)
 println("AccountWire: exact username, stable IDs, history, contacts, points and device capture isolation passed")
}
