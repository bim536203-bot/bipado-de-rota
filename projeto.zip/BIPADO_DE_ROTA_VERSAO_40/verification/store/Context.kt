package android.content

// In-memory persistence boundary; the production Store itself is compiled unchanged.
class Context {
 private val preferences=mutableMapOf<String,MemoryPreferences>()
 fun getSharedPreferences(name:String,mode:Int)=preferences.getOrPut(name){MemoryPreferences()}
}
typealias SharedPreferences=MemoryPreferences
class MemoryPreferences {
 private val values=mutableMapOf<String,String>()
 fun getString(key:String,default:String?):String?=values[key] ?: default
 fun edit()=Editor(values)
 class Editor(private val target:MutableMap<String,String>){
  private val pending=mutableMapOf<String,String>()
  fun putString(key:String,value:String)=apply{pending[key]=value}
  fun commit():Boolean{target.putAll(pending);return true}
 }
}
