import android.content.Context
import br.com.leitorencomendas.Store
import br.com.leitorencomendas.RouteCsv
import org.json.JSONArray
import org.json.JSONObject

fun main(){
 var count=0
 fun expect(ok:Boolean,message:String){check(ok){message};count++}
 fun item(n:Int,a:String)=JSONObject().put("number",n).put("address",a)
 val address="Rua das Campainhas, 111, Casa Verde, Pricumã, Boa Vista, RR, 69309-470, Brasil"
 val other="Rua Vega, 28, Boa Vista, RR"
 val c=Context()
 expect(Store.add(c,address,1),"First captured package")
 expect(Store.addSameAddress(c,1,2),"Second confirmed package")
 expect(Store.addSameAddress(c,1,3),"Third confirmed package")
 val raw=Store.all(c)
 val csvBefore=RouteCsv.export(raw)
 val group=Store.addressGroups(raw).single()
 expect(group.title=="PACOTE 1-2-3","One title replaces peer badges")
 expect(group.primaryNumber==1 && group.indices==listOf(0,1,2),"First captured package anchors group")
 expect(group.numbers==listOf(1,2,3),"Real numbers sorted with hyphens")
 expect(Store.all(c).length()==3,"Grouping display does not delete real packages")
 expect(RouteCsv.export(Store.all(c))==csvBefore,"Display does not modify export")
 expect(csvBefore.contains("PACOTE 1-2-3"),"Spoke notes remain grouped")
 expect(Store.nextNumber(c)==4,"Next number includes hidden members")
 expect(Store.skipNext(c,4),"Skipped card remains separate")
 expect(Store.addressGroups(Store.all(c)).size==1,"Skipped number is not a delivery group")
 expect(Store.add(c,other,5),"Different address remains visible")
 expect(Store.addressGroups(Store.all(c)).map{it.title}==listOf("PACOTE 1-2-3","PACOTE 5"),"One card per address")
 expect(Store.edit(c,0,7,address),"Renumber first captured package")
 val renumbered=Store.addressGroups(Store.all(c)).first()
 expect(renumbered.primaryNumber==7,"Anchor follows first capture, not minimum number")
 expect(renumbered.title=="PACOTE 2-3-7","Displayed numbers remain sorted")
 expect(Store.edit(c,1,2,"Rua dos Ipês, 221, Boa Vista, RR"),"Edit hidden member individually")
 expect(Store.addressGroups(Store.all(c)).size==3,"Changing one address splits it into its own card")
 expect(Store.addressGroups(Store.all(c)).first().title=="PACOTE 3-7","Remaining siblings stay grouped")
 expect(!Store.removeGroup(c,listOf(2,3,7)),"Reject stale group deletion")
 expect(Store.all(c).length()==4,"Stale deletion changes nothing")
 expect(!Store.removeGroup(c,listOf(3,3,7)),"Reject repeated ID in deletion")
 expect(!Store.removeGroup(c,emptyList()),"Reject empty deletion")
 expect(Store.removeGroup(c,listOf(7,3)),"Delete confirmed complete group atomically")
 expect(Store.all(c).length()==2,"Other destinations preserved")
 expect(Store.skipped(c).optInt(0)==4,"Skipped card preserved")
 expect(Store.clear(c),"Archive current list")
 val at=Store.history(c).getJSONObject(0).getLong("deletedAt")
 expect(Store.restore(c,at),"Restore archived list")
 expect(Store.addressGroups(Store.all(c)).size==2,"Restored list groups normally")
 val imported=JSONArray().put(item(9,address)).put(item(1,address)).put(item(8,other))
 expect(Store.replaceWithImport(c,imported),"Grouped import accepted")
 val first=Store.addressGroups(Store.all(c)).first()
 expect(first.primaryNumber==9 && first.title=="PACOTE 1-9","Preserve first known entry on import")
 expect(first.numbers.contains(1),"Hidden ID remains available for searching/editing")
 expect(Store.remove(c,0),"Removing anchor individually remains supported")
 expect(Store.addressGroups(Store.all(c)).first().title=="PACOTE 1","Next remaining entry becomes anchor")
 expect(Store.removeGroup(c,listOf(1)),"Delete singleton")
 expect(Store.removeGroup(c,listOf(8)),"Delete last group")
 expect(Store.nextNumber(c)==1,"Empty active route resets sequence")
 val noisy=JSONArray().put(item(1,address)).put(item(2,address.lowercase())).put(item(3,other)).put(item(4,"")).put(item(5,address).put("skipped",true))
 expect(Store.addressGroups(noisy).map{it.title}==listOf("PACOTE 1-2","PACOTE 3"),"Identity normalization matches CSV; ignore blank and skipped records")
 val groups=Store.addressGroups(noisy)
 expect(groups.all{it.numbers.none{n->n==4||n==5}},"No fictitious delivery numbers")
 val via="Via das Flores, 731, Casa, Pricumã, Boa Vista, RR, 69309-393, Brasil"
 val extra="Av Via das Flores, 731, Casa, Pricumã, Boa Vista, RR, 69309-393, Brasil"
 val conflict="Via das Flores, 731, Outro Bairro, Boa Vista, RR, 69309-394, Brasil"
 val variants=JSONArray().put(item(1,"Via das Flores, 731")).put(item(2,via)).put(item(3,via)).put(item(4,conflict))
 expect(Store.addressGroups(variants).map{it.numbers}==listOf(listOf(1,2,3),listOf(4)),"No context-less bridge can join conflicting locations")
 expect(Store.addressGroups(JSONArray().put(item(1,extra)).put(item(2,via))).single().numbers==listOf(1,2),"Verified mixed-prefix variation groups safely")
 val csv=RouteCsv.exportForSpoke(variants)
 expect(csv.contains("PACOTE 1-2-3") && csv.contains("PACOTE 4"),"CSV uses the same contextual grouping rule")
 expect(Store.matchingIndex(variants,via)==0,"Repeated prefix matches saved road")
 val reviewed=Context()
 expect(Store.add(reviewed,via,1),"Save first location")
 expect(Store.possibleMatch(reviewed,via.replace("Via das Flores","Rua das Flores"))!=null,"Different road type requests user review")
 expect(Store.addSameAddress(reviewed,1,2,bipped=true),"Confirmed extra parcel preserved")
 expect(Store.addressGroups(Store.all(reviewed)).single().numbers==listOf(1,2),"Both parcels retained in one stop")
 println("Grouped saved cards: $count checks passed")
}
