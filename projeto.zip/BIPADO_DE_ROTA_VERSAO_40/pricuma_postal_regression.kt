import br.com.leitorencomendas.PricumaPostal as P
import br.com.leitorencomendas.AddressExtractor as A
import br.com.leitorencomendas.CaptureAddressValidation as V
import br.com.leitorencomendas.GeoAddress as G
fun main(){
 var checks=0
 fun verify(ok:Boolean,label:String){check(ok){label};checks++}
 verify(P.entries.size==48,"48 source entries")
 verify(P.entries.map {it.postcode}.distinct().size==48,"unique postcode per source entry")
 for(e in P.entries){
  verify(P.exact(e.street.uppercase())==e,"case/accents lookup ${e.street}")
  verify(P.suggestions(e.street).contains(e),"offline suggestion ${e.street}")
  val raw="${e.street} 28 Casa PRICUMA Boa Vista-RR ${e.postcode}"
  val r=A.parse(raw)
  verify(r.streetLine=="${e.street}, 28, Casa — Pricumã" && V.valid(raw,r),"parse ${e.street}: $r")
 }
 verify(P.suggestions("das").any {it.street=="Rua das Rosas"},"connector-only short fragment")
 verify(P.suggestions("dos b").any {it.street=="Rua das Bacabas"},"partial street fragment")
 val query=G.query("26 das, Boa Vista, RR")
 verify(query.number=="26" && query.street=="das","real fragment query preserves house number")
 val first=P.suggestions(query.street).take(5)
 for((name,code) in listOf("Alameda das Acácias" to "69309-360","Rua das Acácias" to "69309-370","Via das Acácias" to "69309-380")){
  verify(first.any {it.street==name && it.postcode==code},"26 das must show $name with its own CEP among first five")
 }
 verify(P.suggestions("das ac").count {it.street.contains("Acácias")}==3,"more typing retains the three distinct Acácias streets")
 verify(P.suggestions("rua das ac").any{it.street=="Rua das Acácias"},"explicit street remains available")
 verify(P.canonicalStreet("R. das rosas","69309-630")=="Rua das Rosas","type abbreviation")
 verify(P.canonicalStreet("Rua das Rozas","69309-630")=="Rua das Rosas","one typo supported by exact visible CEP")
 verify(P.canonicalStreet("das tres marias","69309-670")=="Rua das Três Marias","untyped OCR supported by CEP")
 verify(P.canonicalStreet("Rua das Acácias","69309-360")==null,"must not confuse Rua with Alameda")
 verify(P.canonicalStreet("Alameda das Hortências","69309-500")==null,"must not confuse Alameda with Rua")
 verify(P.canonicalStreet("Rua das Rosas","69309-530")==null,"must not change a known street to another due to conflicting CEP")
 verify(P.canonicalStreet("Rua das Rozas","")==null,"never invent missing CEP")
 verify(P.canonicalStreet("Rua das Rozas","69309-63O")==null,"letter is not a postcode digit")
 verify(P.canonicalStreet("Rua totalmente diferente","69309-630")==null,"postcode alone does not identify street")
 for(raw in listOf("Rua das Rosas 28 Casa PRICUMA Boa Vista-RR","Rua das Rosas 28 Casa PRICUMA 69309-630","69309-630 PRICUMA Boa Vista-RR")){
  verify(!V.valid(raw,A.parse(raw)),"dictionary cannot manufacture missing street/number/city/postcode")
 }
 println("Pricumã postal catalogue: $checks recognition/negative safety checks passed (source data, synthetic OCR; not real ML Kit)")
}
