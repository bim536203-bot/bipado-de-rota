create table public.bipado_accounts(
 id uuid primary key default gen_random_uuid(),
 username text collate "C" not null unique check(octet_length(username) between 1 and 512),
 topic uuid not null default gen_random_uuid(),revision bigint not null default 0,
 state jsonb not null default '{"schema":1,"revision":0,"items":[],"skipped":[],"history":[],"lastNumber":0}',
 created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table public.bipado_sessions(token_hash text primary key,account_id uuid not null references public.bipado_accounts(id) on delete cascade,expires_at timestamptz not null default now()+interval '90 days');
create index on public.bipado_sessions(account_id);
create table public.bipado_operations(account_id uuid not null references public.bipado_accounts(id) on delete cascade,operation_id uuid not null,created_at timestamptz not null default now(),primary key(account_id,operation_id));
create table public.bipado_limits(bucket text primary key,started_at timestamptz not null default now(),hits int not null default 1);
alter table public.bipado_accounts enable row level security;
alter table public.bipado_sessions enable row level security;
alter table public.bipado_operations enable row level security;
alter table public.bipado_limits enable row level security;
revoke all on public.bipado_accounts,public.bipado_sessions,public.bipado_operations,public.bipado_limits from anon,authenticated;
grant all on public.bipado_accounts,public.bipado_sessions,public.bipado_operations,public.bipado_limits to service_role;
create function public.bipado_limit(p_bucket text) returns void language plpgsql security invoker set search_path='' as $$
declare n int;
begin
 insert into public.bipado_limits(bucket) values(p_bucket) on conflict(bucket) do update set
 hits=case when bipado_limits.started_at<now()-interval '1 minute' then 1 else bipado_limits.hits+1 end,
 started_at=case when bipado_limits.started_at<now()-interval '1 minute' then now() else bipado_limits.started_at end returning hits into n;
 if n>60 then raise exception 'Muitas tentativas. Aguarde um minuto.';end if;
 delete from public.bipado_limits where started_at<now()-interval '1 day';
end $$;
create function public.bipado_open(p_name text,p_hash text,p_register boolean) returns jsonb language plpgsql security invoker set search_path='' as $$
declare a public.bipado_accounts;
begin
 if p_register then insert into public.bipado_accounts(username) values(p_name) returning * into a;
 else select * into a from public.bipado_accounts where username=p_name collate "C";end if;
 if a.id is null then raise exception 'Usuário incorreto.';end if;
 insert into public.bipado_sessions(token_hash,account_id) values(p_hash,a.id);
 delete from public.bipado_sessions where expires_at<now();
 return jsonb_build_object('id',a.id,'name',a.username,'topic',a.topic,'revision',a.revision,'state',a.state);
end $$;
create function public.bipado_read(p_hash text) returns jsonb language plpgsql security invoker set search_path='' as $$
declare a public.bipado_accounts;
begin
 select a1.* into a from public.bipado_accounts a1 join public.bipado_sessions s on s.account_id=a1.id where s.token_hash=p_hash and s.expires_at>now();
 if a.id is null then raise exception 'Sessão expirada. Entre novamente.';end if;
 return jsonb_build_object('id',a.id,'name',a.username,'topic',a.topic,'revision',a.revision,'state',a.state);
end $$;
create function public.bipado_commit(p_hash text,p_operation uuid,p_expected bigint,p_state jsonb) returns jsonb language plpgsql security invoker set search_path='' as $$
declare a public.bipado_accounts;existing boolean;
begin
 select a1.* into a from public.bipado_accounts a1 join public.bipado_sessions s on s.account_id=a1.id where s.token_hash=p_hash and s.expires_at>now() for update of a1;
 if a.id is null then raise exception 'Sessão expirada. Entre novamente.';end if;
 select exists(select 1 from public.bipado_operations where account_id=a.id and operation_id=p_operation) into existing;
 if not existing and a.revision<>p_expected then return jsonb_build_object('conflict',true,'revision',a.revision,'state',a.state);end if;
 if not existing then
  if octet_length(p_state::text)>2000000 then raise exception 'Conta muito grande.';end if;
  insert into public.bipado_operations(account_id,operation_id) values(a.id,p_operation);
  update public.bipado_accounts set state=jsonb_set(p_state,'{revision}',to_jsonb(a.revision+1)),revision=a.revision+1,updated_at=now() where id=a.id returning * into a;
 end if;
 return jsonb_build_object('revision',a.revision,'state',a.state);
end $$;
create function public.bipado_logout(p_hash text) returns void language sql security invoker set search_path='' as $$delete from public.bipado_sessions where token_hash=p_hash;$$;
create function public.bipado_notify() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 perform realtime.send(jsonb_build_object('revision',new.revision),'changed','bipado:'||new.topic::text,false);return new;
end $$;
create trigger bipado_account_changes after update on public.bipado_accounts for each row execute function public.bipado_notify();
revoke all on function public.bipado_limit(text),public.bipado_open(text,text,boolean),public.bipado_read(text),public.bipado_commit(text,uuid,bigint,jsonb),public.bipado_logout(text),public.bipado_notify() from public,anon,authenticated;
grant execute on function public.bipado_limit(text),public.bipado_open(text,text,boolean),public.bipado_read(text),public.bipado_commit(text,uuid,bigint,jsonb),public.bipado_logout(text),public.bipado_notify() to service_role;
