import {validState,mergeChange} from './sync-state.js';
import {validUsername,validateRegistration} from './username-policy.js';
const URL_BASE=Deno.env.get('SUPABASE_URL')!;
const KEY=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const headers={'Access-Control-Allow-Origin':'https://bim536203-bot.github.io','Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS','Content-Type':'application/json','Cache-Control':'no-store'};
const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
const hash=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))),b=>b.toString(16).padStart(2,'0')).join('');
async function rpc(name:string,args:unknown){
 const response=await fetch(URL_BASE+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:KEY,Authorization:'Bearer '+KEY,'Content-Type':'application/json'},body:JSON.stringify(args),signal:AbortSignal.timeout(9000)});
 const raw=await response.text();const data=raw?JSON.parse(raw):null;if(!response.ok)throw Object.assign(new Error(data?.code==='23505'?'Este nome de usuário já está cadastrado.':data?.message||'Serviço indisponível.'),{code:data?.code});return data;
}
Deno.serve(async(req:Request)=>{
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return json({error:'Método inválido.'},405);
 try{
  const origin=req.headers.get('origin');if(origin&&origin!=='https://bim536203-bot.github.io')return json({error:'Origem inválida.'},403);
  if(Number(req.headers.get('content-length')||0)>4100000)return json({error:'Dados muito grandes.'},413);
  const raw=await req.text();if(raw.length>4100000)return json({error:'Dados muito grandes.'},413);
  const body=JSON.parse(raw),action=body.action;
  if(action==='login'||action==='register'){
   const ip=req.headers.get('x-forwarded-for')?.split(',')[0]||'unknown';
   await rpc('bipado_limit',{p_bucket:await hash(ip)});
   if(!validUsername(body.name))return json({error:'Usuário incorreto.'},400);
   if(action==='register'){const error=validateRegistration(body.name,body.repeat);if(error)return json({error},400);}
   const token=crypto.randomUUID()+crypto.randomUUID();
   const account=await rpc('bipado_open',{p_name:body.name,p_hash:await hash(token),p_register:action==='register'});
   return json({...account,token});
  }
  const token=req.headers.get('authorization')?.replace(/^Bearer /,'');
  if(!token||!/^[a-f0-9-]{72}$/.test(token))return json({error:'Sessão inválida.'},401);
  const p_hash=await hash(token);
  if(action==='logout'){await rpc('bipado_logout',{p_hash});return json({ok:true});}
  const account=await rpc('bipado_read',{p_hash});
  if(action==='read')return json({...account,state:validState(account.state)});
  if(action!=='change'||typeof body.operation!=='string'||!/^[a-f0-9-]{36}$/.test(body.operation))return json({error:'Operação inválida.'},400);
  const before=validState(body.before),after=validState(body.after);
  let revision=account.revision,state=account.state;
  for(let attempt=0;attempt<6;attempt++){
   const merged=mergeChange(state,before,after);
   const result=await rpc('bipado_commit',{p_hash,p_operation:body.operation,p_expected:revision,p_state:merged});
   if(!result.conflict)return json(result);
   revision=result.revision;state=result.state;
  }
  return json({error:'A conta está sendo alterada em outro aparelho. Tentaremos novamente.'},409);
 }catch(error){
  console.error('bipado-sync failure', (error as any)?.code||'network', (error as Error).message);
  const message=(error as Error).message||'Não foi possível sincronizar.';
  const known=/Usuário incorreto|já está cadastrado|Sessão|Muitas tentativas|Conta muito grande|Pacote inválido|Histórico inválido|Dados da conta|Número de pacote/.test(message);
  return json({error:known?message:'Não foi possível sincronizar. Confira a conexão.'},message.includes('já está cadastrado')?409:message.includes('Sessão')?401:400);
 }
});
