// Usernames are opaque, case-sensitive identifiers. Never trim or normalize them.
export function validUsername(value) {
  return typeof value === 'string' && value.length <= 128 &&
    /\S/u.test(value) && !/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/u.test(value);
}
export function matchingUsername(actual, supplied) {
  return validUsername(actual) && validUsername(supplied) && actual === supplied;
}
export function validateRegistration(first, repeated) {
  if (!validUsername(first)) return 'Informe um nome de usuário válido.';
  if (!matchingUsername(first, repeated)) return 'Os nomes de usuário precisam ser exatamente iguais.';
  return null;
}
