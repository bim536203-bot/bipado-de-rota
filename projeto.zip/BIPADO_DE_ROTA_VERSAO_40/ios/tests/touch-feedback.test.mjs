import test from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {setupTouchFeedback} from '../dist/touch-feedback.js';
test('Toque dá cor sem adiar clique; teclado, controles dinâmicos, repetição e desativados',async()=>{
 const dom=new JSDOM('<button id="one">Abrir</button>'),w=dom.window,d=w.document;
 w.matchMedia=()=>({matches:true});
 const cleanup=setupTouchFeedback(w),b=d.getElementById('one');let actions=0;
 b.addEventListener('click',()=>actions++);
 b.click();assert.equal(actions,1);assert.equal(b.classList.contains('touch-pressed'),true);
 await new Promise(r=>w.setTimeout(r,160));assert.equal(b.classList.contains('touch-pressed'),false);
 const later=d.createElement('button');later.textContent='Salvar';d.body.append(later);
 later.dispatchEvent(new w.MouseEvent('pointerdown',{bubbles:true}));assert.equal(later.classList.contains('touch-pressed'),true);
 later.disabled=true;later.classList.remove('touch-pressed');later.dispatchEvent(new w.MouseEvent('pointerdown',{bubbles:true}));assert.equal(later.classList.contains('touch-pressed'),false);
 b.click();b.click();assert.equal(actions,3);cleanup();assert.equal(b.classList.contains('touch-pressed'),false);dom.window.close();
});
