import test from 'node:test';
import assert from 'node:assert/strict';
import {sameAddress,possibleAddress,groups,exportCsv,parseCsv} from '../dist/core.js';
const full=(street,n='731',district='Pricumã',zip='69309-393')=>`${street}, ${n}, Casa, ${district}, Boa Vista, RR, ${zip}, Brasil`;
test('prefixos extras de logradouro, contexto e indicação de possível repetição',()=>{
 for(const [a,b] of [['Av Via das Flores','Via das Flores'],['Rua Rua Exemplo','R. Exemplo'],['Av. Alameda Teste','Alameda Teste'],['Tv Travessa Teste','Travessa Teste']])assert.ok(sameAddress(full(a),full(b)));
 assert.ok(!sameAddress(full('Via das Flores'),full('Via das Flores','731','Outro Bairro')));
 assert.ok(!sameAddress(full('Via das Flores'),full('Via das Flores','731','Pricumã','69309-394')));
 for(const number of ['732','731A','731/2'])assert.ok(!sameAddress(full('Via das Flores'),full('Via das Flores',number)));
 assert.ok(possibleAddress(full('Rua das Flores'),full('Alameda das Flores')));
 assert.ok(possibleAddress(full('Rua das das Flores'),full('Rua das Flores')));
 assert.ok(!possibleAddress('Rua Exemplo, 731','Alameda Exemplo, 731'));
 assert.ok(!possibleAddress(full('Rua das Flores'),full('Rua das Rosas')));
 assert.ok(!sameAddress('Rua Via Láctea, 731','Via Láctea, 731'));
});
test('cartões e CSV conservam pacotes e não unem bairros/CEPs incompatíveis nem por ponte sem CEP',()=>{
 const items=[full('Av Via das Flores'),full('Via das Flores'),full('Via das Flores','731','Outro Bairro','69309-394')].map((address,i)=>({number:i+1,address}));
 assert.deepEqual(groups(items).map(g=>g.numbers),[[1,2],[3]]);
 assert.match(exportCsv(items),/PACOTE 1-2/);assert.equal(parseCsv(exportCsv(items)).length,3);
 const unknown={number:1,address:'Via das Flores, 731'};
 assert.equal(groups([unknown,...items.map(i=>({...i,address:i.address.replace('Av Via','Via'),number:i.number+1}))]).length,2);
});
