import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {pricumaPostcodes} from '../dist/pricuma-postcodes.js';
import {streetFeatures} from '../dist/street-catalogue.js';
import {localSuggestions,searchSuggestions,verifiedPoint,createMiniMap} from '../dist/mini-map.js';

test('48 ruas e CEPs do Pricumã são idênticos nas plataformas e respondem sem rede',async()=>{
 const native=JSON.parse(await readFile(new URL('../../app/src/main/assets/pricuma-postcodes.json',import.meta.url)));
 assert.deepEqual(native,pricumaPostcodes);assert.equal(native.entries.length,48);
 const kotlin=await readFile(new URL('../../app/src/main/java/br/com/leitorencomendas/PricumaPostal.kt',import.meta.url),'utf8');
 const entries=[...kotlin.matchAll(/Entry\("([^"]+)","(\d{5}-\d{3})"\)/g)].map(m=>({street:m[1],postcode:m[2]}));
 assert.deepEqual(entries,native.entries);
 for(const e of native.entries){
  const hits=await searchSuggestions({fetch:()=>{throw Error('network must not be used');}},'28 '+e.street+', Pricumã, Boa Vista, RR');
  const hit=hits.find(h=>h.streetLine===e.street+', 28, Pricumã'&&h.postcode===e.postcode);
  assert.ok(hit,e.street);assert.equal(hit.lat,null);assert.equal(hit.lon,null);assert.equal(hit.exact,false);assert.equal(verifiedPoint(hit),null);
 }
});

test('Rua, Alameda e Via com nomes semelhantes mantêm seus CEPs distintos',()=>{
 const hits=localSuggestions('28 acac, Boa Vista, RR');
 for(const [name,code] of [['Alameda das Acácias','69309-360'],['Rua das Acácias','69309-370'],['Via das Acácias','69309-380']]){
  assert.ok(hits.some(h=>h.streetLine.startsWith(name+', 28,')&&h.postcode===code));
 }
 assert.ok(!localSuggestions('28 rosas, Buritis, Boa Vista, RR').some(h=>h.postalOnly));
 assert.deepEqual(localSuggestions('28 rosas, São Paulo, SP'),[]);
});

test('CEPs locais corrigidos conservam geometria e não verificam número de imóvel',()=>{
 const byName=new Map(pricumaPostcodes.entries.map(e=>[e.street,e.postcode]));let n=0;
 for(const f of streetFeatures){
  const p=f.properties;if(!p.postal_source)continue;n++;
  assert.equal(p.postcode,byName.get(p.street));assert.ok('osm_postcode' in p);
  assert.equal(p.district,'Pricumã');assert.ok(!p.housenumber);
 }
 assert.equal(n,11);
});

test('a lista postal está incluída no cache offline do iOS',async()=>{
 const sw=await readFile(new URL('../dist/sw.js',import.meta.url),'utf8');assert.ok(sw.includes("'pricuma-postcodes.js'"));
});

test('resultado postal não desenha marcador nem é salvo como coordenada confirmada',async()=>{
 const hit=localSuggestions('28 rosas, Pricumã, Boa Vista, RR').find(h=>h.postalOnly);
 let moved='unset',views=0,markers=0;
 const map={setView(){views++;return this;},invalidateSize(){},remove(){}};
 const w={AbortController,setTimeout,clearTimeout,navigator:{onLine:false},requestAnimationFrame:fn=>fn(),L:{map:()=>map,tileLayer:()=>({addTo(){}}),marker:()=>{markers++;throw Error('no invented coordinate');}}};
 const status={textContent:''};
 const mini=createMiniMap(w,{},status,'Rua das Rosas, 28, Boa Vista, RR',{selected:hit,onPointChanged:p=>moved=p});
 await mini.ready;assert.equal(moved,null);assert.equal(markers,0);assert.equal(views,1);assert.equal(status.textContent,'Rua e CEP encontrados na base local');mini.destroy();
});

test('26 das mostra Rua das Acácias nas primeiras opções, ao lado de Alameda e Via, sem rede',async()=>{
 const hits=await searchSuggestions({fetch:()=>{throw Error('must stay offline');}},'26 das, Boa Vista, RR');
 const first=hits.slice(0,5);
 for(const [name,code] of [['Alameda das Acácias','69309-360'],['Rua das Acácias','69309-370'],['Via das Acácias','69309-380']]){
  assert.ok(first.some(h=>h.streetLine===name+', 26, Pricumã'&&h.postcode===code),name+' must appear among first five');
 }
 assert.equal(new Set(hits.map(h=>h.streetLine+'|'+h.postcode)).size,hits.length);
 assert.ok(localSuggestions('26 Rua das ac, Boa Vista, RR').some(h=>h.streetLine==='Rua das Acácias, 26, Pricumã'&&h.postcode==='69309-370'));
});
