import test from 'node:test';
import assert from 'node:assert/strict';
import {addressKey,sameAddress,groups,exportCsv,parseCsv} from '../dist/core.js';
import {queryParts} from '../dist/mini-map.js';
test('número com barra conserva identidade, busca, agrupamento e CSV Android/iPhone',()=>{
 const base='Avenida de Teste',a=`${base}, 78/3, Boa Vista, RR`,b=`${base}, 78/4, Boa Vista, RR`,c=`${base}, 78, Boa Vista, RR`;
 assert.equal(addressKey(a),'avenida de teste|78/3');assert.equal(sameAddress(a,b),false);assert.equal(sameAddress(a,c),false);
 assert.equal(sameAddress(a,`${base}, 78/3, AP 02, Boa Vista, RR`),true);
 for(const value of [a,`78/3 ${base}, Boa Vista, RR`,`${base} 78/3, Boa Vista, RR`])assert.equal(queryParts(value).number,'78/3');
 const items=[a,b,c].map((address,i)=>({number:i+1,address}));assert.equal(groups(items).length,3);assert.deepEqual(parseCsv(exportCsv(items)).map(i=>i.address),items.map(i=>i.address));
});
