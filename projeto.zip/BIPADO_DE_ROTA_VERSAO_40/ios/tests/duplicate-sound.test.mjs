import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createSounds} from '../dist/sounds.js';
test('repetição tem áudio próprio, curto e disponível offline',async()=>{
 const duplicate=await readFile(new URL('../dist/assets/bip_repetido.wav',import.meta.url));
 assert.equal(duplicate.toString('ascii',0,4),'RIFF');const duration=(duplicate.length-44)/(22050*2);assert.ok(duration>.3&&duration<.6);
 for(const name of ['sucesso','erro'])assert.ok(!duplicate.equals(await readFile(new URL(`../dist/assets/bip_${name}.wav`,import.meta.url))));
 const sw=await readFile(new URL('../dist/sw.js',import.meta.url),'utf8');assert.match(sw,/assets\/bip_repetido.wav/);
 const fetched=[];class AudioContext{state='running';destination={};async decodeAudioData(b){return b;}createBufferSource(){return {connect(){},start(){}};}}
 const sounds=createSounds({AudioContext,fetch:async path=>{fetched.push(path);return {ok:true,arrayBuffer:async()=>new ArrayBuffer(4)};}});
 await sounds.play('duplicate');await sounds.play('duplicate');assert.deepEqual(fetched,['./assets/bip_repetido.wav']);
});
