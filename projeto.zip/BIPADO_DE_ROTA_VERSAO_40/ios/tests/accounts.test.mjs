import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {createAccountRepository} from '../dist/account-sync.js';
import {freshState} from '../dist/core.js';
import {fresh,mergeChange} from '../../backend/sync-state.js';
import {validUsername,validateRegistration} from '../dist/username-policy.js';
const cp=structuredClone;
const item=(n,id=randomUUID())=>({id,number:n,address:'Rua de Teste, '+n+', Boa Vista, RR'});
const wait=()=>new Promise(r=>setTimeout(r,10));
function fixture(){
 const accounts=new Map(),tokens=new Map(),ops=new Map();let offline=false;
 const request=async(b,token)=>{
  if(offline)throw Error('Sem conexão');
  if(b.action==='register'||b.action==='login'){
   if(b.action==='register'){if(accounts.has(b.name))throw Error('Este nome de usuário já está cadastrado.');accounts.set(b.name,{id:randomUUID(),name:b.name,topic:randomUUID(),revision:0,state:fresh()});}
   const a=accounts.get(b.name);if(!a)throw Error('Usuário incorreto.');const t=randomUUID();tokens.set(t,a);return {...cp(a),token:t};
  }
  const a=tokens.get(token);if(!a)throw Error('Sessão inválida.');
  if(b.action==='logout'){tokens.delete(token);return {ok:true};}
  if(b.action==='change'&&!ops.has(b.operation)){a.state=mergeChange(a.state,b.before,b.after);a.state.revision=++a.revision;ops.set(b.operation,true);}
  return cp(a);
 };
 function device(localItems=[]){
  const records={'local':{...freshState(),items:localItems}},local={
   readRecord:async k=>cp(records[k]),
   updateRecords:async(keys,fn)=>{const r=fn(Object.fromEntries(keys.map(k=>[k,cp(records[k])])));for(const[k,v]of Object.entries(r.writes))if(v===undefined)delete records[k];else records[k]=cp(v);return r.value;},
   readState:async()=>cp(records.local),
   commitState:async(rev,fn)=>{assert.equal(records.local.revision,rev);records.local={...fn(cp(records.local)),revision:rev+1};return cp(records.local);}
  };
  const w={crypto:{randomUUID},navigator:{onLine:true},document:{hidden:false,addEventListener(){}},setTimeout,clearTimeout,setInterval,clearInterval,addEventListener(){}};
  return createAccountRepository(w,local,{request});
 }
 return {device,accounts,setOffline(v){offline=v;}};
}
test('nomes literais e repetição exata',()=>{
 for(const name of ['Fabio',' fabio','Fábio','a-b','a b'])assert.ok(validUsername(name));
 assert.ok(validateRegistration('Fabio','fabio'));assert.ok(validateRegistration('x','x '));assert.equal(validateRegistration('Nome','Nome'),null);
 for(const name of ['', '   ', '\u200b', 'a\nb'])assert.equal(validUsername(name),false);
});
test('local 40 → conta 30 → sair restaura os mesmos dados locais',async()=>{
 const f=fixture(),a=f.device(Array.from({length:40},(_,i)=>item(i+1))),b=f.device();
 try{
  await a.account.enter('Nome Exato','Nome Exato');let s=await a.readState();await a.commitState(s.revision,x=>({...x,items:Array.from({length:30},(_,i)=>item(i+1))}));await wait();await a.account.refresh();
  await b.account.enter('Nome Exato');assert.equal((await b.readState()).items.length,30);
  await assert.rejects(()=>b.account.enter('nome exato'),/incorreto/);await assert.rejects(()=>b.account.enter('Nome Exato','Nome Exato'),/cadastrado/);
  await a.account.logout();assert.equal((await a.readState()).items.length,40);
  await a.account.enter('Nome Exato');assert.equal((await a.readState()).items.length,30);
 }finally{a.close();b.close();}
});
test('alterações sem internet sobrevivem à saída e sincronizam ao voltar',async()=>{
 const f=fixture(),a=f.device(),b=f.device();
 try{
  await a.account.enter('Offline','Offline');f.setOffline(true);let s=await a.readState();await a.commitState(s.revision,x=>({...x,items:[item(1)]}));await wait();assert.equal((await a.account.status()).pending,1);
  await a.account.logout();assert.equal((await a.readState()).items.length,0);f.setOffline(false);await a.account.enter('Offline');await wait();await a.account.refresh();await b.account.enter('Offline');assert.equal((await b.readState()).items.length,1);
 }finally{a.close();b.close();}
});
test('capturas simultâneas mantêm ambos os pacotes e numeração única',()=>{
 const before=fresh(),a={...fresh(),items:[item(1)]},b={...fresh(),items:[item(1)]};
 const merged=mergeChange(mergeChange(before,before,a),before,b);assert.equal(merged.items.length,2);assert.equal(new Set(merged.items.map(i=>i.number)).size,2);
});
test('edição antiga não ressuscita pacote apagado e preserva outro campo remoto',()=>{
 const before={...fresh(),items:[item(1)]},after=cp(before);after.items[0].address='Rua de Teste, 2, Boa Vista, RR';
 assert.equal(mergeChange(fresh(),before,after).items.length,0);
 const server=cp(before);server.items[0].whatsapp='5595999999999';assert.equal(mergeChange(server,before,after).items[0].whatsapp,'5595999999999');
});
