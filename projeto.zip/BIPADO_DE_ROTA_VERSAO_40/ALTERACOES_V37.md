# Versão 37

- Ícone de usuário no início, com nome pequeno e ponto verde quando conectado.
- Entrada pelo nome exato; cadastro exige repetir o mesmo nome e impede duplicação.
- Sincronização de pacotes, endereços, números, contatos, pulados e histórico.
- SAIR retorna aos dados locais preservados no aparelho, sem misturar listas.
- Alterações offline permanecem pendentes até a conexão voltar.
- Proteção contra callbacks de captura e edições antigas após mudança de usuário.
- Preserva a busca, o design aprovado e a exportação Spoke sem telefones.

Servidor dedicado configurado. Testes automatizados e validação com servidor real; teste final em aparelhos físicos ainda necessário.
