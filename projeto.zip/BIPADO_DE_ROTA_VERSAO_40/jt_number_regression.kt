import br.com.leitorencomendas.AddressExtractor as A
import br.com.leitorencomendas.CaptureAddressValidation as V
import br.com.leitorencomendas.AddressIdentity as I
import br.com.leitorencomendas.GeoAddress as G
import br.com.leitorencomendas.OcrLayout as L
fun main(){
 var count=0
 fun yes(raw:String,street:String,zip:String){val r=A.parse(raw);check(r.streetLine==street && r.locationLine.endsWith(zip) && V.valid(raw,r)){"$raw => $r"};count++}
 val loc="PRICUMA Boa Vista-RR"
 yes("321 . Rua das Damas da Noite 321 321 $loc 69309440","Rua das Damas da Noite, 321 — Pricumã","69309-440")
 yes("Rua dos Narcisos 421 AP 02 $loc 69309397","Rua dos Narcisos, 421, Ap 02 — Pricumã","69309-397")
 yes("Rua das Acácias 854 Rua das Acácias 854 854 $loc 69309370","Rua das Acácias, 854 — Pricumã","69309-370")
 yes("Rua dos Narcisos 199 Rua dos Narcisos 199 199 $loc 69309397","Rua dos Narcisos, 199 — Pricumã","69309-397")
 yes("Alameda dos Girassóis Vila , Quarto 5 Alameda dos Girassóis Vila , Quarto 5 2080 $loc 69309490","Alameda dos Girassóis, 2080, Vila , Quarto 5 — Pricumã","69309-490")
 yes("Avenida Bandeirantes 78/3 $loc 69309515","Avenida Bandeirantes, 78/3 — Pricumã","69309-515")
 yes("Rua de Teste Quarto 5 2080 $loc 69309490","Rua de Teste, 2080, Quarto 5 — Pricumã","69309-490")
 for(unit in listOf("AP","Ap.","APTO","Apartamento","Bloco","Quarto","Sala","Loja","Quadra","Lote"))yes("Rua dos Narcisos 421 $unit 02 $loc 69309397","Rua dos Narcisos, 421, ${unit.lowercase().replaceFirstChar{it.uppercase()}} 02 — Pricumã","69309-397")
 for(raw in listOf("Rua Perpétua 00 Rua Perpétua 00 642 $loc 69309403","Rua das Acácias 1 854 $loc 69309370","Rua das Acácias 854 855 $loc 69309370","Rua dos Narcisos AP 02 $loc 69309397","Rua dos Narcisos 421 AP 02 567 $loc 69309397","Rua dos Narcisos 421 $loc","Rua dos Narcisos 421 69309397")){
  val r=A.parse(raw);check(!V.valid(raw,r)){"Unexpected acceptance $raw => $r"};count++
 }
 check(G.query("Avenida Bandeirantes, 78/3, Boa Vista, RR").number=="78/3");count++
 check(G.query("78/3 Avenida Bandeirantes, Boa Vista, RR").number=="78/3");count++
 check(I.same("Rua dos Narcisos, 78/3, Casa", "R. dos Narcisos, 78/3, Pricumã"));count++
 check(!I.same("Rua dos Narcisos, 78/3", "Rua dos Narcisos, 78"));count++
 check(!I.same("Rua dos Narcisos, 78/3", "Rua dos Narcisos, 78/4"));count++
 // Reflowed rows and independent side actions exercise selection + parser together.
 val rows=listOf("Rua dos Narcisos 421 AP","02 PRICUMA Boa Vista-RR","69309397")
 fun span(t:String,x:Int,y:Int)=L.Span(t,x,y,x+t.length*10,y+26)
 val spans=listOf(span("999999999999991",60,260),span("Destinatário Sintético",60,320))+rows.mapIndexed{i,t->span(t,60,380+i*42)}+listOf(span("navegação",760,380),span("telefone",760,422),span("2026-10-21",60,540))
 val selection=L.select(spans,1080,1920);yes(selection.text,"Rua dos Narcisos, 421, Ap 02 — Pricumã","69309-397")
 println("J&T numbering: $count cases passed (synthetic text/layout; device OCR pending)")
}
