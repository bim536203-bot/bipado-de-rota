import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {JSDOM} from 'jsdom';
import {createApp} from '../dist/app.js';import * as C from '../dist/core.js';import {pickResult,resultList,createMiniMap,attachAutocomplete,searchSuggestions,queryParts} from '../dist/mini-map.js';
const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');const tick=()=>new Promise(r=>setTimeout(r,0)),settle=()=>new Promise(r=>setTimeout(r,430));
const hit={lat:2.8,lon:-60.6,exact:true,streetLine:'Rua Vega, 28',location:'Boa Vista, RR, 69300-123',postcode:'69300-123',label:'Rua Vega, 28 — Boa Vista, RR, 69300-123'};
test('Fragmento → sugestões com CEP → seleção → SALVAR → mapa → somente CONFIRMAR grava e toca bip',async()=>{
 const dom=new JSDOM(html,{url:'https://example.test/'}),w=dom.window,d=w.document;w.scrollTo=()=>{};w.matchMedia=()=>({matches:false});w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open')};
 let stored=C.freshState(),maps=0,destroyed=0;const played=[];
 const repo={readState:async()=>structuredClone(stored),commitState:async(rev,fn)=>{assert.equal(rev,stored.revision);stored=C.validateState({...fn(structuredClone(stored)),revision:rev+1});return structuredClone(stored)}};
 const app=createApp(w,repo,{searchSuggestions:async()=>[hit],sounds:{unlock(){},play:s=>played.push(s)},mapFactory:(win,map,status,address,options)=>{maps++;assert.equal(options.selected,hit);assert.match(address,/Rua Vega, 28/);status.textContent='Número localizado na base • confira o ponto';return {destroy(){destroyed++}}}});await app.ready;
 const click=label=>{const b=[...d.querySelectorAll('#dialog-actions button')].find(b=>b.textContent===label);assert.ok(b,label);b.click()};
 assert.equal(d.querySelector('#import-home span').textContent,'ADICIONAR ENDEREÇO MANUALMENTE');
 const fill=async()=>{const mapsBefore=maps,itemsBefore=stored.items.length;d.getElementById('import-home').click();assert.deepEqual([...d.querySelectorAll('#dialog-actions button')].filter(b=>!b.hidden).map(b=>b.textContent),['CANCELAR']);const input=d.getElementById('editor-address');input.value='28 veg';input.dispatchEvent(new w.Event('input'));await settle();assert.match(d.querySelector('.address-suggestion').textContent,/69300-123/);d.querySelector('.address-suggestion').click();assert.equal(maps,mapsBefore);assert.equal(stored.items.length,itemsBefore);assert.equal(d.querySelector('.save-address').hidden,false);click('SALVAR')};
 await fill();assert.equal(stored.items.length,0);assert.equal(maps,1);assert.deepEqual([...d.querySelectorAll('#dialog-actions button')].map(b=>b.textContent),['CANCELAR','CONFIRMAR']);assert.ok(d.querySelector('.mini-map'));click('CANCELAR');assert.equal(destroyed,1);assert.deepEqual(played,[]);
 await fill();click('CONFIRMAR');await tick();assert.equal(stored.items[0].number,1);assert.match(stored.items[0].address,/69300-123/);assert.deepEqual(played,['success']);assert.equal(destroyed,2);
 await fill();assert.match(d.querySelector('.parcel-heading').textContent,/Pacote 2/);d.querySelector('.pencil-button').click();assert.equal(d.getElementById('editor-address').value,'Rua Vega, 28');click('CANCELAR');assert.equal(stored.items.length,1);
 dom.window.close();
});
test('Próximo pacote ignora contador antigo e acompanha exclusão, edição e grupos',()=>{
 let s=C.freshState();s.lastNumber=999;assert.equal(C.nextNumber(s),1);s=C.addManual(s,'Rua Vega, 28');s=C.editItem(s,1,15,'Rua Vega, 28');assert.equal(C.nextNumber(s),16);s=C.editItem(s,15,7,'Rua Vega, 28');assert.equal(C.nextNumber(s),8);s=C.removeGroup(s,[7]);assert.equal(C.nextNumber(s),1);
 s=C.importRoute(s,[{number:1,address:'Rua Vega, 28'},{number:2,address:'Rua Vega, 28'},{number:7,address:'Rua Vega, 28'}]);assert.equal(C.nextNumber(s),8);
});
const f=(p={},c=[-60.6,2.8])=>({geometry:{coordinates:c},properties:{street:'Rua Vega',city:'Boa Vista',countrycode:'BR',...p}});
test('Fragmentos curtos e tipo de via não desaparecem no filtro; dados de teste não comprovam cobertura real',()=>{
 const candidates=[f({street:'Alameda dos Bambus',district:'Pricumã',postcode:'69300-000'}),f({street:'Travessa dos Bambus'}),f({street:'Via das Flores'}),f({street:'Rua Vega'}),f({street:'Rua Cisne'})];
 for(const input of ['46 dos b','46 dos bam']){
  const hits=resultList(candidates,input+', Boa Vista, RR');assert.equal(hits.length,2);assert.match(hits[0].streetLine,/Alameda dos Bambus, 46/);assert.equal(hits[0].exact,false);
 }
 for(const input of ['1003 via','1093 via']){const hits=resultList(candidates,input+', Boa Vista, RR');assert.equal(hits.length,1);assert.match(hits[0].streetLine,/Via das Flores/);assert.equal(hits[0].exact,false);}
 assert.equal(resultList(candidates,'46 dos z, Boa Vista, RR').length,0);
 const highway=f({street:'',name:'Via das Flores',type:undefined,osm_key:'highway',osm_value:'tertiary'});
 assert.match(resultList([highway],'1003 via, Boa Vista, RR')[0].streetLine,/Via das Flores/);
});
test('Consulta real montada pelo app usa fragmento e bbox local, sem número e sem UF após prefixo',async()=>{
 let url;const w={setTimeout:f=>{queueMicrotask(f);return 1},clearTimeout(){},fetch:async u=>{url=new URL(u);return {ok:true,json:async()=>({features:[f({street:'Via das Flores'})]})};}};
 const hits=await searchSuggestions(w,'1093 via, Boa Vista, RR',new AbortController().signal);
 assert.equal(url.searchParams.get('q'),'via');assert.equal(url.searchParams.get('bbox'),'-61.2,2.4,-60.15,3.25');assert.equal(url.searchParams.get('countrycode'),'BR');assert.equal(hits.length,1);assert.equal(hits[0].exact,false);
});
test('Resultados não confundem outra rua, cidade ou número; fragmentos e números iniciais funcionam',()=>{
 const a='Rua Vega, 28, Boa Vista, RR, Brasil';assert.equal(pickResult([f({street:'Rua Cisne',housenumber:'28'})],a),null);assert.equal(pickResult([f({city:'Outra cidade',housenumber:'28'})],a),null);assert.equal(pickResult([f({housenumber:'28'})],a).exact,true);assert.equal(pickResult([f({housenumber:'20'})],a).exact,false);
 assert.equal(pickResult([f({housenumber:'28'})],'28 veg, Boa Vista, RR').exact,true);
 assert.equal(pickResult([f({housenumber:'28'})],', Boa Vista'),null);
 assert.equal(pickResult([f({},[NaN,2.8])],a),null);assert.equal(pickResult([f({countrycode:'VE'})],a),null);
 assert.equal(pickResult([f({})],a).exact,false);
 assert.equal(queryParts('578 veg').number,'578');
 assert.deepEqual(queryParts('28Ve'),{street:'Ve',number:'28'});
 assert.deepEqual(queryParts('Rua 13 de Maio'),{street:'Rua 13 de Maio',number:''});
});
test('Nome parcial do comércio combina com bairro e importa CEP sem exigir nome da rua',()=>{
 const features=[f({name:'Supermercado Goiana',street:'Rua Dom Apparecido José Dias',district:'Cidade Satélite',type:'house',osm_key:'shop',osm_value:'supermarket',postcode:'69317-482'})];
 const h=resultList(features,'goiana sat, Boa Vista, RR')[0];assert.ok(h);assert.equal(h.postcode,'69317-482');assert.match(h.streetLine,/Supermercado Goiana/);assert.equal(h.place,true);assert.equal(h.exact,false);
 assert.equal(resultList(features,'outra loja, Boa Vista, RR').length,0);
 const noZip=pickResult([f({})],'veg, Boa Vista, RR');assert.equal(noZip.postcode,'');
});
test('Selecionar usa exatamente as coordenadas recebidas e não faz nova consulta',async()=>{
 const calls=[];let fetched=0;
 const layer={addTo(){return this}},map={setView(c){calls.push(c);return this},invalidateSize(){},remove(){}};
 const w={AbortController,setTimeout,clearTimeout,requestAnimationFrame:fn=>fn(),navigator:{onLine:true},fetch:()=>{fetched++;throw Error('não deveria consultar')},L:{map:()=>map,tileLayer:()=>layer,marker:c=>{calls.push(c);return layer},divIcon:x=>x}};
 const status={},m=createMiniMap(w,{},status,'Rua Vega, 28',{selected:hit});await m.ready;assert.equal(fetched,0);assert.deepEqual(calls.at(-1),[hit.lat,hit.lon]);m.destroy();
});
test('Digitação nova cancela resultado antigo; fechar impede consultas e atualizações tardias',async()=>{
 const dom=new JSDOM('<input><p></p><div></div>'),w=dom.window,d=w.document,input=d.querySelector('input'),status=d.querySelector('p'),list=d.querySelector('div');let resolveFirst,signalFirst;
 const a=attachAutocomplete(w,input,null,list,status,{search:async(win,q,signal)=>{if(q.startsWith('veg')){signalFirst=signal;return await new Promise(r=>resolveFirst=r);}return [{...hit,label:'Resultado novo'}];}});
 input.value='veg';input.dispatchEvent(new w.Event('input'));await settle();input.value='novo';input.dispatchEvent(new w.Event('input'));assert.equal(signalFirst.aborted,true);resolveFirst([hit]);await settle();assert.equal(list.firstChild.textContent,'Resultado novo');
 input.value='veg';input.dispatchEvent(new w.Event('input'));a.destroy();await settle();assert.equal(list.children.length,0);dom.window.close();
});
test('Pino aproximado não vira casa localizada; tocar no mapa registra ajuste manual e rejeita coordenadas inválidas',async()=>{
 const events={},markerEvents={},points=[],icons=[];let coords;
 const marker={addTo(){return this},on:(name,fn)=>markerEvents[name]=fn,setLatLng(c){coords=c;return this},setIcon:i=>icons.push(i),getLatLng:()=>({lat:coords[0],lng:coords[1]})};
 const map={setView(){return this},invalidateSize(){},remove(){},on:(name,fn)=>events[name]=fn};
 const w={AbortController,setTimeout,clearTimeout,requestAnimationFrame:f=>f(),navigator:{onLine:true},L:{map:()=>map,tileLayer:()=>({addTo(){}}),marker:()=>marker,divIcon:i=>{icons.push(i);return i}}};
 const status={},m=createMiniMap(w,{},status,'Rua Exemplo, 28',{selected:{lat:2.8,lon:-60.6,exact:false},onPointChanged:p=>points.push(p)});await m.ready;
 assert.equal(points[0],null);assert.match(icons[0].className,/approximate-marker/);assert.match(status.textContent,/Casa não localizada/);
 events.click({latlng:{lat:2.81,lng:-60.61}});assert.deepEqual(points.at(-1),{lat:2.81,lon:-60.61,precision:'manual'});assert.doesNotMatch(icons.at(-1).className,/approximate/);
 const count=points.length;events.click({latlng:{lat:NaN,lng:10}});assert.equal(points.length,count);m.destroy();events.click({latlng:{lat:2.82,lng:-60.62}});assert.equal(points.length,count);
});
test('Mapa aparece de imediato e refina apenas com a casa retornada; ajuste manual vence resposta atrasada',async()=>{
 async function run(manual){
  let resolveFetch;const points=[],moves=[],events={};
  const marker={addTo(){return this},on(){},setLatLng:c=>moves.push(c),setIcon(){}};
  const map={setView(){return this},invalidateSize(){},remove(){},on:(n,fn)=>events[n]=fn};
  const w={AbortController,setTimeout:(fn,ms)=>setTimeout(fn,ms>=6000?60000:0),clearTimeout,requestAnimationFrame:f=>f(),navigator:{onLine:true},fetch:async()=>await new Promise(r=>resolveFetch=r),L:{map:()=>map,tileLayer:()=>({addTo(){}}),marker:()=>marker,divIcon:i=>i}};
  const number=manual?'991':'992';
  const selected={...hit,exact:false,streetLine:'Rua Exemplo, '+number};
  const status={},m=createMiniMap(w,{},status,'Rua Exemplo, '+number,{selected,onPointChanged:p=>points.push(p)});
  // Let the request scheduler run without waiting for an external service.
  await new Promise(r=>setTimeout(r,10));assert.equal(points[0],null);
  if(manual)events.click({latlng:{lat:2.81,lng:-60.61}});
  resolveFetch({ok:true,json:async()=>({features:[f({street:'Rua Exemplo',housenumber:number},[-60.62,2.82])]})});
  await m.ready;
  assert.equal(points.at(-1).precision,manual?'manual':'house');
  assert.equal(points.at(-1).lat,manual?2.81:2.82);m.destroy();
 }
 await run(false);await run(true);
});
test('Coordenadas verificadas persistem; aproximadas e não finitas são descartadas; edição para outra casa limpa ponto',()=>{
 let s=C.addManual(C.freshState(),'Rua Exemplo, 28, Boa Vista, RR');s=C.setPoint(s,1,{lat:2.8,lon:-60.6,precision:'manual'});
 assert.equal(C.validateState(s).items[0].point.precision,'manual');const csv=C.exportCsv(s.items);assert.ok(!csv.includes('latitude'));
 let other=C.editItem(s,1,1,'Rua Exemplo, 30, Boa Vista, RR');assert.equal(other.items[0].point,undefined);
 assert.equal(C.setPoint(s,1,{lat:2.8,lon:-60.6,precision:'approximate'}).items[0].point,undefined);
 assert.equal(C.setPoint(s,1,{lat:NaN,lon:-60.6,precision:'house'}).items[0].point,undefined);
});
