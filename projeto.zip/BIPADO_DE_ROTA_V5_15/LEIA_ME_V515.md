# BIPADO DE ROTA — projeto V5.15

Base: ZIP V5.14 fornecido pelo usuário. Código-fonte atualizado (não é APK compilado).

Alterações:
- Contador persistente crescente, não reutiliza numeração excluída.
- Aviso de endereço duplicado recebe botão PULAR PARA PACOTE X, abaixo de VOLTAR.
- Se a captura OCR não cumprir filtros positivos CEP real + Boa Vista-RR + rua e número, a tela não oferece CONFIRMAR; oferece CANCELAR e PULAR PARA PACOTE X. A confirmação normal é preservada somente para captura válida.
- Pacotes pulados aparecem em caixas rosas, estreitas, sem lixeira, uma linha: «Pacote X pulado», em ordem decrescente junto dos demais.
- CSV exportado para Spoke inclui apenas pacotes salvos com endereço; não inclui linhas dos pulados, e mantém numeração nos Notes.
- Menu lateral: Importar Rotas csv (seletor de arquivos do Android). Importação de CSV com colunas Address,Notes e confirmação antes de substituir; lista anterior arquivada por até 24 horas. Falha de análise não altera a lista.
- Restante do app V5.14 preservado.

ATENÇÃO: sem SDK Android/Gradle instalado para gerar ou executar um APK; a compilação final, verificação do fluxo em dispositivo e testes de integração deverão ocorrer no Work/Android Studio.

Testes de parser Kotlin puro realizados: 9 casos do address_parser_test, 43 regressões, 15 identidade/duplicatas e 2 replays de OCR (não usando ML Kit). A suíte completa existente de atualizações tem uma asserção antiga conflitante com a política atual de verificação assíncrona; não foi usada para validar este pacote.
