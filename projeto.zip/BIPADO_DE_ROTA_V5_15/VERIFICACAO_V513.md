# Verificação local V5.13

Compilação Android assembleDebug e lintDebug: sucesso; zero erros e 54 avisos (incluem APIs antigas e recomendações de estilo). APK versão 5.13.0, versionCode65, minSdk26, targetSdk34, arquiteturas arm64-v8a/armeabi-v7a/x86/x86_64. Assinatura conferida e mantida; zipalign aprovado.

108 casos Kotlin passaram: 87 regressões anteriores (incluindo captura reproduzida com Tesseract, não ML Kit) e 21 casos de política de atualização, incluindo falha de consulta, versão igual, versão nova e exigência persistida mais alta. Sete casos Python de recebimento de ZIP passaram (projeto válido, caminho absoluto, travessia, caminho Windows, múltiplos projetos, projeto ausente e link simbólico). Workflow YAML válido.

Não executados: workflow real no GitHub (repositório/segredos ainda não disponíveis), UI e perda de conexão em dispositivo, permissões de instalação e confirmação do instalador Android, atualização real preservando dados no Moto G8 Plus. Não distribuir o APK antes de ativar a primeira release, pois o bloqueio obrigatório impede uso sem consulta bem-sucedida.
