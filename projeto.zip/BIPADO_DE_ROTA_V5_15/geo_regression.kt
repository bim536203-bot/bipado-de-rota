import br.com.leitorencomendas.GeoAddress as G
fun main(){
 val q=G.query("Alameda das Acácias, 587, Casa de Esquina — Pricumã, Boa Vista, RR, 69309-360")
 check(q.street=="Alameda das Acácias");check(q.number=="587");check(q.district=="Pricumã");check(q.postcode=="69309-360")
 check(!q.full.contains("Esquina"))
 check(G.query("578 veg, Boa Vista, RR").let{it.number=="578"&&it.street=="veg"})
 check(G.query("89 ba, Boa Vista, RR").let{it.number=="89"&&it.street=="ba"})
 check(G.streetScore("Rua João Batista","ba")==100)
 check(G.streetScore("Alameda das Acacias","Alameda das Acácias")==100)
 check(G.streetScore("Rua das Palmeiras","Alameda das Acácias")==0)
 check(G.inRegion(2.815698,-60.701482));check(!G.inRegion(-23.5,-46.6));check(!G.inRegion(Double.NaN,-60.7))
 check(G.exactNumber("587","587"));check(!G.exactNumber("587",""));check(!G.exactNumber("587","589"))
 check(G.query("Rua 13 de Maio, 402, Casa, Boa Vista RR").let{it.street=="Rua 13 de Maio"&&it.number=="402"})
 check(G.query("Alameda dos Bambu Salón de Beleza, 1433, Casa").street=="Alameda dos Bambu")
 println("18 geocoding query/precision tests passed")
}
