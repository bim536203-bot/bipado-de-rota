# Investigação e correção — BIPADO DE ROTA 5.10.1

## Conclusão e limites da evidência

Foram comprovados defeitos na passagem de OCR para o parser e nos filtros, reproduzidos executando o AddressExtractor original do ZIP. Alameda e Avenida já estavam na expressão de logradouros: acrescentar palavras não resolveria estes defeitos.

Não existe registro da saída original do ML Kit da leitura que falhou no Moto G8 Plus. Por isso, os defeitos demonstrados são causas comprovadas de falhas equivalentes, mas não se afirma qual deles disparou a ocorrência específica no aparelho. Falha de reconhecimento de caracteres, agrupamento/ordem particular do ML Kit e efeitos da captura ao vivo ainda exigem registro no telefone.

## Defeitos reproduzidos no código original

1. CaptureService passava somente `result.text` a AddressExtractor; descartava `textBlocks`, linhas, elementos e suas caixas. O parser interpretava a sequência concatenada como ordem vertical da tela.
2. O parser cortava tudo depois da primeira ocorrência de cidade e da posição do CEP. Se o bloco `189 BURITIS Boa Vista-RR` vem antes do bloco com a via, o nome da rua desaparece: saída reproduzida `streetLine=""`, CEP 69309-186 e aviso `Nome da rua não identificado com segurança`. Se o CEP vem primeiro, também ocorre perda do endereço.
3. O filtro de navegação/telefone descartava a linha inteira. Simulação com `Alameda das Acácias 587 Casa de navegação` perde a via e o número, mas mantém o CEP de outra linha.
4. A heurística de destinatário removia a primeira linha textual de uma via sem prefixo, por exemplo `das Tres Marias` seguida por `707 Vila...`.
5. `trimLeadingName` arbitrariamente conservava somente as últimas três palavras de nomes longos sem prefixo: podia mutilar logradouros legítimos.
6. O ZIP continha `singleLine=true`, que causa erro Kotlin; o número/nome interno de versão também ainda era 59/5.9.0, incompatível com identificação correta da nova entrega e com atualização sobre o APK anterior de versionCode 60.

Reprodução executável: `tests/baseline/AddressExtractor.kt` + `tests/baseline/reproduce.kt`. A entrada normal funciona; as variações documentadas falham. Estas variações são cenários de agrupamento plausíveis, não registros reais do ML Kit.

## Capturas e recorte

As imagens da J&T medem 1080×2280. O recorte anterior usa aproximadamente x=27..1058 e y=387..1824. A linha do ID fica acima de y=387 e é cortada. O destinatário e as linhas visíveis de endereço/CEP permanecem no recorte destas duas imagens. Portanto, nestas referências, não se comprovou que o recorte corta Alameda/Avenida. Com rolagem, teclado, orientação ou outras resoluções, um recorte fixo pode cortar a primeira linha; isso continua sendo uma limitação real do método antigo.

Não foram atribuídas caixas estimadas ao ML Kit. Os arquivos TSV em `tests/` são resultados efetivos do Tesseract aplicado aos recortes, com coordenadas convertidas para a tela. Esse motor leu ambas as ruas e os números. No exemplo Alameda, retornou `Acacias` sem acento: nenhuma correção inventada de ortografia foi aplicada.

## Correções

- Captura mantém a resolução original e a tela inteira, sem recorte estreito por percentuais e sem uma segunda rodada de OCR. Continua escondendo a bolha e descartando frames antigos antes de ler.
- Novo `OcrLayout.kt`: recebe elementos reais do ML Kit com left/top/right/bottom; ordena e agrupa por posição vertical; reconstitui palavras da esquerda para a direita; usa faixa de conteúdo da esquerda para excluir botões laterais; usa ID e posição da rua para separar destinatário; termina na data. Não depende da ordem de TextBlocks nem supõe que o ML Kit informa negrito.
- Filtros do parser removem trechos de interface, CEP e cidade sem destruir o restante da linha. Removida a amputação de nomes para três palavras. Refinada a distinção entre destinatário e rua dividida em linhas.
- Diagnóstico de falha: grava somente a última falha em arquivo privado `ocr-last-failure.json`, contendo tamanho da imagem, texto bruto, elementos/caixas, seleção e aviso. Não grava captura nem envia dados. Resumo no log `BipadoLeitura`; escrita do arquivo em thread de trabalho. Uma falha posterior substitui a anterior.
- Mantidos minimapa/autocomplete, histórico, restauração, duplicados, CSV Address/Notes, numeração e recursos visuais da V5.10. Ajustes de encerramento removem sobreposições/diálogos, cancelam callbacks e impedem captura concorrente enquanto a confirmação está aberta. Bip de sucesso também ocorre após gravar.
- Mantidos os ajustes de compatibilidade das compilações anteriores: receiver interno não exportado, autorização de captura integral no Android 14+, notificações no Android 13+, restauração de CSV pendente e indicador de serviço ativo.

## Testes realizados antes da compilação

- 9 testes anteriores do parser: endereços conhecidos, cabeçalho, cartão e exclusão de destinatário, incluindo Alameda das Acácias 587.
- 41 casos novos: Alameda, Avenida, Rua, Via, Travessa, ruas/complementos em linhas separadas, nomes longos, texto de navegação, 24 permutações de caixas dos dois exemplos, três escalas de imagem e recusa de entrada sem via/número.
- 2 replays das imagens com palavras e coordenadas reais do Tesseract: Alameda das Acacias 587 Casa de Esquina Pricumã e Avenidas dos a Bandeirante 189 Buritis.
- Total: 52 casos aprovados. `run-regression.sh` permite repetir com Kotlin/JDK instalados. Os TSV não são fixtures do ML Kit; `regression.kt` contém também caixas sintéticas claramente identificáveis.

## Validação ainda necessária no Moto G8 Plus

Não foi executado emulador: não havia emulador/AVD instalado nem dispositivo `/dev/kvm` disponível. Não foi executado ML Kit nativo sobre estas imagens no Android. Testes locais não comprovam desempenho, latência ou reconhecimento da captura real.

Após instalar sobre a V5.9: testar os dois cartões, captura repetida, arraste, confirmação/edição, navegação para histórico, apagar/restaurar, duplicados e CSV/Notes no Spoke. Comparar tempo da captura integral com a anterior. Minimapa e autocomplete continuam dependendo da internet e do provedor geográfico.

Se falhar: manter a tela original e fornecer o diagnóstico da última falha. Em computador com ADB autorizado: `adb shell run-as br.com.leitorencomendas cat files/ocr-last-failure.json`. Log: `adb logcat -s BipadoLeitura`. O JSON contém nomes/endereços e deve ser compartilhado apenas para esta investigação. Isso permitirá distinguir falta de texto no ML Kit de seleção incorreta pelo layout.

## Referência técnica

Google ML Kit documenta acesso a blocos, linhas, elementos e bounding boxes: https://developers.google.com/ml-kit/vision/text-recognition/v2/android . A mudança usa essas coordenadas disponíveis em vez de tratar `result.text` como layout confiável.

## Compilação final

Gradle assembleDebug + lintDebug concluídos. Zero erros e 41 avisos (incluindo APIs Android depreciadas/questões de interface; não são erros de compilação). VersionCode 61, versionName 5.10.1. MinSDK 26, targetSDK 34, compileSDK 35. APK contém ARM64 e ARMv7, além de x86/x86_64. Apksigner passou verificação para APIs 29 a 36, zipalign passou. Assinatura igual à usada nas versões anteriores, inclusive V5.9. Sons WAV e asset do mapa conferidos byte a byte contra o projeto. Não houve instalação nem execução no Moto G8 Plus.
