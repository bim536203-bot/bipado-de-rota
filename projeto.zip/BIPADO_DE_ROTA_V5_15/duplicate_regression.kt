import br.com.leitorencomendas.AddressIdentity as D
fun main(){
 val base="Rua das Campainhas, 402, Oficina (t+) Mecanica, Pricumã, Boa Vista, RR, 69309-470, Brasil"
 val pairs=listOf(
  Triple(base,"Rua das Campainhas, 402, Oficina () Mecanica",true),
  Triple(base,"R. das Campainhas, 402, Casa 2",true),
  Triple(base,"Rua das Campainhas 402 Oficina",true),
  Triple(base,"Rua das Campainhas, 403, Oficina",false),
  Triple(base,"Rua das Palmeiras, 402, Oficina",false),
  Triple("Alameda das Acácias, 587, Casa","Al. das Acacias, 587, Esquina",true),
  Triple("Avenida Brasil, 10","Av. Brasil, 10",true),
  Triple("Rua 13 de Maio, 402","Rua 13 de Maio, 403",false),
  Triple("Via das Flores, 261","Via das Flores, 261A",false),
  Triple("Travessa Flores, 20, apartamento 101","Tv. Flores, 20, apartamento 102",true),
  Triple("Rua sem número","Rua outra sem número",false)
 )
 for((a,b,wanted) in pairs)check(D.same(a,b)==wanted){"$a / $b => ${D.key(a)} / ${D.key(b)}"}
 val nine="Alameda dos Bambu Salón de Beleza Perla Bela Alameda dos Bambu Salón de Beleza Perla Bela, 1433, Pricumã"
 val ten="Alameda dos Bambu Salón de (t) Beleza Perla Bela Alameda dos Bambu Salón de Beleza Perla Bela, 1433, Pricumã"
 check(D.same(nine,ten))
 check(D.same(nine,"Alameda dos Bambu, 1433, Casa"))
 check(!D.same(nine,"Alameda dos Bambu, 1434, Casa"))
 check(br.com.leitorencomendas.AddressText.clean("Rua Botão-de-ouro 102 Rua (t) Botão-de-ouro 102")=="Rua Botão-de-ouro 102")
 println("15 duplicate/text identity tests passed")
}
