# BIPADO DE ROTA V5.4 — código-fonte Android

Projeto não compilado neste ambiente (Android SDK/Gradle indisponíveis).

## Atualizações aplicadas
- Endereços da J&T reconhecidos por ML Kit OCR e interpretados por `AddressExtractor`, testado com quatro exemplos enviados.
- Tela de confirmação sobre a J&T com painel branco arredondado, cabeçalho Pacote N grande, primeiro bloco de rua/número/complemento/bairro e segundo bloco independente para cidade/UF/CEP. Botões Cancelar/Confirmar e pequeno lápis no canto superior direito que abre edição de ambos os blocos.
- O botão flutuante utiliza o PNG original azul e branco aprovado, sem alterar o símbolo interno.
- Na exportação `BAIXAR ROTAS`, o CSV possui duas colunas distintas: `Address` (endereço completo com cidade, UF, CEP disponível e Brasil) e `Notes` (exatamente `PACOTE 1`, `PACOTE 2`, etc.). O número usado é o do cadastro, inclusive após edição.
- Mantidos: tela cheia de endereços em cartões com editar, lixeira com confirmação, nome BIPADO DE ROTA, INICIAR BIPE cinza/PARA LEITURA BIPE vermelho, crédito de autoria.
- A captura mantém um único VirtualDisplay por permissão MediaProjection para compatibilidade com Android 14.

## ALERTA IMPORTANTE — integração Spoke
O app Spoke exibiu `Adicionar notas` vazio ao importar uma versão anterior do CSV. Não foi possível verificar documentalmente o mapeamento de `Notes` para este campo nem executar o aplicativo Spoke neste ambiente. Assim, o CSV gerado contém `PACOTE N` na coluna Notes, mas a importação **não está validada** e NÃO deve ser anunciada como funcionando até teste real na versão instalada do Spoke.

## Teste recomendado antes de uso em entregas
1. Compilar com Android Studio/Android SDK e Gradle; corrigir erros que o build detectar.
2. Instalar no Moto G8 Plus (Android 10) e conferir permissões de overlay e MediaProjection.
3. Testar 10+ endereços diversos da J&T. Conferir captura, OCR, CEP, rua/número e edição por lápis.
4. Capturar consecutivamente mais de uma encomenda na mesma sessão.
5. Exportar CSV com 2 pacotes e inspecionar os valores Address e Notes. Importar no Spoke e verificar se o campo Adicionar notas contém PACOTE 1 e PACOTE 2; se não, confirmar o mapeamento oficial/importador do Spoke e adaptar o formato antes de declarar sucesso.
6. Não mudar ID do pacote Android nem chave de assinatura de atualização sem planejamento, para preservar dados já salvos.

Os prints e arquivos de imagem utilizados na conversa podem conter dados de clientes. Este código não envia dados a serviços externos por conta própria.
