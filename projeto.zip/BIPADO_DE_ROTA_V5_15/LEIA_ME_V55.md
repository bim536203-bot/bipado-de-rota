# BIPADO DE ROTA V5.5 — projeto Android para compilação

Mudanças: tela principal colorida com 3 botões centralizados; botão vermelho enquanto a leitura está ativa; lista com botão VOLTAR azul, lixeira geral e lixeiras individuais com confirmação; arquivo de rota nomeado automaticamente pelo dia local da semana, ainda editável no seletor Android; botão flutuante usa o launcher original e oferece menu FECHAR ao manter pressionado por 1,5 s; estado do botão principal sincronizado com o serviço de captura; bip de sucesso (0,2 s) no reconhecimento e alerta grave duplo de erro; janela de confirmação anterior mantida; notas CSV com `PACOTE N`.

ATENÇÃO: Este ZIP contém código-fonte, não um APK. Requer compilação e teste real em aparelho Android. A importação do campo Notes no Spoke NÃO foi validada; o CSV gera `Address,Notes`, mas o Spoke pode exigir outra coluna ou modo de importação. Testar esta integração antes de uso em serviço.

Não foram realizadas verificações de build Android porque este ambiente não possui Android SDK/Gradle. O extrator de endereços foi executado isoladamente com os quatro exemplos incluídos no projeto.

A permanência de dados entre versões depende de instalar usando o mesmo applicationId e assinatura compatível. Faça backup de seus endereços antes de atualizar.
