import br.com.leitorencomendas.AddressExtractor
fun main(){
 val cases=listOf(
 "normal" to "Carla Souza\nBuritis . Avenidas dos a bandeirante\n189 BURITIS Boa Vista-RR\n69309186",
 "CEP block first" to "69309186\nCarla Souza\nBuritis . Avenidas dos a bandeirante\n189 BURITIS Boa Vista-RR",
 "number block first" to "189 BURITIS Boa Vista-RR\n69309186\nCarla Souza\nBuritis . Avenidas dos a bandeirante",
 "UI on address line" to "Anderson de Souza\nAlameda das Acácias 587 Casa de navegação\nesquina PRICUMA Boa Vista-RR\n69309360",
 "split street without type" to "das Tres Marias\n707 Vila PRICUMA Boa Vista-RR\n69309670"
 );cases.forEach{println(it.first+" => "+AddressExtractor.parse(it.second))}
}
