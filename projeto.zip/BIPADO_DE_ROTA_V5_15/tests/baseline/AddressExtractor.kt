package br.com.leitorencomendas

import java.util.Locale

/** Leitura offline de cartão J&T: cabeçalho, rastreio e destinatário NÃO são endereço. */
object AddressExtractor {
 data class Result(val streetLine:String,val locationLine:String,val warning:String="")
 private val locale=Locale.forLanguageTag("pt-BR")
 private val cep=Regex("""(?<!\d)(\d{5})[-.\s]?(\d{3})(?!\d)""")
 private val city=Regex("""(?i)\bBoa\s*Vista\s*[-,/ ]*\s*RR\b""")
 private val date=Regex("""\b20\d{2}[-/]\d{2}[-/]\d{2}.*""")
 private val tracking=Regex("""(?<!\d)\d{9,22}(?!\d)""")
 private val road=Regex("""(?i)\b(?:ruas?|r\.?|avenidas?|av\.?|vias?|travessas?|tv\.?|alamedas?|al\.?|estradas?|rodovias?|passagens?|praças?|pracas?|becos?|vielas?|ladeiras?|ramais?|conjuntos?|servidões?|servidoes?)\b""")
 private val number=Regex("""(?<!\d)\b(\d{1,5})(?!\d)""")
 private val bairro=Regex("""(?i)\b(?:BURITIS|PRICUM[AÃ]|CIDADE SAT[EÉ]LITE|LIBERDADE|CAUAM[EÉ]|CARAN[AÃ]|CAIMB[EÉ]|J[OÓ]QUEI CLUBE|S[ÃA]O FRANCISCO|CENTRO|MECEJANA|PINTOL[ÂA]NDIA|SENADOR H[EÉ]LIO CAMPOS|DR SILVIO LEITE)\b""")
 private val noise=Regex("""(?i)(?:whatsapp|telefone|navega[cç][aã]o|procurar|n[uú]mero [uú]nico|entrega pendente|assinar)""")
 private fun clean(s:String)=s.replace(Regex("""\s+""")," ").trim(' ',',','.',';',':','-')
 private fun title(s:String)=clean(s).lowercase(locale).split(' ').joinToString(" "){v->if(v in setOf("de","da","do","das","dos","e","a"))v else v.replaceFirstChar{it.titlecase(locale)}}
 private fun location(code:String)="Boa Vista, RR"+(if(code.isNotEmpty())", $code" else "")
 private fun normalizeSimple(s:String)=java.text.Normalizer.normalize(s.lowercase(locale),java.text.Normalizer.Form.NFD).replace(Regex("""\p{M}+"""),"")

 private fun trimLeadingName(candidate:String):String {
  val c=clean(candidate)
  val match=road.find(c)
  if(match!=null && match.range.first>0) return clean(c.substring(match.range.first))
  val n=number.find(c) ?: return c
  val before=clean(c.substring(0,n.range.first))
  if(before.length<8) return c
  val districtAtStart=bairro.find(before)?.range?.first==0
  if(districtAtStart) return c
  val words=before.split(' ').filter{it.isNotBlank()}
  return if(words.size>=5) clean(words.takeLast(3).joinToString(" ")+" "+c.substring(n.range.first)) else c
 }

 fun parse(raw:String):Result {
  val lines=raw.lines().map(::clean).filter {it.isNotEmpty()}
  val trackIndex=lines.indexOfFirst{tracking.matches(it.replace(" ",""))}
  var section=if(trackIndex>=0)lines.drop(trackIndex+1) else lines
  section=section.takeWhile{!date.containsMatchIn(it)}
   .filterNot{tracking.matches(it.replace(" ",""))||noise.containsMatchIn(it)}
  if(section.size>1 && !road.containsMatchIn(section.first()) &&
    !bairro.containsMatchIn(section.first()) && !cep.containsMatchIn(section.first()) && !number.containsMatchIn(section.first()))section=section.drop(1)
  if(section.isEmpty())return Result("",location(""),"Endereço não identificado. Use o lápis.")

  var text=section.joinToString(" ")
  text=tracking.replace(text," ")
  val zip=cep.findAll(text).lastOrNull()
  val cepValue=zip?.let{"${it.groupValues[1]}-${it.groupValues[2]}"}.orEmpty()
  if(zip!=null)text=text.substring(0,zip.range.first)
  val cityMatch=city.find(text)
  if(cityMatch!=null)text=text.substring(0,cityMatch.range.first)
  text=clean(text)

  val typed=road.find(text)
  var prefixDistrict=""
  if(typed!=null) {
   val prefix=text.substring(0,typed.range.first)
   prefixDistrict=bairro.find(prefix)?.value.orEmpty()
   text=clean(text.substring(typed.range.first))
  } else {
   val d=bairro.find(text)
   if(d!=null && d.range.first==0){
    prefixDistrict=d.value
    text=clean(text.substring(d.range.last+1).trimStart('.',' '))
   }
  }

  text=trimLeadingName(text)
  val n=number.find(text) ?: return Result("",location(cepValue),"Número da residência não identificado. Confira pelo lápis.")
  var street=clean(text.substring(0,n.range.first))
  if(street.isBlank()){
   val fallback=trimLeadingName(section.joinToString(" "))
   val n2=number.find(fallback)
   if(n2!=null) street=clean(fallback.substring(0,n2.range.first))
  }
  if(street.length<4||street.none{it.isLetter()}||tracking.containsMatchIn(street))
   return Result("",location(cepValue),"Nome da rua não identificado com segurança. Use o lápis.")

  val remainder=clean(text.substring(n.range.last+1))
  val d=bairro.find(remainder)
  val district=d?.value?:prefixDistrict
  val extra=clean(if(d!=null)remainder.substring(0,d.range.first) else remainder).take(55)
  val districtDisplay=when(normalizeSimple(district).uppercase(locale)){
   "PRICUMA" -> "Pricumã"
   else -> title(district)
  }
  val address=buildString {
   append(title(street));append(", ");append(n.value)
   if(extra.isNotBlank())append(", ${title(extra)}")
   if(districtDisplay.isNotBlank())append(" — $districtDisplay")
  }
  val warning=when {
   cepValue.isBlank()->"CEP não identificado. Confira antes de salvar."
   districtDisplay.isBlank()->"Bairro não identificado. Confira o endereço."
   else->""
  }
  return Result(address,location(cepValue),warning)
 }
}
