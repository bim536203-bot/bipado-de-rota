# BIPADO DE ROTA — V5.6 (projeto-fonte Android)

Esta entrega é o CÓDIGO-FONTE, não um APK compilado. Abrir como projeto Android Gradle e compilar `assembleDebug` com Android SDK 35 / JDK 17. Instalação no Android exige gerar APK a partir do projeto. Não há certificação de compilação/dispositivo nesta entrega: ambiente atual não inclui Android SDK/Gradle, então não foi possível executar testes instrumentados.

## Atualizações implementadas
- Ícones da interface substituídos por vetores Android (scan, salvos, download, parar, lixeiras, lápis); removidos os glifos Unicode que ficavam quadrados.
- Ícone flutuante: toque simples captura; pressionar e arrastar reposiciona sem capturar; removido menu FECHAR e vibração associada. Parar pelo botão principal.
- Captura: removida espera de 350ms, substituída por 110ms; listener de imagens e conversão de bitmap em thread específica; recorte espacial em proporções de tela elimina barra de pesquisa da J&T e regiões inferiores inúteis. OCR permanece com ML Kit local, sem enviar captura pela internet.
- Parser do endereço: começa no primeiro marcador de logradouro; descarta barra de pesquisa, código de rastreio, textos de interface e data; extrai rua/número/CEP/cidade/bairro; caso não reconheça elementos importantes solicita edição manual. Mantida nota "PACOTE N" no CSV para Spoke.
- Testes unitários simples do parser: `kotlinc app/src/main/java/br/com/leitorencomendas/AddressExtractor.kt address_parser_test.kt -include-runtime -d /tmp/test.jar && java -jar /tmp/test.jar`.

## Limitações e verificações essenciais
- A leitura visual nesta conversa é feita por modelo multimodal e NÃO equivale ao ML Kit local; o APK não garante leitura perfeita de todos os endereços.
- Tempos inferiores a 1 segundo são meta, não resultado medido no Moto G8 Plus. Pode haver espera maior na primeira leitura.
- Recorte se baseia na posição relativa da J&T em retrato; outras telas, rolagem e diferentes layouts podem requerer ajuste após testes reais.
- Confira o endereço antes de confirmar. CSV Notes no Spoke ainda precisa de teste de importação real.
- Antes de distribuir, compilar, instalar, exercitar capturas sucessivas, arraste, permissões de tela e importação CSV.
