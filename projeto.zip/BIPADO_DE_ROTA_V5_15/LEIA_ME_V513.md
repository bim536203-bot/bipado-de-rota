# BIPADO DE ROTA V5.13 — atualização obrigatória

Esta versão requer um repositório de atualizações ativo. Não distribuir antes de publicar a primeira release com APK e update.json. O endereço padrão preparado é bim536203-bot/bipado-de-rota; alterável por -PupdateRepository.

Conforme solicitado pelo usuário, a consulta de versão falha fechada: sem internet, erro do servidor ou arquivo de versão inválido não libera o uso. Uma atualização detectada é persistida e mantém o bloqueio até que a versão exigida esteja instalada. O botão ATUALIZAR baixa e verifica o APK; a confirmação da instalação continua pertencendo ao Android. Cancelar o instalador mantém a tela obrigatória.

As verificações são feitas fora da tela principal. Na inicialização e na volta à tela principal é consultada a versão (intervalo mínimo 15 segundos para evitar uma segunda consulta ao sair da própria verificação). O acesso depende de internet validada pelo Android. A perda de rede bloqueia a tela ativa e para o serviço flutuante. Os dados salvos não são apagados. O APK baixado deve corresponder ao pacote, versão, tamanho, SHA-256 e certificado já instalado.

Configuração da compilação: JDK17, Gradle8.9, Android SDK35. A assinatura e GEOAPIFY_API_KEY continuam externas. As propriedades ciVersionCode e ciVersionName permitem aumentar a versão na automação. Preserve Updater.kt, UpdateActivity.kt, UpdatePolicy.kt, BipadoApplication.kt e as declarações no manifesto nas próximas versões.

Os recursos V5.12 foram preservados. O ZIP de automação separado contém o workflow e as instruções de ativação. O repositório e os segredos não foram configurados por falta dessa capacidade no acesso conectado. Testes locais e compilação não substituem teste da instalação pelo Android nem execução real do workflow no GitHub.
