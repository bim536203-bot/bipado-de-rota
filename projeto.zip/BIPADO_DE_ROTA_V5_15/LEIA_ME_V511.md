# BIPADO DE ROTA V5.11.0 — correções aprovadas

1. Mesmo nome de rua e mesmo número identificam o mesmo destino. Complemento, empresa, bairro/CEP e descrição diferentes não impedem a identificação quando rua e número foram extraídos. Mantidas diferenças de número (402/403 e 261/261A). Abreviações de logradouro e acentos são normalizados. A mesma regra atende ao bipe, confirmação, inclusão e edição via Store.matchingIndex. Endereços já gravados são comparados pela regra nova, sem migração destrutiva.
2. Limpeza de trechos adjacentes repetidos e artefatos conhecidos `(t)`, `(t+)`, `()`. Nome do estabelecimento antes do número é separado da via quando identificado por marcadores, como Salón/Salão, Oficina, Hospital etc. A limpeza é usada na leitura e na chave de comparação. Ela não pretende corrigir automaticamente toda grafia incerta do OCR; conferir sempre antes de salvar.
3. Endereços salvos são exibidos do último incluído para o primeiro. Editar o número não muda a posição de inclusão. Editar e excluir continuam usando o índice original do registro; a ordem de armazenamento/exportação não é invertida.
4. Endereço já bipado toca o som de erro existente, sem bip de sucesso anterior à verificação. O som e o design do alerta são preservados; beep de sucesso ocorre nas leituras válidas novas e após gravar.

## Dados existentes

Nenhum pacote já salvo é apagado, renumerado ou mesclado automaticamente. Duplicados antigos permanecem para exclusão manual. A regra nova os reconhece em leituras futuras; os textos antigos não são reescritos automaticamente na lista.

## Testes

69 casos locais passaram: 43 de parser/layout, 15 de identidade/limpeza de duplicados, 9 anteriores e 2 replays de screenshots (Tesseract, não ML Kit). Incluem Campainhas 402 com complementos diferentes, Alameda dos Bambu 1433 com descrição repetida, Botão-de-ouro 102 duplicado no texto, número diferente, rua diferente, abreviações, acentos e complementos de apartamento diferentes (tratados como mesmo destino, conforme regra aprovada).

O diagnóstico de última falha OCR e a seleção por coordenadas da V5.10.1 continuam. Histórico, minimapa, botão flutuante, CSV Address/Notes e numeração preservados.

Testar no Moto G8 Plus: bipe repetido, som do alerta, endereço após limpeza, lista recente no topo, editar/excluir o cartão correto, histórico/restauração e exportação. Nenhum teste local substitui execução do ML Kit e da interface no telefone.

O ZIP não inclui chave privada. O APK entregue usa a assinatura anterior. Para recompilar com essa assinatura, fornecer bipadoSigningKey conforme COMO_COMPILAR.md.

## Compilação
Gradle assembleDebug e lintDebug concluídos: zero erros, 41 avisos. VersionCode 63, versionName 5.11.0. Apksigner e zipalign aprovados; arquitetura ARM64/ARMv7 e requisitos de Android 10 conferidos. Sem instalação/teste em aparelho nesta entrega.
