# BIPADO DE ROTA – V5.10 (consolidada)

Alterações consolidadas nesta versão:

1. **Aviso de endereço já bipado**
   - mantém o design aprovado;
   - destaque maior para **PACOTE X** em letras maiúsculas;
   - botão cinza **VOLTAR** no lugar da mensagem vermelha inferior;
   - fecha ao tocar em **VOLTAR**, fora da janela, ou no botão voltar do Android.

2. **Histórico de lista apagada**
   - cada caixinha do histórico agora possui **lixeira individual**;
   - permite apagar manualmente uma lista do histórico sem esperar 24 horas;
   - a limpeza automática após 24 horas continua ativa.

3. **Menu da tela inicial**
   - ícone de três pontinhos reposicionado para o **canto superior direito da tela**, conforme aprovado.

4. **Leitura de endereços**
   - reforços no parser para melhorar identificação de endereços com **Avenida / Av. / Alameda / Al.**;
   - reforço da exclusão de **nome do cliente** e **ID do pacote** da linha do endereço.

5. **Demais funções anteriores permanecem**
   - mini mapa na confirmação/edição;
   - histórico e restauração de listas apagadas;
   - bloqueio para endereço duplicado;
   - autocomplete de edição com sugestões.
