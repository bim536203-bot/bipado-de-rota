#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
src=app/src/main/java/br/com/leitorencomendas
kotlinc "$src/AddressExtractor.kt" "$src/OcrLayout.kt" "$src/AddressIdentity.kt" "$src/AddressText.kt" "$src/GeoAddress.kt" "$src/UpdatePolicy.kt" update_regression.kt geo_regression.kt address_parser_test.kt regression.kt duplicate_regression.kt screenshot_replay.kt -include-runtime -d "$work/tests.jar"
java -cp "$work/tests.jar" Update_regressionKt
java -cp "$work/tests.jar" Geo_regressionKt
java -cp "$work/tests.jar" Address_parser_testKt
java -cp "$work/tests.jar" RegressionKt
java -cp "$work/tests.jar" Duplicate_regressionKt
java -cp "$work/tests.jar" Screenshot_replayKt
kotlinc tests/baseline/AddressExtractor.kt tests/baseline/reproduce.kt -include-runtime -d "$work/baseline.jar"
java -cp "$work/baseline.jar" ReproduceKt
