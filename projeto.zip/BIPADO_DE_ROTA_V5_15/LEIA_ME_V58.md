BIPADO DE ROTA V5.8 — projeto Android Kotlin (FONTE, NÃO APK)

Correções desta versão sobre a V5.7:
- AddressExtractor: após o código de rastreamento, exclui o nome isolado do destinatário antes de interpretar os textos de endereço. Mantém suporte a Via, Rua, Avenida, Alameda, Travessa e logradouros sem prefixo.
- Barra Endereços salvos: botão VOLTAR e lixeira branca AGORA separados num LinearLayout; confirmação de exclusão total preservada; exclusão individual mantida.
- Mapa: ícone de alfinete vermelho; zoom de rua; resultados aproximados identificados como tais; consulta primeiro pela rua sem CEP e complemento; evita resultados fora da região de Boa Vista e pontos turísticos/estabelecimentos sem tipo de via confiável. Sugestões durante edição continuam sendo assíncronas, com seleção manual.
- Funcionalidades preexistentes mantidas: OCR ML Kit; botão flutuante arrastável; sons; edição; listagem; exportação CSV.

IMPORTANTE: o desenho do mapa foi APROXIMADO com Leaflet + OpenStreetMap, não é o SDK Google Maps. Serviços Photon/OSM são GRATUITOS em uso moderado, porém possuem limites, exigem internet e podem não localizar a rua. O app NÃO deve inventar um marcador onde não há posição segura. Autocomplete Photon não oferece a mesma cobertura que Google Places. Verifique termos/limites do serviço para uso intensivo em produção.

Validação: os 8 testes locais de AddressExtractor passaram. mapa.html passou teste sintático JS. ZIP verificado. Não há Android SDK/Gradle para compilar e testar APK neste ambiente. Work deve compilar, corrigir eventuais erros e testar no dispositivo ANTES de considerá-lo pronto.

IMPORTANTE: confirme exportação CSV/Notes no Spoke com uma rota real; não foi comprovado aqui.
