import br.com.leitorencomendas.OcrLayout as L
import br.com.leitorencomendas.AddressExtractor as A
fun main(){
val alameda=listOf(L.Span("Anderson",75,455,281,492),L.Span("de",296,455,347,492),L.Span("Souza",361,456,492,492),L.Span("Alameda",76,544,238,575),L.Span("das",253,544,317,575),L.Span("Acacias",331,544,476,575),L.Span("587",493,545,559,575),L.Span("Casa",574,545,663,575),L.Span("de",678,544,721,575),L.Span("(ph)",790,532,856,598),L.Span("navegacgao",867,548,1041,591),L.Span("esquina",77,594,219,633),L.Span("PRICUMA",236,594,413,624),L.Span("Boa",428,594,494,624),L.Span("Vista-RR",508,594,665,624),L.Span("69309360",78,643,264,673),L.Span("(®&)",790,633,855,698),L.Span("telefone",864,651,997,680),L.Span("2026-10-12",77,728,254,754),L.Span("08:26:14",266,728,401,754),L.Span("a)",81,856,141,920),L.Span("WhatsApp",151,874,341,914),L.Span("Cine",641,786,863,976),L.Span("JO",894,786,1021,976))
val alamedaResult=A.parse(L.select(alameda,1080,2280).text)
check(alamedaResult.streetLine=="Alameda das Acacias, 587, Casa de Esquina — Pricumã"){alamedaResult.toString()}
println(alamedaResult)
val avenida=listOf(L.Span("Carla",76,455,188,492),L.Span("Souza",202,456,333,492),L.Span("Buritis",79,545,191,575),L.Span(".",212,571,213,575),L.Span("Avenidas",226,544,393,575),L.Span("dos",407,544,473,575),L.Span("a",487,553,505,575),L.Span("bandeirante",521,544,738,575),L.Span("(ph)",790,532,856,598),L.Span("navegacgao",866,552,1042,587),L.Span("189",79,594,144,624),L.Span("BURITIS",161,594,305,625),L.Span("Boa",321,594,387,624),L.Span("Vista-RR",401,594,558,624),L.Span("69309186",78,643,265,673),L.Span("(&)",790,632,856,698),L.Span("telefone",864,651,997,680),L.Span("2026-10-10",77,728,253,754),L.Span("17:30:52",267,728,401,754),L.Span("a)",81,856,141,920),L.Span("WhatsApp",151,874,341,914))
val avenidaResult=A.parse(L.select(avenida,1080,2280).text)
check(avenidaResult.streetLine=="Avenidas dos a Bandeirante, 189 — Buritis"){avenidaResult.toString()}
println(avenidaResult)
println("2 screenshot OCR replay cases passed (Tesseract, not ML Kit)")
}