package br.com.leitorencomendas

/** Mandatory positive evidence from the actual OCR selection, never manufactured by the parser. */
object CaptureAddressValidation {
 private val zip=Regex("""(?<!\d)\d{5}[-.\s]?\d{3}(?!\d)""")
 private val city=Regex("""(?i)\bBoa\s*Vista\s*[-,/ ]*\s*RR\b""")
 private val house=Regex("""(?<!\d)\b\d{1,5}\b(?!\d)""")
 private val street=Regex("""(?i)\b(?:ruas?|r\.?|avenidas?|av\.?|alamedas?|al\.?|travessas?|tv\.?|vias?|estradas?|rodovias?|becos?|passagens?)\b""")
 fun valid(ocr:String,result:AddressExtractor.Result):Boolean {
  // Requires explicit city, CEP and street number in the SAME isolated parcel OCR selection.
  val s=ocr.replace('\n',' ')
  if(!zip.containsMatchIn(s) || !city.containsMatchIn(s))return false
  if(result.streetLine.isBlank() || result.locationLine.isBlank())return false
  val roadPart=result.streetLine.substringBefore('—')
  return house.containsMatchIn(roadPart) && (street.containsMatchIn(roadPart) || roadPart.substringBefore(',').split(' ').size>=2)
 }
}
