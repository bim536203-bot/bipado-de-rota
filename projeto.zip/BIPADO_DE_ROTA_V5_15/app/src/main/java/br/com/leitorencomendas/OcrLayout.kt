package br.com.leitorencomendas

/** Pure geometry adapter. Input is ML Kit elements, not its concatenated block order. */
object OcrLayout {
 data class Span(val text:String,val left:Int,val top:Int,val right:Int,val bottom:Int)
 data class Selection(val text:String,val lines:List<String>,val reason:String)
 private val tracking=Regex("""^\d{9,22}$""")
 private val date=Regex("""\b20\d{2}[-/]\d{2}[-/]\d{2}""")
 private val ui=Regex("""(?i)^(?:navegação|navegacao|telefone|whatsapp|assinar|procurar|número|único)$""")
 private val road=Regex("""(?i)\b(?:ruas?|avenidas?|av\.?|vias?|travessas?|alamedas?|estradas?|rodovias?)\b""")
 fun select(spans:List<Span>,width:Int,height:Int):Selection {
  if(width<=0 || height<=0)return Selection("",emptyList(),"invalid image")
  // Broad screen bounds: crop/scroll must not remove the first address line.
  val candidates=spans.filter {it.text.isNotBlank() && it.left<width*.72 && it.top>=height*.08 && it.bottom<=height*.96 && !ui.matches(it.text.trim())}
   .sortedWith(compareBy<Span>{it.top}.thenBy{it.left})
  val rows=mutableListOf<MutableList<Span>>()
  for(s in candidates){
   val center=(s.top+s.bottom)/2.0
   val row=rows.lastOrNull()
   val reference=row?.firstOrNull()
   if(reference!=null && kotlin.math.abs(center-(reference.top+reference.bottom)/2.0)<=minOf(s.bottom-s.top,reference.bottom-reference.top)*.55)row.add(s)
   else rows.add(mutableListOf(s))
  }
  var lines=rows.map {row->row.sortedBy{it.left}.joinToString(" "){it.text.trim()}}.filter {it.isNotBlank()}
  val track=lines.indexOfFirst {tracking.matches(it.replace(" ",""))}
  if(track>=0)lines=lines.drop(track+1)
  lines=lines.takeWhile {!date.containsMatchIn(it)}
  val street=lines.indexOfFirst {road.containsMatchIn(it)}
  if(street>0)lines=lines.drop(street)
  else if(street<0 && track>=0 && lines.size>1)lines=lines.drop(1) // recipient below tracking
  return Selection(lines.joinToString("\n"),lines,"vertical element rows; track=$track street=$street")
 }
}
