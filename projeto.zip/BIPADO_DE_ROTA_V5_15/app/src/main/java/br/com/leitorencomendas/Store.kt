package br.com.leitorencomendas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Todas as alterações de lista/histórico são gravadas em uma única transação de preferências. */
object Store {
 const val RETENTION_MS = 24L * 60L * 60L * 1000L
 private fun prefs(c:Context) = c.getSharedPreferences("deliveries",0)
 private fun initial(c:Context):JSONObject {
  val legacy=prefs(c).getString("items","[]") ?: "[]"
  return JSONObject().put("items",try{JSONArray(legacy)}catch(_:Exception){JSONArray()}).put("history",JSONArray()).put("lastNumber",0)
 }
 @Synchronized private fun state(c:Context):JSONObject {
  val s=try{JSONObject(prefs(c).getString("state", "")!!)}catch(_:Exception){initial(c)}
  val h=s.optJSONArray("history") ?: JSONArray()
  val now=System.currentTimeMillis()
  val current=JSONArray()
  for(i in 0 until h.length()) {
   val item=h.optJSONObject(i) ?: continue
   val at=item.optLong("deletedAt",0)
   if(at>0 && at<=now && now-at<RETENTION_MS)current.put(item)
  }
  if(current.length()!=h.length()) {s.put("history",current);save(c,s)}
  return s
 }
 private fun save(c:Context,s:JSONObject):Boolean = prefs(c).edit().putString("state",s.toString()).commit()
 @Synchronized fun all(c:Context):JSONArray=JSONArray(state(c).optJSONArray("items")!!.toString())
 @Synchronized fun history(c:Context):JSONArray=JSONArray(state(c).optJSONArray("history")!!.toString())
 fun normalize(address:String)=AddressIdentity.normalize(address)
 fun matchingIndex(items:JSONArray,address:String,except:Int=-1):Int {
  val key=normalize(address)
  if(key.isBlank())return -1
  for(i in 0 until items.length())if(i!=except && AddressIdentity.same(items.optJSONObject(i)?.optString("address") ?: "",address))return i
  return -1
 }
 @Synchronized fun matching(c:Context,address:String):JSONObject? {
  val list=all(c);val index=matchingIndex(list,address)
  return if(index>=0)list.getJSONObject(index) else null
 }
 private fun highest(s:JSONObject):Int {
  val items=s.optJSONArray("items") ?: JSONArray()
  val skipped=s.optJSONArray("skipped") ?: JSONArray()
  // Empty active routes start again at 1, including states saved by older versions.
  if(items.length()==0 && skipped.length()==0)return 0
  var maximum=s.optInt("lastNumber",0)
  for(i in 0 until items.length()) maximum=maxOf(maximum,items.optJSONObject(i)?.optInt("number",0) ?: 0)
  for(i in 0 until skipped.length()) maximum=maxOf(maximum,skipped.optInt(i,0))
  return maximum
 }
 @Synchronized fun nextNumber(c:Context):Int=highest(state(c))+1
 /** Reserve exactly the current next number; never create a dummy address for a skipped package. */
 @Synchronized fun skipNext(c:Context,expected:Int):Boolean {
  val s=state(c)
  if(expected!=highest(s)+1)return false
  val skips=s.optJSONArray("skipped") ?: JSONArray().also{s.put("skipped",it)}
  skips.put(expected)
  s.put("lastNumber",expected)
  return save(c,s)
 }
 @Synchronized fun skipped(c:Context):JSONArray=JSONArray((state(c).optJSONArray("skipped") ?: JSONArray()).toString())

 @Synchronized fun add(c:Context,address:String,number:Int):Boolean {
  val s=state(c);val a=s.optJSONArray("items")!!
  if(number!=highest(s)+1 || address.isBlank() || matchingIndex(a,address)>=0)return false
  for(i in 0 until a.length())if(a.getJSONObject(i).optInt("number",i+1)==number)return false
  a.put(JSONObject().put("address",address.trim()).put("number",number).put("createdAt",System.currentTimeMillis()))
  s.put("lastNumber",number)
  return save(c,s)
 }
 /** Apagar tudo sempre faz snapshot antes de limpar. Exclusões individuais não entram no histórico. */
 @Synchronized fun clear(c:Context):Boolean {
  val s=state(c);val old=s.optJSONArray("items")!!
  if(old.length()==0 && (s.optJSONArray("skipped")?.length() ?: 0)==0){
   if(s.optInt("lastNumber",0)==0)return true
   s.put("lastNumber",0);return save(c,s)
  }
  val h=s.optJSONArray("history")!!
  h.put(JSONObject().put("deletedAt",System.currentTimeMillis()).put("items",JSONArray(old.toString())).put("skipped",JSONArray((s.optJSONArray("skipped") ?: JSONArray()).toString())))
  s.put("items",JSONArray());s.put("skipped",JSONArray());s.put("lastNumber",0);return save(c,s)
 }
 @Synchronized fun restore(c:Context,deletedAt:Long):Boolean {
  val s=state(c);val h=s.optJSONArray("history")!!
  val selected=(0 until h.length()).mapNotNull{h.optJSONObject(it)}.firstOrNull{it.optLong("deletedAt")==deletedAt} ?: return false
  val restoring=selected.optJSONArray("items") ?: return false
  if(restoring.length()==0 && (selected.optJSONArray("skipped")?.length() ?: 0)==0)return false
  val old=s.optJSONArray("items")!!
  if(old.length()>0 || (s.optJSONArray("skipped")?.length() ?: 0)>0)h.put(JSONObject().put("deletedAt",System.currentTimeMillis()).put("items",JSONArray(old.toString())).put("skipped",JSONArray((s.optJSONArray("skipped") ?: JSONArray()).toString())))
  s.put("items",JSONArray(restoring.toString()))
  s.put("skipped",JSONArray((selected.optJSONArray("skipped") ?: JSONArray()).toString()))
  s.put("lastNumber",highest(s))
  return save(c,s)
 }
 /** All-or-nothing CSV import. Old active list (and skipped placeholders) is retained in history. */
 @Synchronized fun replaceWithImport(c:Context,imported:JSONArray):Boolean {
  if(imported.length()==0)return false
  val seenNumbers=mutableSetOf<Int>()
  for(i in 0 until imported.length()) {
   val row=imported.optJSONObject(i) ?: return false
   val number=row.optInt("number",0)
   val address=row.optString("address","").trim()
   if(number<=0 || !seenNumbers.add(number) || address.length<8 || matchingIndex(imported,address,i)>=0)return false
  }
  val s=state(c)
  val old=s.optJSONArray("items") ?: JSONArray()
  val skips=s.optJSONArray("skipped") ?: JSONArray()
  if(old.length()>0 || skips.length()>0){
   val h=s.optJSONArray("history") ?: JSONArray().also{s.put("history",it)}
   h.put(JSONObject().put("deletedAt",System.currentTimeMillis()).put("items",JSONArray(old.toString())).put("skipped",JSONArray(skips.toString())))
  }
  s.put("items",JSONArray(imported.toString()))
  s.put("skipped",JSONArray())
  // A new imported route starts a new logical sequence.
  s.put("lastNumber",0)
  s.put("lastNumber",highest(s))
  return save(c,s)
 }

 @Synchronized fun deleteHistory(c:Context,deletedAt:Long):Boolean {
  val s=state(c);val h=s.optJSONArray("history")!!
  val newer=JSONArray()
  var removed=false
  for(i in 0 until h.length()) {
   val item=h.optJSONObject(i) ?: continue
   if(item.optLong("deletedAt") == deletedAt) removed=true else newer.put(item)
  }
  if(!removed)return false
  s.put("history",newer)
  return save(c,s)
 }

 @Synchronized fun remove(c:Context,index:Int):Boolean {
  val s=state(c);val a=s.optJSONArray("items")!!
  if(index !in 0 until a.length())return false
  val newer=JSONArray();for(i in 0 until a.length())if(i!=index)newer.put(a.getJSONObject(i))
  s.put("items",newer)
  if(newer.length()==0 && (s.optJSONArray("skipped")?.length() ?: 0)==0)s.put("lastNumber",0)
  return save(c,s)
 }
 @Synchronized fun edit(c:Context,index:Int,number:Int,address:String):Boolean {
  val s=state(c);val a=s.optJSONArray("items")!!
  if(index !in 0 until a.length()||number<1||address.isBlank()||matchingIndex(a,address,index)>=0)return false
  for(i in 0 until a.length())if(i!=index&&a.getJSONObject(i).optInt("number",i+1)==number)return false
  a.getJSONObject(index).put("number",number).put("address",address.trim())
  s.put("lastNumber",highest(s))
  return save(c,s)
 }
}
