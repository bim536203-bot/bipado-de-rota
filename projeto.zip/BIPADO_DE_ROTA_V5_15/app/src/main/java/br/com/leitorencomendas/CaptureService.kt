package br.com.leitorencomendas

import android.app.*
import android.content.*
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.media.MediaPlayer
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.*
import android.webkit.WebView
import android.text.TextWatcher
import android.text.Editable
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService: Service() {
 companion object { @Volatile var active=false; private set }
 private var confirmationView:View?=null
 private var editorDialog:AlertDialog?=null
 private var duplicateDialog:AlertDialog?=null
 private var confirmationMap:MapAssistant?=null
 private lateinit var wm:WindowManager
 private var bubble:View?=null
 private var projection:MediaProjection?=null
 private var reader:ImageReader?=null
 private var virtualDisplay:android.hardware.display.VirtualDisplay?=null
 private var busy=false
 private val worker=HandlerThread("JtCaptureWorker").apply {start()}
 private val imageHandler=Handler(worker.looper)
 @Volatile private var captureId=0
 private fun playSound(id:Int){
  try { val player=MediaPlayer.create(this,id) ?: return
   player.setOnCompletionListener{it.release()};player.start()
  }catch(_:Exception){}
 }
 private val handler=Handler(Looper.getMainLooper())
 private val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
 override fun onBind(intent:Intent?)=null
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
  if(!Updater.allowed(this)){Updater.openGate(this);stopSelf();return START_NOT_STICKY}
  if(projection!=null)return START_NOT_STICKY
  val channel="capture_v5"; val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(channel,"Leitura de encomendas",NotificationManager.IMPORTANCE_LOW))
  val note=Notification.Builder(this,channel).setContentTitle("BIPADO DE ROTA ativo").setContentText("Toque no botão flutuante para capturar").setSmallIcon(android.R.drawable.ic_menu_camera).build()
  if(Build.VERSION.SDK_INT>=29) startForeground(5,note,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(5,note)
  val code=intent?.getIntExtra("resultCode",0)?:0
  val data=if(Build.VERSION.SDK_INT>=33)intent?.getParcelableExtra("resultData",Intent::class.java) else intent?.getParcelableExtra<Intent>("resultData")
  if(data==null){stopSelf();return START_NOT_STICKY}
  val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  projection=mgr.getMediaProjection(code,data)
  projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){handler.post { stopSelf() }}},handler)
  // Android 14 allows only one createVirtualDisplay() per MediaProjection grant.
  val metrics=resources.displayMetrics
  reader=ImageReader.newInstance(metrics.widthPixels,metrics.heightPixels,PixelFormat.RGBA_8888,3)
  virtualDisplay=projection?.createVirtualDisplay("parcel_capture",metrics.widthPixels,metrics.heightPixels,
   metrics.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,handler)
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  val bounds=resources.displayMetrics
  val lp=WindowManager.LayoutParams(dp(64),dp(64),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
   WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
   PixelFormat.TRANSLUCENT).apply {gravity=Gravity.TOP or Gravity.START
   x=(bounds.widthPixels-dp(70)).coerceAtLeast(0);y=(bounds.heightPixels/2-dp(32)).coerceAtLeast(0)}
  val slop=ViewConfiguration.get(this).scaledTouchSlop
  val b=ImageView(this).apply {
   setImageResource(R.mipmap.ic_launcher)
   scaleType=ImageView.ScaleType.FIT_CENTER
   setBackgroundColor(Color.TRANSPARENT)
   var touchX=0f;var touchY=0f;var originX=0;var originY=0;var dragged=false
   setOnTouchListener { _,event ->
    when(event.actionMasked){
     MotionEvent.ACTION_DOWN -> {
      touchX=event.rawX;touchY=event.rawY;originX=lp.x;originY=lp.y;dragged=false;true
     }
     MotionEvent.ACTION_MOVE -> {
      val dx=event.rawX-touchX;val dy=event.rawY-touchY
      if(!dragged && (kotlin.math.abs(dx)>slop || kotlin.math.abs(dy)>slop))dragged=true
      if(dragged){
       lp.x=(originX+dx.toInt()).coerceIn(0,(bounds.widthPixels-dp(64)).coerceAtLeast(0))
       lp.y=(originY+dy.toInt()).coerceIn(0,(bounds.heightPixels-dp(64)).coerceAtLeast(0))
       wm.updateViewLayout(this,lp)
      }
      true
     }
     MotionEvent.ACTION_UP -> {if(!dragged){tapFeedback();capture()};true}
     MotionEvent.ACTION_CANCEL -> true
     else -> true
    }
   }
  }
  wm.addView(b,lp);bubble=b;active=true
  // Load ML Kit while the user opens J&T; this blank frame is never shown or saved.
  imageHandler.post {
   val warm=Bitmap.createBitmap(64,64,Bitmap.Config.ARGB_8888).apply {eraseColor(Color.WHITE)}
   try {recognizer.process(InputImage.fromBitmap(warm,0)).addOnCompleteListener {warm.recycle()}}
   catch(_:Exception){warm.recycle()}
  }
  getSharedPreferences("capture_status",MODE_PRIVATE).edit().putBoolean("active",true).apply()
  return START_NOT_STICKY
 }
 private fun tapFeedback(){
  val vibrator=getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
  if(vibrator.hasVibrator())vibrator.vibrate(android.os.VibrationEffect.createOneShot(18,android.os.VibrationEffect.DEFAULT_AMPLITUDE))
 }
 private fun capture(){
  if(!Updater.allowed(this)){Updater.openGate(this);return}
  if(busy || confirmationView!=null || duplicateDialog!=null)return
  busy=true
  val session=++captureId
  val started=SystemClock.elapsedRealtime()
  bubble?.visibility=View.INVISIBLE
  val ir=reader
  if(ir==null){finishFailed(session,"Captura de tela indisponível");return}
  // Allow a frame without the bubble. Work on a separate handler so the UI stays responsive.
  handler.postDelayed({
   if(session!=captureId)return@postDelayed
   try {
    // Drain stale frames (which may still contain the overlay) before subscribing.
    imageHandler.post {
     if(session!=captureId)return@post
     try {while(true){val stale=ir.acquireLatestImage()?:break;stale.close()}}catch(_:Exception){}
     ir.setOnImageAvailableListener({ source ->
      if(session!=captureId)return@setOnImageAvailableListener
      val img=source.acquireLatestImage()?:return@setOnImageAvailableListener
      source.setOnImageAvailableListener(null,null)
      try {
       val plane=img.planes[0];val stride=plane.pixelStride;val row=plane.rowStride
       val raw=Bitmap.createBitmap(row/stride,img.height,Bitmap.Config.ARGB_8888)
       raw.copyPixelsFromBuffer(plane.buffer)
       val w=img.width;val h=img.height
       android.util.Log.d("BipadoLeitura","frameReady ${SystemClock.elapsedRealtime()-started}ms")
       img.close()
       // Crop out the J&T search header and Android navigation bar. Use relative bounds.
       val left=0;val top=0
       val right=w;val bottom=h
       val crop=Bitmap.createBitmap(raw,left,top,right-left,bottom-top)
       if(crop!==raw)raw.recycle()
       recognizer.process(InputImage.fromBitmap(crop,0))
        .addOnSuccessListener(java.util.concurrent.Executor {work->imageHandler.post(work)}) {result ->
         crop.recycle()
         if(session==captureId){
          android.util.Log.d("BipadoLeitura","OCR ${SystemClock.elapsedRealtime()-started}ms")
          val spans=result.textBlocks.flatMap {block->block.lines.flatMap {line->line.elements.mapNotNull {element->element.boundingBox?.let {box->OcrLayout.Span(element.text,box.left,box.top,box.right,box.bottom)} } } }
          val selected=OcrLayout.select(spans,w,h)
          val parsed=AddressExtractor.parse(selected.text)
          val positivelyValidated=CaptureAddressValidation.valid(selected.text,parsed)
          android.util.Log.d("BipadoLeitura","elements=${spans.size} selectedLines=${selected.lines.size} ${selected.reason} positive=$positivelyValidated success=${parsed.streetLine.isNotBlank()}")
          if(parsed.streetLine.isBlank()){
           val diagnostic=org.json.JSONObject().put("width",w).put("height",h).put("rawText",result.text).put("selectedText",selected.text).put("warning",parsed.warning)
           diagnostic.put("elements",org.json.JSONArray().apply {spans.forEach {s->put(org.json.JSONObject().put("text",s.text).put("left",s.left).put("top",s.top).put("right",s.right).put("bottom",s.bottom))}})
           imageHandler.post {try {openFileOutput("ocr-last-failure.json",MODE_PRIVATE).use {it.write(diagnostic.toString(2).toByteArray())}}catch(_:Exception){}}
          }
          handler.post {
           if(session!=captureId)return@post
           bubble?.visibility=View.VISIBLE;busy=false;confirm(parsed,positivelyValidated)
           android.util.Log.d("BipadoLeitura","confirmReady ${SystemClock.elapsedRealtime()-started}ms")
          }
         }
        }.addOnFailureListener {error -> crop.recycle();finishFailed(session,"Falha na leitura: ${error.message}")}
      }catch(e:Exception){try{img.close()}catch(_:Exception){};finishFailed(session,"Falha ao preparar a imagem: ${e.message}")}
     },imageHandler)
    }
   }catch(e:Exception){finishFailed(session,"Falha na captura: ${e.message}")}
  },50)
  handler.postDelayed({
   if(session==captureId && busy){
    captureId++
    ir.setOnImageAvailableListener(null,null)
    busy=false;bubble?.visibility=View.VISIBLE;playSound(R.raw.bip_erro)
    Toast.makeText(this,"Captura demorou. Tente novamente.",Toast.LENGTH_SHORT).show()
   }
  },6000)
 }
 private fun finishFailed(session:Int,message:String){handler.post {
  if(session!=captureId)return@post
  captureId++;busy=false;bubble?.visibility=View.VISIBLE;playSound(R.raw.bip_erro)
  Toast.makeText(this,message,Toast.LENGTH_LONG).show()
 }}
 private fun dp(value:Int)=(value*resources.displayMetrics.density+0.5f).toInt()
 private fun bg(color:Int,rad:Int)=GradientDrawable().apply { setColor(color);cornerRadius=dp(rad).toFloat() }
 private fun confirm(parsed:AddressExtractor.Result,sourceValidated:Boolean){
  val number=Store.nextNumber(this)
  if(sourceValidated && parsed.streetLine.isNotBlank() && parsed.locationLine.isNotBlank()){
   val candidate="${parsed.streetLine.replace(" — ", ", ")}, ${parsed.locationLine}, Brasil"
   Store.matching(this,candidate)?.let { existing ->
    showAlreadySaved(existing.optInt("number",0),existing.optString("address"))
    return
   }
  }
  val validFromCapture=sourceValidated && parsed.streetLine.isNotBlank()
  if(!validFromCapture)playSound(R.raw.bip_erro) else playSound(R.raw.bip_sucesso)
  // Persistent screenshot projection is not an address database. The user must verify OCR results.
  val container=LinearLayout(this).apply {
   orientation=LinearLayout.VERTICAL
   setPadding(dp(20),dp(18),dp(20),dp(18))
   background=bg(Color.WHITE,20)
  }
  val top=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  val title=TextView(this).apply {text="Pacote $number";textSize=28f;setTextColor(Color.BLACK);setTypeface(null,Typeface.BOLD)}
  top.addView(title,LinearLayout.LayoutParams(0,-2,1f))
  val pencil=ImageView(this).apply {setImageResource(R.drawable.ic_edit);setPadding(dp(9),dp(8),dp(9),dp(8));contentDescription="Editar endereço"}
  top.addView(pencil,LinearLayout.LayoutParams(dp(48),dp(44)))
  container.addView(top)
  fun divider()=View(this).apply {setBackgroundColor(0xFFE6E8EA.toInt())}
  container.addView(divider(),LinearLayout.LayoutParams(-1,dp(1)).apply {topMargin=dp(10);bottomMargin=dp(12)})
  val address1=TextView(this).apply {text=if(validFromCapture)parsed.streetLine else "Endereço não identificado — toque no lápis";textSize=19f;setTextColor(Color.BLACK)}
  val address2=TextView(this).apply {text=if(validFromCapture)parsed.locationLine else "Boa Vista, RR";textSize=19f;setTextColor(Color.BLACK);setPadding(0,dp(15),0,dp(5))}
  container.addView(address1)
  container.addView(address2)
  // Show the confirmation immediately; geocoding and map tiles load asynchronously.
  val mapStatus=TextView(this).apply {text="Procurando endereço no mapa…";textSize=12f;setTextColor(0xFF526475.toInt());setPadding(0,dp(7),0,dp(5))}
  val miniMap=WebView(this).apply {minimumHeight=dp(185)}
  container.addView(miniMap,LinearLayout.LayoutParams(-1,dp(185)).apply{topMargin=dp(12)})
  container.addView(mapStatus)
  var mapAssistant:MapAssistant?=null
  fun updateMap(){mapAssistant?.lookup("${address1.text}, ${address2.text}")}
  fun startMap(){
   if(confirmationView==null)return
   mapAssistant=MapAssistant(this,miniMap,mapStatus);confirmationMap=mapAssistant
   updateMap()
  }
  if(parsed.warning.isNotBlank())container.addView(TextView(this).apply {text=parsed.warning;textSize=13f;setTextColor(0xFFAB5000.toInt());setPadding(0,dp(8),0,0)})
  container.addView(divider(),LinearLayout.LayoutParams(-1,dp(1)).apply {topMargin=dp(18);bottomMargin=dp(12)})
  val controls=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.END}
  val cancel=Button(this).apply {text="CANCELAR";setAllCaps(false);setTextColor(0xFF252525.toInt());background=bg(0xFFF0F0F0.toInt(),12)}
  val accept=Button(this).apply {text="CONFIRMAR";setAllCaps(false);setTextColor(0xFF087439.toInt());background=bg(0xFFDDF5E5.toInt(),12)}
  if(validFromCapture){
   controls.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply {marginEnd=dp(6)})
   controls.addView(accept,LinearLayout.LayoutParams(0,dp(50),1f).apply {marginStart=dp(6)})
   container.addView(controls)
  } else {
   container.addView(cancel,LinearLayout.LayoutParams(-1,dp(50)))
   val skip=Button(this).apply{text="PULAR PARA PACOTE ${number+1}";setAllCaps(false);setTextColor(0xFF173B65.toInt());background=bg(0xFFDCEBFF.toInt(),12)}
   container.addView(skip,LinearLayout.LayoutParams(-1,dp(54)).apply{topMargin=dp(10)})
   skip.setOnClickListener{
    if(Store.skipNext(this,number)){closeCurrentConfirmation();Toast.makeText(this,"Pacote $number pulado",Toast.LENGTH_SHORT).show()}
    else Toast.makeText(this,"Numeração mudou; tente novamente",Toast.LENGTH_LONG).show()
   }
  }
  val overlay=FrameLayout(this).apply {setPadding(dp(14),dp(8),dp(14),dp(8));addView(container,FrameLayout.LayoutParams(-1,-2,Gravity.CENTER))}
  val params=WindowManager.LayoutParams(-1,-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
    WindowManager.LayoutParams.FLAG_DIM_BEHIND,PixelFormat.TRANSLUCENT).apply {
    gravity=Gravity.CENTER;dimAmount=.55f;softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
  }
  fun close(){editorDialog?.dismiss();try{wm.removeView(overlay)}catch(_:Exception){};confirmationView=null;mapAssistant?.release();confirmationMap=null}
  cancel.setOnClickListener {close()}
  pencil.setOnClickListener {
   val editPanel=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),0)}
   val field1=EditText(this).apply {setText(if(address1.text.startsWith("Endereço não identificado"))"" else address1.text);hint="Rua, número, complemento — bairro";minLines=1;maxLines=3;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE}
   val field2=EditText(this).apply {setText(address2.text);hint="Boa Vista, RR, CEP";setSingleLine(true)}
   editPanel.addView(TextView(this).apply {text="Rua, número, complemento e bairro"})
   editPanel.addView(field1)
   editPanel.addView(TextView(this).apply {text="Cidade, UF e CEP"})
   editPanel.addView(field2)
   val editStatus=TextView(this).apply{text="Busque e confira a localização no mapa";textSize=12f;setTextColor(0xFF536273.toInt())}
   val editMap=WebView(this)
   editPanel.addView(editMap,LinearLayout.LayoutParams(-1,dp(145)).apply{topMargin=dp(7)})
   editPanel.addView(editStatus)
   val suggestions=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
   editPanel.addView(suggestions)
   val editAssistant=MapAssistant(this,editMap,editStatus)
   val searchHandler=Handler(Looper.getMainLooper())
   var nextSearch:Runnable?=null
   var applyingSuggestion=false
   fun searchEdited() {
    nextSearch?.let {searchHandler.removeCallbacks(it)}
    val full="${field1.text}, ${field2.text}".trim()
    nextSearch=Runnable {
     editAssistant.lookup(full,true) { hits ->
      suggestions.removeAllViews()
      if(hits.isEmpty()){
       editStatus.text="Nenhuma sugestão encontrada. Você pode digitar manualmente."
      }
      for(hit in hits.take(3)) {
       val option=TextView(this).apply {
        text="📍 ${hit.label}";textSize=13f;setTextColor(0xFF193C58.toInt());setPadding(dp(6),dp(6),dp(6),dp(6))
        setOnClickListener {
         applyingSuggestion=true
         nextSearch?.let{searchHandler.removeCallbacks(it)}
         // Only change what the user elected; never overwrite their ZIP/CEP without verification.
         field1.setText(hit.label)
         field1.setSelection(field1.text.length)
         suggestions.removeAllViews()
         applyingSuggestion=false
         editAssistant.choose(hit)
        }
       }
       suggestions.addView(option)
      }
     }
    }
    searchHandler.postDelayed(nextSearch!!,180)
   }
   val watcher=object:TextWatcher {
    override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
    override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(!applyingSuggestion)searchEdited()}
    override fun afterTextChanged(s:Editable?){}
   }
   field1.addTextChangedListener(watcher)
   field2.addTextChangedListener(watcher)
   val dialog=AlertDialog.Builder(this).setTitle("Editar endereço").setView(editPanel)
    .setNegativeButton("CANCELAR",null).setPositiveButton("SALVAR",null).create()
   dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
   editorDialog=dialog
   dialog.setOnDismissListener {
    editorDialog=null
    nextSearch?.let{searchHandler.removeCallbacks(it)}
    editAssistant.release()
   }
   dialog.show()
   dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.95f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
   searchEdited()
   dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
    address1.text=field1.text.toString().trim()
    address2.text=field2.text.toString().trim()
    updateMap()
    dialog.dismiss()
   }
  }
  accept.setOnClickListener {
   val street=address1.text.toString().trim()
   val location=address2.text.toString().trim()
   if(street.length<8 || !Regex("\\b\\d{1,5}\\b").containsMatchIn(street)) {
    Toast.makeText(this,"Confira rua e número antes de salvar",Toast.LENGTH_LONG).show();return@setOnClickListener
   }
   if(!Regex("(?i)Boa\\s+Vista[, ]+RR").containsMatchIn(location)){
    Toast.makeText(this,"Confira cidade e UF",Toast.LENGTH_LONG).show();return@setOnClickListener
   }
   val full="${street.replace(" — ", ", ")}, $location, Brasil"
   val existing=Store.matching(this,full)
   if(existing!=null){
    showAlreadySaved(existing.optInt("number",0),existing.optString("address"))
    return@setOnClickListener
   }
   if(Store.add(this,full,number)) {
    playSound(R.raw.bip_sucesso)
    close()
    Toast.makeText(this,"PACOTE $number salvo",Toast.LENGTH_SHORT).show()
   } else Toast.makeText(this,"Número ou endereço já salvo",Toast.LENGTH_LONG).show()
  }
  wm.addView(overlay,params);confirmationView=overlay
  overlay.post {startMap()}
 }
 private fun closeCurrentConfirmation(){
  editorDialog?.dismiss()
  try{confirmationView?.let{wm.removeView(it)}}catch(_:Exception){}
  confirmationView=null;confirmationMap?.release();confirmationMap=null
 }
 private fun showAlreadySaved(existingNumber:Int,address:String){
  if(duplicateDialog!=null)return
  playSound(R.raw.bip_erro)
  val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(14))}
  val circle=FrameLayout(this).apply{background=bg(0xFFEF3030.toInt(),80)}
  circle.addView(ImageView(this).apply{setImageResource(R.drawable.ic_warning_white);setPadding(dp(14),dp(14),dp(14),dp(14))},FrameLayout.LayoutParams(dp(72),dp(72),Gravity.CENTER))
  panel.addView(circle,LinearLayout.LayoutParams(dp(72),dp(72)).apply{gravity=Gravity.CENTER_HORIZONTAL;bottomMargin=dp(14)})
  panel.addView(TextView(this).apply{text="ENDEREÇO JÁ BIPADO!";textSize=21f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(0xFFEF3030.toInt());setPadding(0,dp(4),0,dp(12))})
  panel.addView(TextView(this).apply{text="Este endereço já está salvo na sua lista como";textSize=17f;gravity=Gravity.CENTER;setTextColor(Color.BLACK)})
  panel.addView(TextView(this).apply{text="PACOTE $existingNumber";textSize=23f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(0xFFEF3030.toInt());setPadding(0,dp(6),0,dp(4))})
  val addressRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=bg(0xFFF0F3F7.toInt(),12);setPadding(dp(10),dp(13),dp(10),dp(13))}
  addressRow.addView(ImageView(this).apply{setImageResource(R.drawable.ic_pin_red)},LinearLayout.LayoutParams(dp(34),dp(45)).apply{marginEnd=dp(10)})
  addressRow.addView(TextView(this).apply{text=address;textSize=16f;setTextColor(0xFF15253D.toInt())},LinearLayout.LayoutParams(0,-2,1f))
  panel.addView(addressRow,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(16)})
  val backButton=Button(this).apply{text="VOLTAR";setAllCaps(false);setTextColor(0xFF303949.toInt());background=bg(0xFFE6E8EC.toInt(),12)}
  panel.addView(backButton,LinearLayout.LayoutParams(-1,dp(54)).apply{topMargin=dp(16)})
  val dialog=AlertDialog.Builder(this).setView(panel).create()
  dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
  duplicateDialog=dialog
  dialog.setOnDismissListener {duplicateDialog=null}
  dialog.setCanceledOnTouchOutside(true)
  dialog.show()
  backButton.setOnClickListener{dialog.dismiss()}
  val skipped=Store.nextNumber(this)
  val skipButton=Button(this).apply{text="PULAR PARA PACOTE ${skipped+1}";setAllCaps(false);setTextColor(0xFF173B65.toInt());background=bg(0xFFDCEBFF.toInt(),12)}
  panel.addView(skipButton,LinearLayout.LayoutParams(-1,dp(54)).apply{topMargin=dp(10)})
  skipButton.setOnClickListener{
   if(Store.skipNext(this,skipped)){
    dialog.dismiss();closeCurrentConfirmation()
    Toast.makeText(this,"Pacote $skipped pulado",Toast.LENGTH_SHORT).show()
   } else Toast.makeText(this,"Numeração mudou; tente novamente",Toast.LENGTH_LONG).show()
  }
 }
 override fun onDestroy(){
  captureId++;active=false
  handler.removeCallbacksAndMessages(null)
  imageHandler.removeCallbacksAndMessages(null)
  reader?.setOnImageAvailableListener(null,null)
  editorDialog?.dismiss()
  duplicateDialog?.dismiss()
  confirmationMap?.release()
  try{confirmationView?.let{wm.removeView(it)}}catch(_:Exception){}
  getSharedPreferences("capture_status",MODE_PRIVATE).edit().putBoolean("active",false).apply()
  sendBroadcast(Intent("br.com.leitorencomendas.STOPPED").setPackage(packageName))
  try{bubble?.let{wm.removeView(it)}}catch(_:Exception){};virtualDisplay?.release();reader?.close();projection?.stop();recognizer.close();worker.quitSafely();super.onDestroy()}
}
