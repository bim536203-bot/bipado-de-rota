package br.com.leitorencomendas

object GeoAddress {
 data class Query(val street:String,val number:String,val district:String,val postcode:String){
  val full:String get()=listOf(street,number,district,"Boa Vista","RR",postcode,"Brasil").filter{it.isNotBlank()}.joinToString(", ")
 }
 fun query(raw:String):Query {
  val text=AddressText.clean(raw)
  val parts=text.split(',').map{it.trim()}
  val first=parts.firstOrNull().orEmpty().substringBefore('—').trim()
  val initial=Regex("""^(\d{1,5}[a-zA-Z]?)\s+(.+)""").find(first)
  val commaNumber=parts.getOrNull(1)?.takeIf{Regex("""\d{1,5}[a-zA-Z]?""").matches(it)}
  val inline=Regex("""^(.+?)\s+(\d{1,5}[a-zA-Z]?)(?:\s|$)""").find(first)
  val number=initial?.groupValues?.get(1) ?: commaNumber ?: inline?.groupValues?.get(2).orEmpty()
  val street=AddressText.splitStreet(initial?.groupValues?.get(2) ?: if(commaNumber!=null)first else inline?.groupValues?.get(1) ?: first).first
  val district=Regex("""(?i)\b(?:Pricum[ãa]|Buritis|Liberdade|Mecejana|Cidade Sat[ée]lite|Caimb[ée]|Cauam[ée]|Centro)\b""").find(text)?.value.orEmpty()
  val zip=Regex("""(?<!\d)(\d{5})[- ]?(\d{3})(?!\d)""").find(text)
  return Query(street,number,district,zip?.let{"${it.groupValues[1]}-${it.groupValues[2]}"}.orEmpty())
 }
 private val ignored=setOf("rua","r","avenida","av","alameda","al","travessa","tv","via","da","de","do","das","dos")
 fun streetScore(offered:String,requested:String):Int {
  fun words(s:String)=AddressIdentity.normalize(s).split(' ').filter{it.length>=2 && it !in ignored}
  val wanted=words(requested);val available=words(offered)
  if(wanted.isEmpty() || available.isEmpty())return 0
  return wanted.count{w->available.any{it==w || (w.length>=2 && it.startsWith(w))}}*100/wanted.size
 }
 fun inRegion(lat:Double,lon:Double)=lat.isFinite()&&lon.isFinite()&&lat in 2.4..3.25&&lon in -61.2..-60.15
 fun exactNumber(requested:String,returned:String)=requested.isNotBlank()&&requested.equals(returned,true)
}
