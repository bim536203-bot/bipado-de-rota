package br.com.leitorencomendas

import org.json.JSONArray
import org.json.JSONObject

/** Parse CSV with quoted fields, escaped quotes, CRLF and UTF-8 BOM. */
object RouteCsv {
 fun parse(csv:String):JSONArray {
  val text=csv.removePrefix("\uFEFF")
  if(text.length>2_000_000)throw IllegalArgumentException("Arquivo muito grande")
  val rows=mutableListOf<List<String>>()
  val fields=mutableListOf<String>()
  val cell=StringBuilder()
  var quoted=false
  var pos=0
  while(pos<text.length){
   when(val ch=text[pos]){
    '"' -> {
     if(quoted && pos+1<text.length && text[pos+1]=='"'){cell.append('"');pos++}
     else if(quoted)quoted=false
     else if(cell.isEmpty())quoted=true
     else throw IllegalArgumentException("Aspas inválidas no CSV")
    }
    ',' -> if(quoted)cell.append(ch) else {fields.add(cell.toString());cell.setLength(0)}
    '\r','\n' -> if(quoted)cell.append(ch) else {
     fields.add(cell.toString());cell.setLength(0)
     if(fields.any{it.isNotBlank()})rows.add(fields.toList())
     fields.clear()
     if(ch=='\r' && pos+1<text.length && text[pos+1]=='\n')pos++
    }
    else -> cell.append(ch)
   }
   pos++
  }
  if(quoted)throw IllegalArgumentException("CSV com aspas sem fechamento")
  fields.add(cell.toString())
  if(fields.any{it.isNotBlank()})rows.add(fields.toList())
  if(rows.size<2)throw IllegalArgumentException("CSV sem endereços")
  val header=rows.first().map{it.trim().lowercase()}
  val addressColumn=header.indexOf("address")
  val notesColumn=header.indexOf("notes")
  if(addressColumn<0)throw IllegalArgumentException("Coluna Address não encontrada")
  val output=JSONArray();val used=mutableSetOf<Int>()
  for(row in rows.drop(1)){
   if(row.size!=header.size)throw IllegalArgumentException("Linha de CSV incompleta")
   val address=row[addressColumn].trim()
   if(address.isBlank())continue // Ignore empty rows, never create map pin for skipped item.
   if(address.length<8)throw IllegalArgumentException("Endereço inválido no CSV")
   val note=if(notesColumn>=0)row[notesColumn] else ""
   if(Regex("(?i)\\bpacote\\s*\\d+\\s*pulado\\b").containsMatchIn(note)||Regex("(?i)\\bpacote\\s*\\d+\\s*pulado\\b").containsMatchIn(address))continue
   val n=Regex("(?i)\\bpacote\\s*(\\d+)\\b").find(note)?.groupValues?.get(1)?.toIntOrNull()
   var number=n ?: 1
   if(n==null)while(number in used)number++
   if(number<1 || !used.add(number))throw IllegalArgumentException("Números de pacotes repetidos no CSV")
   output.put(JSONObject().put("address",address).put("number",number).put("createdAt",System.currentTimeMillis()))
  }
  if(output.length()==0)throw IllegalArgumentException("Nenhum endereço válido para importar")
  return output
 }
}
