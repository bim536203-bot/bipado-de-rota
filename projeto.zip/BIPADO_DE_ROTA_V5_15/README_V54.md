# BIPADO DE ROTA V5.4 – leitura estruturada da J&T

Esta atualização substitui a extração ingênua do endereço pelo parser `AddressExtractor.kt`, planejado para as telas de detalhes de encomendas da J&T mostradas pelo usuário.

- Separa rastreio, destinatário, rua, número, complemento, bairro, cidade, UF e CEP.
- Aceita endereços em ordem invertida (cidade/UF antes do número) e logradouros sem prefixo `Rua`.
- Exclui data, hora, WhatsApp, telefone e outros rótulos da leitura.
- Apresenta dois campos visuais separados na confirmação: endereço/bairro e `Boa Vista, RR, CEP`.
- Mantém ambos editáveis, para conferência obrigatória, e exporta endereço completo com país no campo `Address`; número sequencial somente em `Notes`.
- Se rua, número, bairro ou CEP estiverem incertos, exige atenção do entregador; não afirma precisão de 100%.

**Limitações:** O parser é determinístico e usa OCR ML Kit local. Não equivale à interpretação visual de um modelo multimodal e pode falhar em algumas capturas. Não houve compilação nem teste num aparelho Android real nesta sessão. A captura depende das permissões MediaProjection/overlay e da tela da J&T permitir captura.

**Para compilar:** abrir projeto no Android Studio com SDK Android 35, Java 17 e Gradle, instalar a build em um Moto G8 Plus e validar as telas reais antes do uso em produção.
