# BIPADO DE ROTA V5.14 — atualização consolidada

Base: projeto-fonte V5.13 enviado pelo usuário. Este ZIP é o PROJETO Android para compilação, não é um APK pronto.

## Alterações
- Número da versão instalado no canto inferior direito da tela inicial; conteúdo vem de `BuildConfig.VERSION_NAME` (ex.: V5.14). Incrementar `versionName` e `versionCode` a cada release.
- Barra superior de Endereços salvos: lupa branca entre VOLTAR e lixeira, preservando o restante dos cartões e controles.
- Campo de busca que abre ao tocar na lupa: filtragem local/instantânea dos endereços bipados, número do pacote, primeira letra, fragmentos, termos misturados, ignorando maiúsculas e acentos. Ao limpar campo, lista completa volta.
- Inicialização direta em `MainActivity` (sem splash 'Verificando atualização'). Consulta remota executada em thread separada após entrada no app.
- Se houver release obrigatória confirmada, persiste a exigência e abre `UpdateActivity`, bloqueando as demais telas até instalar nova versão. Se consulta falhar ou estiver offline e não existir atualização previamente confirmada, o app continua disponível e tenta verificar depois.
- Download e verificação de APK preexistentes preservados (SHA-256, assinatura, identidade e versão). A confirmação de instalação pelo sistema Android continua necessária.

## Observações para compilação/publicação
- `versionName` padrão = `5.14.0`; `versionCode` padrão = `66`; processo de CI pode substituir por `ciVersionName` e `ciVersionCode`, desde que incrementais.
- A consulta usa `https://github.com/<updateRepository>/releases/latest/download/update.json` e os metadados da release. Uma release correta deve estar publicada e o APK deve ser assinado com a MESMA chave instalada no aparelho. O ZIP não publica release nem configura CI.
- O cache de atualização já confirmada força a instalação mesmo offline, para preservar atualização obrigatória. Falha de consulta sem atualização confirmada não bloqueia.
- A instalação silenciosa não é possível para apps Android comuns: o sistema pode exigir autorização do usuário.

## Verificações neste ambiente
- 9 testes Kotlin locais do reconhecimento de endereços passaram.
- 13 arquivos XML analisados sem erros sintáticos.
- Manifesto e referências da nova pesquisa conferidos estaticamente.
- **Não foi possível executar assembleDebug nem fazer teste no aparelho:** Android SDK/Gradle não estão disponíveis neste ambiente. Compile e teste antes da distribuição.
