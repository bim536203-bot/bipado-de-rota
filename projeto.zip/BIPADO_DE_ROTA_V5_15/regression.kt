import br.com.leitorencomendas.AddressExtractor as A
import br.com.leitorencomendas.OcrLayout as L
fun main(){
 var count=0
 fun checkAddress(raw:String,expected:String){val r=A.parse(raw);check(r.streetLine==expected){"$raw => $r expected $expected"};count++}
 val city="Boa Vista-RR 69309360"
 checkAddress("999882273632212\nAnderson de Souza\nAlameda das Acácias 587 Casa de\nesquina PRICUMA $city","Alameda das Acácias, 587, Casa de Esquina — Pricumã")
 for(type in listOf("Alameda","Avenida","Rua","Via","Travessa")){
  checkAddress("Cliente Teste\n$type das Flores\n123 Casa BURITIS $city","$type das Flores, 123, Casa — Buritis")
  checkAddress("$type das Flores 123 Casa navegação\nBURITIS $city","$type das Flores, 123, Casa — Buritis")
 }
 checkAddress("das Tres Marias\n707 Vila PRICUMA $city","das Tres Marias, 707, Vila — Pricumã")
 checkAddress("Cliente Teste\nAlameda Nome Muito Longo de Cinco Palavras 587 BURITIS $city","Alameda Nome Muito Longo de Cinco Palavras, 587 — Buritis")
 fun layout(street:String,number:Int,extra:String,bairro:String,code:String):List<L.Span>{
  fun span(t:String,x:Int,y:Int,w:Int=500)=L.Span(t,x,y,x+w,y+32)
  return listOf(span(code,68,580),span("navegação",774,490,150),span("Cliente Teste",68,410),span("999882273632212",68,295),span(street,68,490),span("$number $extra $bairro Boa Vista-RR",68,535),span("2026-10-12 08:26:14",68,660),span("WhatsApp",68,790))
 }
 val avenida=layout("Buritis · Avenidas dos a bandeirante",189,"","BURITIS","69309186")
 val alameda=layout("Alameda das Acácias 587 Casa de",587,"esquina","PRICUMA","69309360").map {if(it.top==535)it.copy(text="esquina PRICUMA Boa Vista-RR") else it}
 for(input in listOf(avenida,alameda)){
  val expected=if(input===avenida)"Avenidas dos a Bandeirante, 189 — Buritis" else "Alameda das Acácias, 587, Casa de Esquina — Pricumã"
  repeat(12){seed->val selected=L.select(input.shuffled(kotlin.random.Random(seed)),1080,2280);checkAddress(selected.text,expected);check(!selected.text.contains("Cliente"));check(!selected.text.contains("navegação"))}
 }
 for(scale in listOf(.5,1.0,1.5)){
  val spans=alameda.map {it.copy(left=(it.left*scale).toInt(),top=(it.top*scale).toInt(),right=(it.right*scale).toInt(),bottom=(it.bottom*scale).toInt())}
  checkAddress(L.select(spans,(1080*scale).toInt(),(2280*scale).toInt()).text,"Alameda das Acácias, 587, Casa de Esquina — Pricumã")
 }
 check(A.parse("999882273632212\nCliente Teste\n69309360").streetLine.isBlank());count++
 checkAddress("Alameda dos Bambu Salón de (t) Beleza Perla Bela Alameda dos Bambu Salón de Beleza Perla Bela 1433 PRICUMA Boa Vista-RR 69309395","Alameda dos Bambu, 1433, Salón de Beleza Perla Bela — Pricumã")
 checkAddress("Rua Botão-de-ouro 102 Rua (t) Botão-de-ouro 102 PRICUMA Boa Vista-RR 69309365","Rua Botão-de-ouro, 102 — Pricumã")
 println("$count regression cases passed")
}
