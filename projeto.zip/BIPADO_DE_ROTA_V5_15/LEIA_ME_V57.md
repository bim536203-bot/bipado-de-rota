# BIPADO DE ROTA V5.7.0 — Projeto Android para compilação no Work

Base: V5.6.1 (OCR J&T, correções de logradouros, ícones vetoriais e arraste do botão flutuante).

## Novidade: mapa no diálogo de confirmação

- Um mapa com zoom aproximado e marcador aparece automaticamente abaixo do endereço, sem aguardar a conclusão do reconhecimento geográfico para mostrar o diálogo.
- Busca de endereços durante a edição, com espera de 500 ms após digitar, até 3 sugestões e atualização do mapa. Selecionar sugestão altera o texto da primeira linha; revisar sempre complemento, bairro, cidade e CEP.
- Reconsultar o mapa após salvar edição. Quando não houver resultado ou internet, a confirmação manual continua funcionando.
- Fontes: OpenStreetMap tiles + Leaflet via CDN; busca do serviço público Photon/Komooot. Requer acesso à internet, sujeita a disponibilidade/limites e não oferece precisão garantida para número do imóvel. As coordenadas podem refletir apenas rua/região. O uso em produção com alto volume poderá exigir provedor com contrato e chave ou infraestrutura própria.
- Não há chave paga embutida no projeto; o app não possui Google Maps API Key.

## Para compilar

Abra o projeto no Android Studio ou execute Gradle com JDK17 e Android SDK35; módulo `app`, build debug. Instale o APK resultante e conceda acesso à sobreposição e projeção de tela conforme o Android solicitar.

## Testes necessários no dispositivo

1. Verificar a captura J&T / filtro superior / OCR com os três endereços reais do teste.
2. Abrir confirmação, ver o minimapa e o nome da rua; conferir pin e zoom.
3. Abrir lápis, digitar lentamente, escolher sugestões, salvar e confirmar pacote.
4. Repetir sem internet; o mapa deve falhar com mensagem sem impedir salvar endereços.
5. Testar o desempenho de capturas sucessivas, arrastar bolha, exportar CSV e notas.

Aviso: este ZIP é o **projeto-fonte**, NÃO um APK, e não foi possível executar o build Android neste ambiente.
