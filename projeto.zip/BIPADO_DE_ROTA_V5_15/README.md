# Leitor de Encomendas V5.2 Android

Projeto-fonte Kotlin para Android Studio. **Não é APK compilado.**

Mudanças: tela cheia de endereços salvos, cartões individuais e edição do número de Pacote (rótulo fixo) e endereço. Confirmação mostra próximo número disponível; cancelamento não consome número. CSV possui colunas `Address` e `Notes`, com endereço e número separados. Registros antigos sem campo number usam posição original como número na leitura/exportação. Endereços repetidos e números duplicados são bloqueados.

**Teste obrigatório:** verificar em importação real do Spoke se `Notes` é o cabeçalho aceito pela versão instalada; ajustar o mapeamento de colunas caso necessário. Verificar permissões MediaProjection/overlay e captura no aparelho. A captura de telas protegidas pode falhar.

Abra no Android Studio, sincronize Gradle e compile um APK de teste. Não foi possível compilar nem testar neste ambiente.
