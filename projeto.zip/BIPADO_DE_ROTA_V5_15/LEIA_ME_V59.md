# BIPADO DE ROTA V5.9 — projeto Android Kotlin

Atualizado a partir da V5.8. Este ZIP contém CÓDIGO-FONTE, não APK.

## Alterações
- Cadastro de pacotes: bloqueio de duplicidade por normalização de texto (acentos, abreviações mais comuns, pontuação, maiúsculas/minúsculas), sem avançar o número de pacote. Alerta na captura e no botão CONFIRMAR com nome/número do pacote existente; número e complemento diferentes permanecem distintos.
- Alerta visual vermelho/azul, endereço salvo e botão ENTENDI.
- Menu ⋮ na tela inicial, abre painel lateral com opção “Histórico de lista apagada”.
- APAGAR TUDO salva uma cópia da lista principal antes de limpá-la; exclusões individuais não vão ao histórico.
- Histórico: cada grupo com título “Lista apagada”, horário grande, data e contagem de endereços. Ao abrir, todos os endereços e botão RESTAURAR LISTA.
- Restauração exige confirmação, substitui a lista principal e envia antes a lista atual (se não vazia) ao histórico; usa gravação conjunta em SharedPreferences.
- Cada snapshot do histórico expira após 24h. Limpeza na próxima consulta/abertura do histórico, sem depender de trabalho em background e sem afetar a lista principal.
- Extrator offline prioriza estrutura ID -> destinatário -> endereço; inclui Alameda, Via, Travessa, Avenida, Rua e casos sem prefixo. Teste obrigatório do endereço Alameda das Acácias 587 Casa de esquina Pricumã.
- Autocomplete enquanto digita com espera de 180 ms, consultas progressivas gratuitas ao Photon e reaproveitamento de sugestões em cache. Suporta entrada com número inicial (como `578 veg`) como consulta à rua. Seleção preenche o campo na hora e posiciona marcador quando houver coordenadas retornadas.
- Minimapa em Leaflet/OpenStreetMap; não é Google Maps, depende de internet e de cobertura do provedor gratuito; ponto é aproximado, não confirmação do número exato.
- Preservadas leitura pelo ícone flutuante, arraste, bip, lista de pacotes, exportação CSV e recursos de edições anteriores.

## Testes necessários após compilar no Work
1. Instalar por cima da V5.8 e confirmar que endereços existentes foram mantidos.
2. Ler capturas J&T de Carla Souza, Amanda, Gaby, Claudia e Anderson (Alameda 587). Verificar filtros de rastreio/nome.
3. Bipar o mesmo endereço duas vezes; segundo bipe deve mostrar alerta e não criar pacote nem entrar no CSV. Testar acentos, abreviações e número diferente.
4. Salvar alguns pacotes, usar APAGAR TUDO, abrir o menu ⋮, conferir snapshot com horário/contagem, restaurar, testar confirmação e backup da lista principal.
5. Validar retenção de 24h e reabertura do app, inclusive app fechado na hora da expiração.
6. Testar autocomplete ao digitar `578 veg`, `89 ba`, Alameda e Via em Boa Vista com internet móvel, tocar sugestão e verificar que o preenchimento não espera o mapa.
7. Testar janela de confirmação, movimento do ícone flutuante, som curto, CSV e teclado no Moto G8 Plus.

## Limitações de validação
O ambiente de preparação não dispõe do Android SDK/Gradle para compilar um APK e nem do aplicativo J&T em execução. Foram executados testes do parser Kotlin, verificação de XML e do arquivo ZIP, mas a compilação e o teste de interface/câmera/overlay/geocodificação em aparelho ainda são obrigatórios. Serviços gratuitos podem impor limites e não reproduzem a cobertura do Spoke.
