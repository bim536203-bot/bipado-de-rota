# BIPADO DE ROTA V5.6.1 — Correção do reconhecimento de logradouros

Esta atualização corrige o interpretador de endereços sem modificar as funções da V5.6.

- Reconhece `Via`, `Avenida`, `Alameda`, `Travessa`, `Rua`, `Estrada`, `Rodovia` e outras categorias.
- Aceita endereços da J&T sem o tipo de logradouro (ex.: `das tres marias 707 vila PRICUMA`).
- Aceita prefixo de bairro seguido de ponto ou nome da rua (ex.: `Buritis . Antônio Pimheiro Galvão 1762`).
- Continua isolando a linha de cidade/CEP, separando o complemento e ignorando códigos de rastreamento longos.
- Mantém edição manual antes de salvar, pois OCR nunca tem 100% de precisão.

Foram aprovados testes locais do arquivo AddressExtractor.kt com os três exemplos enviados pelo usuário, o exemplo Carla Souza, uma rua normal e a interferência do cabeçalho de pesquisa.

IMPORTANTE: o projeto foi testado com compilador Kotlin para o interpretador, mas o APK Android completo NÃO foi compilado neste ambiente. Solicite a compilação do ZIP no ChatGPT Work e teste no telefone.
