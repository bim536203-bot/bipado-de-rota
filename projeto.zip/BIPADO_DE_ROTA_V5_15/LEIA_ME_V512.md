# BIPADO DE ROTA 5.12.0

## Alterações
- Geoapify para busca e sugestões de endereço, com rua, número, bairro e CEP.
- Diferencia número encontrado na base de posição aproximada da rua. O ponto deve ser conferido pelo usuário; não garante a porta exata.
- Cache de resultados por endereço por sete dias, cancelamento de consultas antigas e mensagens de falha também no minimapa.
- Leaflet incorporado ao aplicativo, sem esperar download do código do mapa. Os mapas e consultas ainda precisam de internet.
- Vibração curta somente no toque do botão flutuante, sem vibrar ao arrastar.
- Preparação do ML Kit no início, processamento de OCR fora da tela principal e confirmação aberta antes da busca no mapa. A redução de latência deve ser medida no celular.
- Preserva reconhecimento geométrico, identificação de repetidos por rua e número, limpeza de texto repetido, som de alerta para repetidos, lista recente no topo, histórico e exportação.

## Verificações
87 casos locais passaram: 18 consultas/precisão de geocodificação, 43 regressões de extração/ordenação, 15 duplicados/limpeza, nove casos anteriores e duas capturas reproduzidas com Tesseract (não ML Kit).
Duas consultas reais ao Geoapify localizaram Alameda das Acácias, 587 e Avenida dos Bandeirantes, 189 em Boa Vista, com número retornado pela base. As consultas levaram aproximadamente 8,6 e 7,1 segundos neste ambiente; não representam a velocidade no telefone.
Validação Android: compilação, lint, assinatura e alinhamento do APK. Não foi executado em emulador nem Moto G8 Plus. Captura real, haptics, áudio, interação J&T/Spoke e desempenho devem ser conferidos no aparelho.

## Compilar
JDK 17 completo, Gradle 8.9 e Android SDK plataforma 35. Configure sdk.dir em local.properties.
Forneça a chave via variável de ambiente GEOAPIFY_API_KEY ou propriedade Gradle geoapifyApiKey. A chave não está neste ZIP. O APK entregue já está configurado.
Para manter a assinatura existente, use -PbipadoSigningKey=/caminho/arquivo.jks com a chave original de testes; ela não está no ZIP.
Execute gradle assembleDebug lintDebug. A configuração atual de assinatura usa alias androiddebugkey e senhas android.
Para regressões, instale Kotlin e execute ./run-regression.sh. Veja os documentos anteriores apenas como histórico.
O APK usa minSdk 26 e targetSdk 34, compatível por configuração com Android 10. Instale sobre a versão anterior para preservar os dados.

## Diagnóstico no aparelho
Logcat: BipadoLeitura separa espera do quadro, OCR e abertura de confirmação. BipadoMapa registra tempo de geocodificação e quantidade de resultados, sem chave nem conteúdo de endereço.
