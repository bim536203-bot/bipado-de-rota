import br.com.leitorencomendas.CidadeSatelitePostal as P
import br.com.leitorencomendas.BoaVistaPostal as B
import br.com.leitorencomendas.AddressExtractor as A
import br.com.leitorencomendas.CaptureAddressValidation as V
fun main(){
 check(P.entries.size==105 && B.entries.size==153)
 var checks=0
 for(e in P.entries){
  check(P.exact(e.street.uppercase())==e)
  check(B.suggestions(e.street,"Cidade Satélite").any{it.street==e.street&&it.postcode==e.postcode})
  val raw="${e.street} 28 Casa CIDADE SATELITE Boa Vista-RR ${e.postcode}"
  val result=A.parse(raw)
  check(result.streetLine=="${e.street}, 28, Casa — Cidade Satélite"){"${e.street}: $result"}
  check(V.valid(raw,result));checks+=4
 }
 check(B.suggestions("vega","Pricumã").isEmpty())
 check(B.suggestions("rosas","Cidade Satélite").isEmpty())
 check(B.canonicalStreet("Rua Vega","69317-803")==null)
 check(B.canonicalStreet("Rua Libra","")==null)
 check(B.canonicalStreet("Rua Libra","69317-520")=="Rua Libra")
 for(raw in listOf("Rua Libra 28 Cidade Satélite Boa Vista-RR","69317-520 Cidade Satélite Boa Vista-RR","Rua J-7 Cidade Satélite Boa Vista-RR 69317-512"))check(!V.valid(raw,A.parse(raw)))
 println("Cidade Satélite: $checks full-catalogue recognition checks plus negative safety cases passed")
}
