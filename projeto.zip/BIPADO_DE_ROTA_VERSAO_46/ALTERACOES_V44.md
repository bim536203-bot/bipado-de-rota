# V44 — edição de endereços salvos

O botão CONFIRMAR é habilitado para o endereço salvo e permite renumerar sem nova busca. Endereço digitado completo (rua/número/cidade/UF) também pode ser confirmado offline; fragmentos exigem completar ou selecionar sugestão. Número vazio, inválido ou fora do limite não habilita o botão. Conflitos de número/endereço e mudanças em outro aparelho continuam verificados na gravação. Endereço mantido preserva ponto e contato. Sons, captura, base postal, histórico e sincronização não alterados. Testes de lógica e DOM não substituem ensaio do editor no aparelho.
