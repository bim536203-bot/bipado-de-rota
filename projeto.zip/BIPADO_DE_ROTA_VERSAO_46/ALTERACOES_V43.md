# V43

Base auxiliar Cidade Satélite: 105 pares de rua/CEP do CEPs do Brasil, duas páginas, consulta 24/10/2026; fonte declara fevereiro de 2026. Incluída na captura Android e nas sugestões Android/iPhone, junto com Pricumã. Não confirma número ou coordenadas. Rua/CEP em conflito não é substituído por outro logradouro. Números que fazem parte de nomes conhecidos como J-7 não são confundidos com a residência quando a rua inteira e CEP concordam.

Som WhatsApp: opção 3 do conjunto grave, Duplo descendente (392/262 Hz; 0,44s), SHA256 7a76d9fad7483b6d7b2ad8f2958fa95113b5258fe3320bf51555fc08beaf2a9a. Somente arquivo bip_whatsapp.wav muda. CaptureSounds.kt e os demais sons da V42 são preservados byte a byte.

Histórico por 7 dias e nome da rota por dia permanecem. Backend não precisa de mudanças. Leitura física via ML Kit, áudio no celular e importação no Spoke não são substituídos pelos testes automatizados.
