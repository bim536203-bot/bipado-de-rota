import br.com.leitorencomendas.SavedAddressEdit as E
fun main(){
 val a="Rua Leão, 670, Cidade Satélite, Boa Vista, RR, 69317-518, Brasil"
 check(E.ready(a,a,"61",false));check(E.ready(a,a,"62",false))
 check(E.ready(a,a.replace("670","671"),"61",false))
 check(!E.ready(a,"671 le","61",false));check(!E.ready(a,a,"",false));check(!E.ready(a,a,"2147483648",false))
 check(!E.ready(a,"Rua Leão, Boa Vista, RR, 69317-518","61",false))
 check(!E.ready(a,"Rua Leão, 671","61",false))
 check(E.ready(a,"Rua Leão, 671","61",true))
 println("Saved editor: existing address, renumbering, full manual edit and invalid/fragment checks passed")
}
