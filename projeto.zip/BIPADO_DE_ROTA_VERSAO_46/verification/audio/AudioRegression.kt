import android.content.Context
import android.media.MediaPlayer
import br.com.leitorencomendas.CaptureSounds
fun main(){
 val sounds=CaptureSounds(Context());var checks=0
 fun expect(value:Boolean){check(value);checks++}
 for(id in listOf(1,2,3,4)){
  sounds.play(id);val player=MediaPlayer.created.last()
  expect(player.resource==id && player.started && !player.released)
  player.completion!!(player);expect(player.released)
 }
 sounds.play(1);val previous=MediaPlayer.created.last();sounds.play(3);expect(previous.released)
 val active=MediaPlayer.created.last();expect(active.resource==3 && active.started)
 expect(active.error!!(active,1,0));expect(active.released)
 MediaPlayer.unavailable=true;sounds.play(2);MediaPlayer.unavailable=false
 sounds.play(1);expect(MediaPlayer.created.last().started)
 MediaPlayer.failStart=true;sounds.play(2);expect(MediaPlayer.created.last().released);MediaPlayer.failStart=false
 sounds.play(3);expect(MediaPlayer.created.last().started)
 sounds.release();expect(MediaPlayer.created.last().released);sounds.release()
 println("Capture audio: $checks checks passed (MediaPlayer boundary; physical playback pending)")
}
