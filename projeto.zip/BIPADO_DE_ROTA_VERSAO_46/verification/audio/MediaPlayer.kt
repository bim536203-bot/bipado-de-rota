package android.media
import android.content.Context
class MediaPlayer(val resource:Int){
 companion object {
  val created=mutableListOf<MediaPlayer>()
  var unavailable=false
  var failStart=false
  fun create(context:Context,id:Int):MediaPlayer?=if(unavailable)null else MediaPlayer(id).also{created.add(it)}
 }
 var started=false;var released=false
 var completion:((MediaPlayer)->Unit)?=null
 var error:((MediaPlayer,Int,Int)->Boolean)?=null
 fun setOnCompletionListener(callback:(MediaPlayer)->Unit){completion=callback}
 fun setOnErrorListener(callback:(MediaPlayer,Int,Int)->Boolean){error=callback}
 fun start(){check(!released);if(failStart)throw IllegalStateException("decoder failed");started=true}
 fun release(){released=true}
}
