import android.content.Context
import br.com.leitorencomendas.Store
import org.json.JSONArray
import org.json.JSONObject
fun main(){
 check(Store.RETENTION_MS==7L*24*60*60*1000)
 val c=Context();val now=System.currentTimeMillis();val day=24L*60*60*1000
 val snapshots=JSONArray()
 for((i,age) in listOf(day,6*day,7*day-60000,7*day+60000).withIndex())snapshots.put(JSONObject().put("id","history:$i").put("deletedAt",now-age).put("items",JSONArray()).put("skipped",JSONArray()))
 val state=JSONObject().put("items",JSONArray()).put("skipped",JSONArray()).put("history",snapshots).put("lastNumber",0)
 c.getSharedPreferences("deliveries",0).edit().putString("state",state.toString()).commit()
 val kept=Store.history(c)
 check(kept.length()==3)
 check((0 until kept.length()).map{kept.getJSONObject(it).getString("id")}==listOf("history:0","history:1","history:2"))
 println("Store history: seven-day retention keeps 1d/6d/just-before-7d, removes expired snapshot")
}
