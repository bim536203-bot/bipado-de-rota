# V42 — nome da rota por dia

O CSV exportado para Spoke recebe ROTA DE SEGUNDA.csv, ROTA DE TERÇA.csv etc., com espaços e acentos. Usa a data de exportação em America/Boa_Vista, nos dois sistemas. Título e assunto Android acompanham o nome; título do compartilhamento iPhone também. CSV e números dos pacotes permanecem iguais. Rotas já importadas não são renomeadas.

Testes dos sete dias, acentos e virada da meia-noite de Boa Vista. Testes existentes verificam compartilhamento, cancelamento, download e ausência de telefones. O título final da rota após importar depende do Spoke; não houve ensaio no Spoke físico.

## Histórico por 7 dias
Android, iPhone e validador de sincronização usam 7 dias (168 horas), contados desde a exclusão. Textos das telas também atualizados. Código preparado; publicação do app e implantação do backend ainda pendentes. Aparelhos com versão antiga ainda aplicam 24 horas e devem ser atualizados juntos. Dados já expirados não são recuperados.

## Som próprio ao salvar WhatsApp
Captura Android de WhatsApp salva com sucesso usa bip_whatsapp.wav, dois tons descendentes (0,405s). Sons de pacote encontrado, repetido e erro preservados, usando o MediaPlayer restaurado na V41. Captura de telefone permanece exclusiva do Android. Atualização ainda não publicada.
