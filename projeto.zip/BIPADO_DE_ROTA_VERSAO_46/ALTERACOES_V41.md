# V41 — correção dos sons no Android

Restaura MediaPlayer.create usado na V39 para os três avisos. Remove SoundPool e o canal de sonificação introduzidos na V40. Mantém o toque próprio de repetição e as demais correções da V40.

O teste de fronteira executa o código real de reprodução para os três recursos, conclusão, erro, troca de aviso e liberação. Não substitui teste audível em aparelho físico. Compilação, assinatura e regressões são verificadas antes da publicação.
