package br.com.leitorencomendas

import java.util.Locale

/** Canonicalize formatting only: never invent a city, postcode or OCR digit. */
internal object AddressOcrText {
 private val postcode=Regex("""(?i)(?:\bCEP\s*[:.]?\s*)?(?<!\d)(\d{5})[\h\r\n]*[-.\u2010-\u2015]?[\h\r\n]*(\d{3})(?!\d)""")
 private val locality=Regex("""(?i)\bBoa\s*Vista\s*(?:[-,./:\u2010-\u2015]\s*)*(?:RR|Roraima)\b""")
 fun normalize(raw:String):String {
  val withPostcode=postcode.replace(raw){"${it.groupValues[1]}-${it.groupValues[2]}"}
  return locality.replace(withPostcode,"Boa Vista-RR")
 }
}

/** Leitura offline de cartão J&T: cabeçalho, rastreio e destinatário NÃO são endereço. */
object AddressExtractor {
 data class Result(val streetLine:String,val locationLine:String,val warning:String="")
 private val locale=Locale.forLanguageTag("pt-BR")
 private val cep=Regex("""(?<!\d)(\d{5})[-.\s]?(\d{3})(?!\d)""")
 private val city=Regex("""(?i)\bBoa\s*Vista\s*[-,/ ]*\s*RR\b""")
 private val date=Regex("""\b20\d{2}[-/]\d{2}[-/]\d{2}.*""")
 private val tracking=Regex("""(?<!\d)\d{9,22}(?!\d)""")
 private val road=Regex("""(?i)\b(?:ruas?|r\.?|avenidas?|av\.?|vias?|travessas?|tv\.?|alamedas?|al\.?|estradas?|rodovias?|passagens?|praças?|pracas?|becos?|vielas?|ladeiras?|ramais?|conjuntos?|servidões?|servidoes?)\b""")
 private val number=Regex("""(?<![\p{L}\p{N}/])\b(\d{1,5}(?:/\d{1,5})?[a-zA-Z]?)(?![\p{L}\p{N}/])""")
 private val unitNumber=Regex("""(?i)\b(?:apartamento|apto|apt|ap|bloco|quarto|sala|loja|quadra|lote)\.?\s*[:#-]?\s*\d{1,5}[a-zA-Z]?\b""")
 private val bairro=Regex("""(?i)\b(?:BURITIS|PRICUM[AÃ]|CIDADE SAT[EÉ]LITE|LIBERDADE|CAUAM[EÉ]|CARAN[AÃ]|CAIMB[EÉ]|J[OÓ]QUEI CLUBE|S[ÃA]O FRANCISCO|CENTRO|MECEJANA|PINTOL[ÂA]NDIA|SENADOR H[EÉ]LIO CAMPOS|DR SILVIO LEITE)\b""")
 private val noise=Regex("""(?i)(?:whatsapp|telefone|navega[cç][aã]o|procurar|n[uú]mero [uú]nico|entrega pendente|assinar)""")
 private fun clean(s:String)=s.replace(Regex("""\s+""")," ").trim(' ',',','.',';',':','-')
 private fun title(s:String)=clean(s).lowercase(locale).split(' ').joinToString(" "){v->if(v in setOf("de","da","do","das","dos","e","a"))v else v.replaceFirstChar{it.titlecase(locale)}}
 private fun location(code:String)="Boa Vista, RR"+(if(code.isNotEmpty())", $code" else "")
 private fun normalizeSimple(s:String)=java.text.Normalizer.normalize(s.lowercase(locale),java.text.Normalizer.Form.NFD).replace(Regex("""\p{M}+"""),"")

 fun parse(raw:String):Result {
  val lines=AddressOcrText.normalize(raw).lines().map { noise.replace(it," ") }.map(::clean).filter {it.isNotEmpty()}
  val trackIndex=lines.indexOfFirst{tracking.matches(it.replace(" ",""))}
  var section=if(trackIndex>=0)lines.drop(trackIndex+1) else lines
  section=section.takeWhile{!date.containsMatchIn(it)}
   .filterNot{tracking.matches(it.replace(" ",""))}
  if(section.size>1 && (trackIndex>=0 || section.drop(1).any { road.containsMatchIn(it) || bairro.find(it)?.range?.first==0 } || (number.find(section[1])?.range?.first ?: 0)>3) && !road.containsMatchIn(section.first()) &&
    !bairro.containsMatchIn(section.first()) && !cep.containsMatchIn(section.first()) && !number.containsMatchIn(section.first()))section=section.drop(1)
  if(section.isEmpty())return Result("",location(""),"Endereço não identificado. Use o lápis.")

  var text=section.joinToString(" ")
  text=tracking.replace(text," ")
  val zip=cep.findAll(text).lastOrNull()
  val cepValue=zip?.let{"${it.groupValues[1]}-${it.groupValues[2]}"}.orEmpty()
  text=cep.replace(text," ")
  text=city.replace(text," ")
  text=clean(AddressText.clean(text))

  val typed=road.find(text)
  var prefixDistrict=""
  if(typed!=null) {
   val prefix=text.substring(0,typed.range.first)
   prefixDistrict=bairro.find(prefix)?.value.orEmpty()
   text=clean(text.substring(typed.range.first))
  } else {
   val d=bairro.find(text)
   if(d!=null && d.range.first==0){
    prefixDistrict=d.value
    text=clean(text.substring(d.range.last+1).trimStart('.',' '))
   }
  }

  text=AddressText.streetType(text)
  // A fully spelled calendar street name contains a date, not the residence number.
  // Skip only this unambiguous pattern; arbitrary multiple numbers still require review.
  val dateStreet=Regex("""(?i)^(?:ruas?|r\.?|avenidas?|av\.?|travessas?|tv\.?)\s+(?:[1-9]|[12]\d|3[01])\s+de\s+(?:janeiro|fevereiro|março|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\b""").find(text)
  val unitRanges=unitNumber.findAll(text).map{it.range}.toList()
  // Numeric parts of an exact visible street+CEP are not the residence number (J-7, R-24).
  val knownStreet=BoaVistaPostal.entries.singleOrNull{it.postcode==cepValue}
  val allTokens=Regex("""[\p{L}\p{N}]+""").findAll(text).toList()
  val knownTokens=knownStreet?.street?.let{Regex("""[\p{L}\p{N}]+""").findAll(it).map{t->normalizeSimple(t.value)}.toList()}
  val knownEnd=if(knownTokens!=null && allTokens.size>=knownTokens.size && allTokens.take(knownTokens.size).map{normalizeSimple(it.value)}==knownTokens)allTokens[knownTokens.size-1].range.last+1 else 0
  val n=number.findAll(text,maxOf(knownEnd,dateStreet?.range?.let {it.last+1} ?: 0)).firstOrNull{candidate->unitRanges.none{candidate.range.first in it}} ?: return Result("",location(cepValue),"Número da residência não identificado. Confira pelo lápis.")
  // Do not turn an OCR icon read as "1" into the house number before a real "512".
  // Other numeric street names/quadra-lote ambiguity require explicit manual review.
  // Repeated identical house fields are redundant; different candidates still require review.
  var afterNumber=text.substring(n.range.last+1)
  val repeatHouse=Regex("""^[\s,;.]+${Regex.escape(n.value)}(?=$|[\s,;.])""")
  while(true){val repeated=repeatHouse.find(afterNumber) ?: break;afterNumber=afterNumber.substring(repeated.range.last+1)}
  val complement=Regex("""(?i)\b(?:casa|apartamento|apto|apt|ap|bloco|quarto|lote|quadra|loja|sala|fundos|resid[eê]ncia|oficina|hospital|sal[aã]o|sal[oó]n)\b""").find(afterNumber)?.range?.first
  val districtStart=bairro.find(afterNumber)?.range?.first
  val stop=listOfNotNull(complement,districtStart).minOrNull() ?: afterNumber.length
  if(number.containsMatchIn(afterNumber.substring(0,stop)))
   return Result("",location(cepValue),"Leitura com mais de um número possível. Confira rua e residência pelo lápis.")
  val details=afterNumber.substring(0,districtStart ?: afterNumber.length)
  val detailUnits=unitNumber.findAll(details).map{it.range}.toList()
  if(detailUnits.isNotEmpty() && number.findAll(details).any{candidate->detailUnits.none{candidate.range.first in it}})
   return Result("",location(cepValue),"Leitura com mais de um número possível. Confira rua e residência pelo lápis.")
  // A partial-circle T missed by the geometry must never become an accepted complement.
  // Preserve meaningful letters in reviewed/manual addresses; ask for review of uncertain OCR.
  val orphanIcon=Regex("""(?i)(?<![\p{L}\p{N}])(?:T\s*[)\]}]|[(\[{]\s*T)(?![\p{L}\p{N}])""")
  if(orphanIcon.containsMatchIn(text.substring(0,n.range.first)) || orphanIcon.containsMatchIn(afterNumber.substring(0,stop)))
   return Result("",location(cepValue),"Símbolo confundido com texto. Confira o endereço pelo lápis.")
  val prefix=text.substring(0,n.range.first)
  // An exact local street/CEP separates leading unit details without truncating a street name.
  val postal=BoaVistaPostal.entries.singleOrNull{it.postcode==cepValue}
  val prefixTokens=Regex("""[\p{L}\p{N}]+""").findAll(prefix).toList()
  val postalTokens=postal?.street?.let{Regex("""[\p{L}\p{N}]+""").findAll(it).map{t->normalizeSimple(t.value)}.toList()}
  val postalEnd=if(postalTokens!=null && prefixTokens.size>=postalTokens.size && prefixTokens.take(postalTokens.size).map{normalizeSimple(it.value)}==postalTokens)prefixTokens[postalTokens.size-1].range.last+1 else null
  val postalExtra=postalEnd?.let{clean(prefix.substring(it))}.orEmpty()
  val (streetPrefix,leadingExtra)=if(postalEnd!=null && Regex("""(?i)^(?:vila|quarto|apartamento|apto|apt|ap|casa|bloco|sala|loja|quadra|lote)\b""").containsMatchIn(postalExtra))
   prefix.substring(0,postalEnd) to postalExtra else {
    val firstUnit=unitRanges.firstOrNull{it.last<n.range.first}
    if(firstUnit!=null)prefix.substring(0,firstUnit.first) to clean(prefix.substring(firstUnit.first)) else AddressText.splitStreet(prefix)
   }
  val street=clean(streetPrefix)
  // Keep legitimate 'Rua T', but do not silently accept/erase a suspicious icon-like suffix.
  if(street.split(Regex("""\s+""")).size>=3 && Regex("""(?i)\sT$""").containsMatchIn(street))
   return Result("",location(cepValue),"Letra isolada no fim da rua. Confira o endereço pelo lápis.")
  if(street.length<4||street.none{it.isLetter()}||tracking.containsMatchIn(street))
   return Result("",location(cepValue),"Nome da rua não identificado com segurança. Use o lápis.")

  val remainder=clean(afterNumber)
  val d=bairro.find(remainder)
  val district=d?.value?:prefixDistrict
  val extra=clean(AddressText.clean(listOf(leadingExtra,if(d!=null)remainder.substring(0,d.range.first) else remainder).filter{it.isNotBlank()}.joinToString(" "))).take(55)
  val districtDisplay=when(normalizeSimple(district).uppercase(locale)){
   "PRICUMA" -> "Pricumã"
   "CIDADE SATELITE" -> "Cidade Satélite"
   else -> title(district)
  }
  val address=buildString {
   append(BoaVistaPostal.canonicalStreet(street,cepValue) ?: title(street));append(", ");append(n.value)
   if(extra.isNotBlank())append(", ${title(extra)}")
   if(districtDisplay.isNotBlank())append(" — $districtDisplay")
  }
  val warning=when {
   cepValue.isBlank()->"CEP não identificado. Confira antes de salvar."
   districtDisplay.isBlank()->"Bairro não identificado. Confira o endereço."
   else->""
  }
  return Result(address,location(cepValue),warning)
 }
}
