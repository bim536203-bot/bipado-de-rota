package br.com.leitorencomendas

import android.content.Context
import android.media.MediaPlayer

/** Use the same MediaPlayer.create route as V39 (media volume), for all parcel cues.
 * Do not use SoundPool/system-sonification: it can be muted independently on phones.
 */
class CaptureSounds(private val context:Context) {
 private var current:MediaPlayer?=null
 fun play(id:Int){
  release()
  try {
   val player=MediaPlayer.create(context,id) ?: return
   current=player
   player.setOnCompletionListener{finished->
    if(current===finished)current=null
    finished.release()
   }
   player.setOnErrorListener{failed,_,_->
    if(current===failed)current=null
    failed.release();true
   }
   player.start()
  }catch(_:Exception){release()}
 }
 fun release(){
  val player=current;current=null
  try{player?.release()}catch(_:Exception){}
 }
}
