package br.com.leitorencomendas

import java.time.Instant
import java.time.ZoneId

/** Name is based on the export instant in Boa Vista, not the parcel creation date. */
object SpokeRouteName {
 private val zone=ZoneId.of("America/Boa_Vista")
 private val days=listOf("SEGUNDA","TERÇA","QUARTA","QUINTA","SEXTA","SÁBADO","DOMINGO")
 fun title(at:Instant=Instant.now()):String="ROTA DE "+days[at.atZone(zone).dayOfWeek.value-1]
 fun filename(at:Instant=Instant.now()):String=title(at)+".csv"
}
