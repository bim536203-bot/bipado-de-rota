package br.com.leitorencomendas

import java.text.Normalizer
import java.util.Locale

/** Postal facts only, no house coordinates. Generated from assets/cidade-satelite-postcodes.json.
 * CEPs do Brasil / Cidade Satélite, retrieved 2026-10-24; source revision February 2026.
 */
object CidadeSatelitePostal {
 data class Entry(val street:String,val postcode:String)
 val entries:List<Entry> = listOf(
  Entry("Alameda Antares","69317-480"),
  Entry("Avenida Consolação de Matos","69317-474"),
  Entry("Avenida das Galáxias","69317-468"),
  Entry("Avenida dos Operários","69317-425"),
  Entry("Avenida Gêmeos","69317-470"),
  Entry("Avenida Jardim","69317-529"),
  Entry("Avenida Sebastião Correia Lira","69317-472"),
  Entry("Avenida Teresa Maciel","69317-464"),
  Entry("Avenida Unicamp","69317-835"),
  Entry("Avenida Universo","69317-466"),
  Entry("Rodovia Pedro Costa","69317-508"),
  Entry("Rua Aquário","69317-482"),
  Entry("Rua Áries","69317-484"),
  Entry("Rua Câncer","69317-486"),
  Entry("Rua Canopus","69317-490"),
  Entry("Rua Capella","69317-492"),
  Entry("Rua Carina","69317-576"),
  Entry("Rua Cassiopéia","69317-530"),
  Entry("Rua Deuza Leão","69317-579"),
  Entry("Rua Dom Apparecido José Dias","69317-488"),
  Entry("Rua Eclipse Solar","69317-519"),
  Entry("Rua Escorpião","69317-500"),
  Entry("Rua Faceten","69317-820"),
  Entry("Rua Faculdade Atual da Amazonia","69317-809"),
  Entry("Rua Faculdade Cathedral","69317-807"),
  Entry("Rua Faculdade Roraimense de Ensino Superior","69317-811"),
  Entry("Rua Halley","69317-504"),
  Entry("Rua Indus","69317-478"),
  Entry("Rua Izidio Lira","69317-534"),
  Entry("Rua J-7","69317-512"),
  Entry("Rua J-8","69317-514"),
  Entry("Rua James Meirelles Sobreiro Júnior","69317-550"),
  Entry("Rua João Batista Sobreiro","69317-552"),
  Entry("Rua Jonas Dias Carneiro","69317-506"),
  Entry("Rua Josemar Batista de Souza","69317-544"),
  Entry("Rua Leão","69317-518"),
  Entry("Rua Libra","69317-520"),
  Entry("Rua Manoel Adriano Girão","69317-563"),
  Entry("Rua Maria das Graças Paulino Cavalcante","69317-546"),
  Entry("Rua Maria de Matos Carneiro","69317-586"),
  Entry("Rua Maria Martins de Almeida","69317-556"),
  Entry("Rua Mimosa","69317-524"),
  Entry("Rua Morada do Sol","69317-517"),
  Entry("Rua Nascer do Sol","69317-513"),
  Entry("Rua NC-2","69317-401"),
  Entry("Rua NC-3","69317-400"),
  Entry("Rua Netuno","69317-526"),
  Entry("Rua Ondite de Lima Pereira","69317-538"),
  Entry("Rua Op - XI","69317-412"),
  Entry("Rua Op - XII","69317-414"),
  Entry("Rua Op - XIII","69317-413"),
  Entry("Rua Op - XIV","69317-415"),
  Entry("Rua Op - XV","69317-416"),
  Entry("Rua Op - XVI","69317-417"),
  Entry("Rua Op- IV","69317-405"),
  Entry("Rua Op- IX","69317-410"),
  Entry("Rua Op- V","69317-406"),
  Entry("Rua Op- VI","69317-407"),
  Entry("Rua Op- VII","69317-408"),
  Entry("Rua Op- VIII","69317-409"),
  Entry("Rua Op- X","69317-411"),
  Entry("Rua Op- XVII","69317-418"),
  Entry("Rua Op- XX","69317-420"),
  Entry("Rua Op- XXI","69317-421"),
  Entry("Rua Op- XXII","69317-422"),
  Entry("Rua Op- XXIII","69317-423"),
  Entry("Rua Op- XXIV","69317-424"),
  Entry("Rua Op- XXIX","69317-430"),
  Entry("Rua Op- XXVI","69317-426"),
  Entry("Rua Op- XXVII","69317-427"),
  Entry("Rua Op- XXVIII","69317-428"),
  Entry("Rua Op- XXX","69317-431"),
  Entry("Rua Op- XXXI","69317-432"),
  Entry("Rua Op- XXXII","69317-433"),
  Entry("Rua Op- XXXIII","69317-434"),
  Entry("Rua Órion","69317-528"),
  Entry("Rua Pedro Camargo","69317-803"),
  Entry("Rua Pégasus","69317-446"),
  Entry("Rua Peixes","69317-532"),
  Entry("Rua Pontifícia Universidade Católica","69317-829"),
  Entry("Rua Por do Sol","69317-515"),
  Entry("Rua Professora Maria Eugênia","69317-536"),
  Entry("Rua R-11","69317-540"),
  Entry("Rua R-24","69317-561"),
  Entry("Rua Raimundo Nonato Dias","69317-558"),
  Entry("Rua Sagitárius","69317-448"),
  Entry("Rua Salva do Campo","69317-531"),
  Entry("Rua Sidreira","69317-533"),
  Entry("Rua Sirius","69317-566"),
  Entry("Rua Telegrafista Rocha","69317-560"),
  Entry("Rua Tenente Azevedo Cruz","69317-542"),
  Entry("Rua Tenente Matos","69317-562"),
  Entry("Rua Tiam Fook","69317-548"),
  Entry("Rua Ulbra","69317-801"),
  Entry("Rua Unfes","69317-827"),
  Entry("Rua Unicórnio","69317-568"),
  Entry("Rua Universidade Estacio de Sá","69317-831"),
  Entry("Rua Universidade Estadual de Roraima","69317-805"),
  Entry("Rua Universidade Federal de Roraima","69317-810"),
  Entry("Rua Universidade Paulista","69317-833"),
  Entry("Rua Universidade São Paulo","69317-825"),
  Entry("Rua Urano","69317-570"),
  Entry("Rua Ursa Menor","69317-571"),
  Entry("Rua Vega","69317-574"),
  Entry("Travessa Op- XXVIII","69317-429")
 )
 private fun normalized(s:String)=Normalizer.normalize(s.lowercase(Locale.ROOT),Normalizer.Form.NFD)
  .replace(Regex("""\p{M}+"""),"").replace(Regex("""[^a-z0-9]+""")," ").trim()
 private fun words(s:String)=normalized(s).split(' ').filter {it.isNotBlank()}.map {when(it){"r"->"rua";"av"->"avenida";"al"->"alameda";"tv"->"travessa";else->it}}
 private val types=setOf("rua","avenida","alameda","travessa","via","rodovia")
 fun exact(street:String):Entry? = entries.singleOrNull {words(it.street)==words(street)}
 fun suggestions(fragment:String):List<Entry>{
  val tokens=words(fragment);val content=tokens.filter {it !in types && it !in setOf("de","da","do","das","dos")}
  val wanted=content.ifEmpty {tokens.filter {it in types}}.ifEmpty {tokens}
  if(wanted.isEmpty())return emptyList()
  return entries.filter {e->val available=words(e.street);wanted.all {w->available.any {it.startsWith(w)}}}
   .sortedWith(compareBy<Entry>{words(it.street).filter {w->w !in types && w !in setOf("de","da","do","das","dos")}.joinToString(" ")}.thenBy {normalized(it.street)})
 }
 private fun oneEdit(a:String,b:String):Boolean {
  if(kotlin.math.abs(a.length-b.length)>1)return false
  var i=0;var j=0;var edits=0
  while(i<a.length && j<b.length){
   if(a[i]==b[j]){i++;j++;continue}
   if(++edits>1)return false
   if(a.length>=b.length)i++
   if(b.length>=a.length)j++
  }
  return edits+(a.length-i)+(b.length-j)<=1
 }
 /** A visible exact CEP must agree; never infer the house number, city or missing CEP. */
 fun canonicalStreet(observed:String,postcode:String):String? {
  val target=entries.singleOrNull {it.postcode==postcode} ?: return null
  exact(observed)?.let {return if(it==target)it.street else null}
  val a=words(observed);val b=words(target.street)
  if(a.isEmpty())return null
  val typed=a.first() in types
  if(typed && a.first()!=b.first())return null // Rua != Alameda != Via
  val observedName=(if(typed)a.drop(1) else a).joinToString(" ")
  val expectedName=b.drop(1).joinToString(" ")
  if(observedName==expectedName || (observedName.length>=8 && oneEdit(observedName,expectedName)))return target.street
  return null
 }
}
