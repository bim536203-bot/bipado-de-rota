package br.com.leitorencomendas

/** Existing addresses can be kept offline; edits need a selection or complete user-reviewed text. */
object SavedAddressEdit {
 private val city=Regex("""(?i)\bBoa\s+Vista\s*[,/-]?\s*RR\b""")
 private val cep=Regex("""\b\d{5}[- ]?\d{3}\b""")
 private val house=Regex("""\b\d{1,5}(?:/\d{1,5})?[a-zA-Z]?\b""")
 fun ready(original:String,current:String,number:String,selected:Boolean):Boolean {
  if(!Regex("""\d+""").matches(number.trim()))return false
  if(number.trim().toIntOrNull()?.let{it>0}!=true)return false
  val address=current.trim()
  if(address.length !in 8..2000)return false
  if(address==original.trim() || selected)return true
  val location=city.find(address) ?: return false
  val street=cep.replace(address.substring(0,location.range.first),"")
  return street.count{it.isLetter()}>=3 && house.containsMatchIn(street)
 }
}
