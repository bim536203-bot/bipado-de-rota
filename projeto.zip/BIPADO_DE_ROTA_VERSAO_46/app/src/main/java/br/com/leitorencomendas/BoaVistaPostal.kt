package br.com.leitorencomendas

/** Street/CEP hints only; never confirms a house or manufactures coordinates. */
object BoaVistaPostal {
 data class Entry(val street:String,val postcode:String,val district:String)
 val entries=PricumaPostal.entries.map{Entry(it.street,it.postcode,"Pricumã")}+CidadeSatelitePostal.entries.map{Entry(it.street,it.postcode,"Cidade Satélite")}
 fun suggestions(fragment:String,district:String=""):List<Entry>{
  val codes=(PricumaPostal.suggestions(fragment).map{it.postcode}+CidadeSatelitePostal.suggestions(fragment).map{it.postcode}).toSet()
  return entries.filter{it.postcode in codes && (district.isBlank() || AddressIdentity.normalize(it.district)==AddressIdentity.normalize(district))}
 }
 fun canonicalStreet(street:String,postcode:String):String? = PricumaPostal.canonicalStreet(street,postcode) ?: CidadeSatelitePostal.canonicalStreet(street,postcode)
}
