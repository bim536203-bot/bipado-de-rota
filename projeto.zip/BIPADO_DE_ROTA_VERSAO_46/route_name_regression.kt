import br.com.leitorencomendas.SpokeRouteName
import java.time.Instant
fun main(){
 val names=listOf("SEGUNDA","TERÇA","QUARTA","QUINTA","SEXTA","SÁBADO","DOMINGO")
 for((i,name) in names.withIndex()){
  val at=Instant.parse("2026-10-${19+i}T16:00:00Z")
  check(SpokeRouteName.title(at)=="ROTA DE $name")
  check(SpokeRouteName.filename(at)=="ROTA DE $name.csv")
 }
 check(SpokeRouteName.title(Instant.parse("2026-10-20T03:59:59Z"))=="ROTA DE SEGUNDA")
 check(SpokeRouteName.title(Instant.parse("2026-10-20T04:00:00Z"))=="ROTA DE TERÇA")
 println("Spoke route names: seven days, accents and Boa Vista midnight passed")
}
