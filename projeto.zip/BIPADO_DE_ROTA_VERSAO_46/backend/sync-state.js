const clone=x=>JSON.parse(JSON.stringify(x));
const MAX=2147483647,RETENTION=7*86400000;
export function fresh(){return {schema:1,revision:0,items:[],skipped:[],history:[],lastNumber:0};}
const integer=n=>Number.isInteger(n)&&n>0&&n<=MAX;
const identity=id=>typeof id==='string'&&/^[a-zA-Z0-9:_-]{1,100}$/.test(id);
export function validState(input,now=Date.now()){
 if(!input||input.schema!==1||!Array.isArray(input.items)||!Array.isArray(input.skipped)||!Array.isArray(input.history))throw Error('Dados da conta inválidos.');
 const items=raw=>{
  if(!Array.isArray(raw)||raw.length>10000)throw Error('Lista muito grande.');
  const ids=new Set(),numbers=new Set();
  return raw.map(i=>{
   if(!i||!identity(i.id)||ids.has(i.id)||!integer(i.number)||numbers.has(i.number)||typeof i.address!=='string'||i.address.trim().length<5||i.address.length>2000)throw Error('Pacote inválido.');
   ids.add(i.id);numbers.add(i.number);
   const out={id:i.id,number:i.number,address:i.address,createdAt:Number.isFinite(i.createdAt)?i.createdAt:0};
   if(i.whatsapp){if(!/^55\d{10,11}$/.test(i.whatsapp))throw Error('Contato inválido.');out.whatsapp=i.whatsapp;}
   if(i.point){if(!Number.isFinite(i.point.lat)||Math.abs(i.point.lat)>90||!Number.isFinite(i.point.lon)||Math.abs(i.point.lon)>180||!['house','place','manual'].includes(i.point.precision))throw Error('Ponto inválido.');out.point=clone(i.point);}
   if(typeof i.captureToken==='string'&&i.captureToken.length<100)out.captureToken=i.captureToken;
   return out;
  });
 };
 const skipped=raw=>[...new Set(raw.filter(integer))];
 const historyIds=new Set();
 const history=input.history.map(h=>{
  if(!h||!identity(h.id)||historyIds.has(h.id)||!Number.isFinite(h.deletedAt)||h.deletedAt>now+300000||!Array.isArray(h.skipped))throw Error('Histórico inválido.');
  historyIds.add(h.id);return {id:h.id,deletedAt:h.deletedAt,items:items(h.items),skipped:skipped(h.skipped)};
 }).filter(h=>h.deletedAt>0&&now-h.deletedAt<RETENTION);
 const current=items(input.items),numbers=new Set(current.map(i=>i.number));
 const skips=skipped(input.skipped).filter(n=>!numbers.has(n));
 return {schema:1,revision:Number.isSafeInteger(input.revision)?input.revision:0,items:current,skipped:skips,history,lastNumber:Math.max(0,...current.map(i=>i.number),...skips)};
}
export function mergeChange(server,before,after,now=Date.now()){
 const current=validState(server,now),base=validState(before,now),next=validState(after,now);
 const old=new Map(base.items.map(i=>[i.id,i])),changed=new Map(next.items.map(i=>[i.id,i]));
 const rows=new Map(current.items.map(i=>[i.id,i]));
 for(const id of old.keys())if(!changed.has(id))rows.delete(id);
 // Apply only fields actually changed on this device; remote contact/point edits survive.
 for(const item of next.items){
  const previous=old.get(item.id),live=rows.get(item.id);
  if(previous&&!live)continue; // remote deletion wins over a stale edit
  if(!previous){
   if(live)continue;
   const copy=clone(item),occupied=new Set([...rows.values()].map(i=>i.number));
   if(occupied.has(copy.number)||current.skipped.includes(copy.number))copy.number=Math.max(0,...occupied,...current.skipped)+1;
   if(copy.number>MAX)throw Error('Limite de pacotes atingido.');
   rows.set(copy.id,copy);
  }else{
   const copy=clone(live);
   for(const field of ['number','address','whatsapp','point','captureToken'])if(JSON.stringify(previous[field])!==JSON.stringify(item[field])){
    if(item[field]===undefined)delete copy[field];else copy[field]=clone(item[field]);
   }
   if([...rows.values()].some(i=>i.id!==copy.id&&i.number===copy.number))throw Error('Número de pacote alterado em outro aparelho. Confira a lista.');
   rows.set(copy.id,copy);
  }
 }
 const skips=new Set(current.skipped);
 for(const n of base.skipped)if(!next.skipped.includes(n))skips.delete(n);
 for(const n of next.skipped)if(!base.skipped.includes(n))skips.add(n);
 const histories=new Map(current.history.map(h=>[h.id,h]));
 for(const h of base.history)if(!next.history.some(n=>n.id===h.id))histories.delete(h.id);
 for(const h of next.history)if(!base.history.some(b=>b.id===h.id)){
  const copy=clone(h);
  // A clear/import archives the full server list, including concurrent additions.
  if(base.items.length&&h.items.length===base.items.length&&h.items.every(i=>old.has(i.id))&&base.items.every(i=>!changed.has(i.id))){
   copy.items=clone(current.items);copy.skipped=[...current.skipped];
   for(const i of current.items)if(!changed.has(i.id))rows.delete(i.id);
  }
  histories.set(h.id,copy);
 }
 return validState({...current,items:[...rows.values()],skipped:[...skips],history:[...histories.values()]},now);
}
