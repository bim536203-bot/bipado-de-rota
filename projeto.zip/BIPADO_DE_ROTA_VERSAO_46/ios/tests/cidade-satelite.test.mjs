import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {cidadeSatelitePostcodes as data} from '../dist/cidade-satelite-postcodes.js';
import {localSuggestions,verifiedPoint,searchSuggestions} from '../dist/mini-map.js';
test('105 ruas/CEPs de Cidade Satélite: paridade e sugestões sem inventar coordenadas',async()=>{
 const native=JSON.parse(await readFile(new URL('../../app/src/main/assets/cidade-satelite-postcodes.json',import.meta.url)));
 assert.deepEqual(data,native);assert.equal(data.entries.length,105);
 const kotlin=await readFile(new URL('../../app/src/main/java/br/com/leitorencomendas/CidadeSatelitePostal.kt',import.meta.url),'utf8');
 assert.deepEqual([...kotlin.matchAll(/Entry\("([^"]+)","(\d{5}-\d{3})"\)/g)].map(m=>({street:m[1],postcode:m[2]})),data.entries);
 for(const e of data.entries){
  const hits=await searchSuggestions({fetch:()=>{throw Error('offline expected');}},'28 '+e.street+', Cidade Satélite, Boa Vista, RR');
  const hit=hits.find(h=>h.streetLine===e.street+', 28, Cidade Satélite'&&h.postcode===e.postcode);
  assert.ok(hit,e.street);assert.equal(verifiedPoint(hit),null);assert.equal(hit.lat,null);assert.equal(hit.lon,null);
 }
 assert.ok(localSuggestions('28 lib, Cidade Satélite, Boa Vista, RR').some(h=>h.streetLine==='Rua Libra, 28, Cidade Satélite'&&h.postcode==='69317-520'));
 assert.ok(!localSuggestions('28 vega, Pricumã, Boa Vista, RR').some(h=>h.postalOnly));
 const sw=await readFile(new URL('../dist/sw.js',import.meta.url),'utf8');assert.ok(sw.includes("'cidade-satelite-postcodes.js'"));
});
test('Som WhatsApp é exatamente a opção 3 escolhida',async()=>{
 const path='../../app/src/main/';
 const picked=await readFile(new URL(path+'res/raw/bip_whatsapp.wav',import.meta.url));
 const {createHash}=await import('node:crypto');assert.equal(createHash('sha256').update(picked).digest('hex'),'7a76d9fad7483b6d7b2ad8f2958fa95113b5258fe3320bf51555fc08beaf2a9a');
});
