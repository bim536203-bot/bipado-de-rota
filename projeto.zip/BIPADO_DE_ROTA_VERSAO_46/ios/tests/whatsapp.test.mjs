import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {JSDOM} from 'jsdom';
import * as C from '../dist/core.js';import {createApp} from '../dist/app.js';
const a='Rua Exemplo, 28, Boa Vista, RR';
const phones=[{number:1,address:a,whatsapp:'5595999991234'},{number:7,address:a,whatsapp:'5511988881234'}];
test('CSV Android/WhatsApp importa os telefones por pacote, conserva no banco/histórico e exporta de volta',async()=>{
 const csv=await readFile(new URL('./fixtures/android-whatsapp-export.csv',import.meta.url),'utf8');const items=C.parseCsv(csv);
 assert.equal(items[0].whatsapp,phones[0].whatsapp);assert.equal(items[1].number,7);assert.equal(items[1].whatsapp,phones[1].whatsapp);
 let s=C.importRoute(C.freshState(),items);s=C.validateState(s);assert.equal(s.items[1].whatsapp,phones[1].whatsapp);
 const exported=C.exportCsv(s.items);assert.equal(exported,csv);s=C.clearRoute(s,10000);assert.equal(s.history[0].items[0].whatsapp,phones[0].whatsapp);
 s=C.restoreRoute(s,s.history[0].id,10001);assert.equal(s.items[1].whatsapp,phones[1].whatsapp);
 for(const note of ['PACOTE 1; WA2=5595999991234','PACOTE 1; WA1=5595999991234; WA1=5511988881234','PACOTE 1; WA1=5500999991234'])assert.throws(()=>C.parseCsv(`Address,Notes\n"${a}","${note}"\n`));
 assert.throws(()=>C.validateItems([{number:1,address:a,whatsapp:'javascript:alert(1)'}]));
});
test('iPhone só mostra WhatsApp com telefone, oferece pacote no grupo e preenche mensagem sem envio automático',async()=>{
 const dom=new JSDOM(await readFile(new URL('../dist/index.html',import.meta.url),'utf8'),{url:'https://example.test/#addresses'}),w=dom.window,d=w.document;
 w.scrollTo=()=>{};w.matchMedia=()=>({matches:false});w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open')};
 let state=C.importRoute(C.freshState(),[...phones,{number:3,address:'Rua Sem telefone, 99, Boa Vista, RR'}]),opened=[];
 const app=createApp(w,{readState:async()=>state,commitState:async(rev,fn)=>state=fn(state)},{openWhatsapp:url=>opened.push(url),sounds:{unlock(){},play(){}}});await app.ready;
 assert.equal(d.querySelectorAll('.whatsapp-button').length,1);assert.equal(d.querySelectorAll('[aria-label*=cadeado]').length,0);
 d.querySelector('.whatsapp-button').click();assert.equal(opened.length,0);
 [...d.querySelectorAll('.choice-button')].find(b=>b.textContent.startsWith('PACOTE 7')).click();assert.equal(opened.length,1);
 const url=new URL(opened[0]);assert.equal(url.pathname,'/5511988881234');assert.equal(url.searchParams.get('text'),C.WHATSAPP_MESSAGE);assert.ok(!url.searchParams.has('send'));
 w.close();
});

test('Spoke recebe só endereço/pacotes; backup mantém contatos e não modifica a lista',async()=>{
 const source=[...phones,{number:3,address:'Rua Outra, 99, Boa Vista, RR'}],before=structuredClone(source);
 const csv=C.exportSpokeCsv(source),back=C.exportCsv(source);
 const android=await readFile(new URL('./fixtures/android-spoke-export.csv',import.meta.url),'utf8');
 assert.equal(C.exportSpokeCsv(phones),android);
 assert.match(csv,/PACOTE 1-7/);assert.match(csv,/PACOTE 3/);assert.doesNotMatch(csv,/WA\d+=|5595999991234|5511988881234/);
 assert.ok(csv.indexOf('PACOTE 1-7')<csv.indexOf('PACOTE 3'));
 assert.equal(C.parseCsv(csv).length,3);assert.ok(C.parseCsv(csv).every(i=>!i.whatsapp));
 assert.match(back,/WA1=5595999991234/);assert.match(back,/WA7=5511988881234/);assert.deepEqual(source,before);
});

test('Botão EXPORTAR PARA ROTA SPOKE compartilha CSV sem telefone; BAIXAR ROTAS preserva contatos',async()=>{
 const dom=new JSDOM(await readFile(new URL('../dist/index.html',import.meta.url),'utf8'),{url:'https://example.test/#addresses'}),w=dom.window,d=w.document;
 w.scrollTo=()=>{};w.matchMedia=()=>({matches:false});w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open')};
 const state=C.importRoute(C.freshState(),phones),before=structuredClone(state),shared=[];
 w.navigator.canShare=()=>true;w.navigator.share=async payload=>shared.push(payload.files[0]);
 const app=createApp(w,{readState:async()=>structuredClone(state),commitState:async()=>{throw new Error('Exportação não deve gravar');}},{sounds:{unlock(){},play(){}}});await app.ready;
 const text=file=>new Promise((resolve,reject)=>{const r=new w.FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsText(file);});
 d.getElementById('spoke-export').click();await new Promise(r=>w.setTimeout(r,0));assert.equal(shared.length,1);assert.equal(shared[0].name,C.spokeRouteName()+'.csv');
 const exported=await text(shared[0]);assert.equal(exported.replace(/^\uFEFF/,''),C.exportSpokeCsv(state.items));assert.doesNotMatch(exported,/WA\d+=|5595999991234|5511988881234/);
 app.navigate('home');d.getElementById('export-home').click();[...d.querySelectorAll('#dialog-actions button')].find(b=>b.textContent==='COMPARTILHAR').click();await new Promise(r=>w.setTimeout(r,0));
 assert.equal(shared.length,2);const backup=await text(shared[1]);assert.match(backup,/WA1=5595999991234/);assert.match(backup,/WA7=5511988881234/);assert.deepEqual(state,before);w.close();
});
