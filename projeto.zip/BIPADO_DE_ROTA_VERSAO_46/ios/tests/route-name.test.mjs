import test from 'node:test';
import assert from 'node:assert/strict';
import {spokeRouteName} from '../dist/core.js';
test('Nome Spoke acompanha todos os dias e a virada da data de Boa Vista',()=>{
 const names=['SEGUNDA','TERÇA','QUARTA','QUINTA','SEXTA','SÁBADO','DOMINGO'];
 names.forEach((name,i)=>assert.equal(spokeRouteName(new Date(`2026-10-${19+i}T16:00:00Z`)),`ROTA DE ${name}`));
 assert.equal(spokeRouteName(new Date('2026-10-20T03:59:59Z')),'ROTA DE SEGUNDA');
 assert.equal(spokeRouteName(new Date('2026-10-20T04:00:00Z')),'ROTA DE TERÇA');
});
