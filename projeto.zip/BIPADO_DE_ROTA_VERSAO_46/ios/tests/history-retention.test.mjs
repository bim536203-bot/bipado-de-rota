import test from 'node:test';
import assert from 'node:assert/strict';
import * as C from '../dist/core.js';
import {fresh,validState,mergeChange} from '../../backend/sync-state.js';
test('Histórico local e sincronizado conserva até 7 dias e expira no limite',()=>{
 const now=1792843200000,week=7*86400000;
 assert.equal(C.RETENTION,week);
 const h={id:'history:test',deletedAt:now,items:[],skipped:[]};
 const local={...C.freshState(),history:[h]},remote={...fresh(),history:[h]};
 for(const age of [86400000,6*86400000,week-1]){
  assert.equal(C.prune(local,now+age).history.length,1);
  assert.equal(validState(remote,now+age).history.length,1);
  assert.equal(mergeChange(remote,remote,remote,now+age).history.length,1);
 }
 for(const age of [week,week+1]){
  assert.equal(C.prune(local,now+age).history.length,0);
  assert.equal(validState(remote,now+age).history.length,0);
 }
});
