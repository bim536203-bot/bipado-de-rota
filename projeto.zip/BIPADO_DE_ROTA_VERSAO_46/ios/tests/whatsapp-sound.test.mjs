import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
test('Captura WhatsApp tem WAV próprio íntegro e diferente dos três avisos de pacote',async()=>{
 const raw=new URL('../../app/src/main/res/raw/',import.meta.url);
 const data=await readFile(new URL('bip_whatsapp.wav',raw));
 assert.equal(data.toString('ascii',0,4),'RIFF');
 assert.equal(data.toString('ascii',8,12),'WAVE');
 assert.equal(data.readUInt32LE(4)+8,data.length);
 assert.equal(data.readUInt16LE(20),1);assert.equal(data.readUInt16LE(22),1);
 assert.equal(data.readUInt16LE(34),16);
 const duration=data.readUInt32LE(40)/data.readUInt32LE(28);
 assert.ok(duration>.35&&duration<.55);
 let peak=0;for(let i=44;i<data.length;i+=2)peak=Math.max(peak,Math.abs(data.readInt16LE(i)));
 assert.ok(peak>5000&&peak<32767);
 for(const kind of ['sucesso','erro','repetido'])assert.ok(!data.equals(await readFile(new URL('bip_'+kind+'.wav',raw))));
});
