import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';
import {createApp} from '../dist/app.js';
import * as C from '../dist/core.js';
const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');
const A='Rua Exemplo, 28, Boa Vista, RR',B='Rua Outra, 100, Boa Vista, RR';
const tick=()=>new Promise(r=>setTimeout(r,0)),settle=()=>new Promise(r=>setTimeout(r,430));
async function fixture(initial,services={}){
 const dom=new JSDOM(html,{url:'https://example.test/#addresses'}),w=dom.window,d=w.document;
 w.scrollTo=()=>{};w.matchMedia=()=>({matches:false});
 w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};
 w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open')};
 let state=structuredClone(initial);
 const repo={readState:async()=>structuredClone(state),commitState:async(rev,fn)=>{assert.equal(rev,state.revision);state=C.validateState({...fn(structuredClone(state)),revision:rev+1});return structuredClone(state)}};
 const app=createApp(w,repo,{sounds:{unlock(){},play(){}},...services});await app.ready;
 const click=label=>{const b=[...d.querySelectorAll('#dialog-actions button')].find(x=>x.textContent===label&&!x.hidden);assert.ok(b,label);b.click()};
 return {app,w,d,dom,click,get state(){return state}};
}
function seed(){const s=C.importRoute(C.freshState(),[1,5,7].map(number=>({number,address:A})).concat({number:3,address:B}));s.skipped=[9];return s;}
test('Endereços salvos: exportação e cartões no mesmo scroll, toolbar fora, grupos e pulados em ordem Android',async()=>{
 const f=await fixture(seed());try{
  const {d}=f,scroll=d.querySelector('.saved-scroll');
  assert.equal(scroll.contains(d.querySelector('.android-toolbar')),false);
  assert.equal(scroll.firstElementChild.id,'spoke-export');assert.equal(scroll.lastElementChild.id,'address-list');
  assert.equal(d.getElementById('addresses-title'),null);assert.equal(d.getElementById('saved-back').textContent,'');
  assert.equal(d.getElementById('spoke-export').getAttribute('aria-label'),'EXPORTAR PARA ROTA SPOKE');
  assert.equal(d.querySelector('.spoke-export img').getAttribute('src'),'./assets/exportar-para-spoke.png');
  assert.deepEqual([...d.querySelectorAll('#address-list h2')].map(x=>x.textContent),['PACOTE 9 pulado','PACOTE 3','PACOTE 1-5-7']);
  assert.equal(d.querySelectorAll('.package-badge').length,1);assert.equal(d.querySelector('.package-badge').textContent,'1-5-7');
  assert.equal(d.querySelector('.skipped-card .card-actions'),null);
  d.getElementById('search-button').click();const q=d.getElementById('search');q.value='pulado';q.dispatchEvent(new f.w.Event('input'));
  assert.equal(d.querySelectorAll('#address-list article').length,1);
  d.querySelector('.skipped-card button').click();assert.deepEqual(f.state.skipped,[9]);f.click('CANCELAR');assert.deepEqual(f.state.skipped,[9]);
  d.querySelector('.skipped-card button').click();f.click('CONFIRMAR');await tick();assert.deepEqual(f.state.skipped,[]);assert.equal(f.state.items.length,4);assert.equal(C.nextNumber(f.state),8);
 }finally{f.dom.window.close()}
});
test('Exportação Spoke entrega um único CSV fiel no gesto, cancelamento não baixa e fallback mantém o arquivo',async()=>{
 const f=await fixture(seed());try{
  const calls=[],downloads=[],{w,d}=f;
  w.navigator.canShare=()=>true;w.navigator.share=async data=>{calls.push(data)};
  d.getElementById('spoke-export').click();await tick();assert.equal(calls.length,1);
  const file=calls[0].files[0];assert.equal(file.name,C.spokeRouteName()+'.csv');assert.equal(file.type,'text/csv');
  const bytes=await new Promise((resolve,reject)=>{const r=new w.FileReader();r.onload=()=>resolve(new Uint8Array(r.result));r.onerror=reject;r.readAsArrayBuffer(file)});
  assert.deepEqual([...bytes.slice(0,3)],[239,187,191]);assert.equal(new TextDecoder().decode(bytes),C.exportCsv(f.state.items));
  assert.deepEqual(C.parseCsv(new TextDecoder().decode(bytes)).map(x=>x.number),[1,5,7,3]);
  w.navigator.share=async()=>{throw Object.assign(new Error(),{name:'AbortError'})};d.getElementById('spoke-export').click();await tick();assert.equal(d.getElementById('app-dialog').open,false);
  w.navigator.canShare=()=>false;w.URL.createObjectURL=()=> 'blob:test';w.URL.revokeObjectURL=()=>{};
  w.HTMLAnchorElement.prototype.click=function(){downloads.push(this.download)};
  d.getElementById('spoke-export').click();await tick();assert.deepEqual(downloads,[C.spokeRouteName()+'.csv']);assert.equal(f.state.items.length,4);
 }finally{f.dom.window.close()}
});
test('Seleção fica na busca: tocar fora ou digitar desmarca; SALVAR abre mapa e somente CONFIRMAR persiste',async()=>{
 const hit={streetLine:'Rua Vega, 28',location:'Boa Vista, RR, 69317-803',postcode:'69317-803',lat:2.8,lon:-60.6,exact:false,label:'Rua Vega, 28'};
 let maps=0;const f=await fixture(C.freshState(),{searchSuggestions:async()=>[hit],mapFactory:()=>{maps++;return {destroy(){}}}});
 try{
  f.d.getElementById('import-home').click();const q=f.d.getElementById('editor-address');q.value='28 ve';q.dispatchEvent(new f.w.Event('input'));await settle();
  const row=f.d.querySelector('.address-suggestion'),save=f.d.querySelector('.save-address');assert.match(row.textContent,/69317-803/);
  row.click();assert.equal(save.hidden,false);assert.equal(row.getAttribute('aria-pressed'),'true');assert.equal(maps,0);assert.equal(q.value,'28 ve');
  f.d.querySelector('.sheet-label').click();assert.equal(save.hidden,true);assert.equal(row.getAttribute('aria-pressed'),'false');assert.equal(q.value,'28 ve');
  row.click();q.value='28 veg';q.dispatchEvent(new f.w.Event('input'));assert.equal(save.hidden,true);await settle();
  f.d.querySelector('.address-suggestion').click();f.click('SALVAR');assert.equal(maps,0);assert.equal(f.state.items.length,0);assert.ok(f.d.querySelector('.parcel-confirmation'));
  f.click('CONFIRMAR');await tick();assert.equal(f.state.items.length,1);assert.match(f.state.items[0].address,/69317-803/);
 }finally{f.dom.window.close()}
});
test('Ripple nasce no toque sem mudar texto, tamanho ou ação e não anima controle desativado',async()=>{
 const f=await fixture(seed());try{
  const b=f.d.getElementById('search-button'),before=b.textContent;
  b.getBoundingClientRect=()=>({width:55,height:58,left:100,top:20});
  b.dispatchEvent(new f.w.MouseEvent('pointerdown',{bubbles:true,clientX:113,clientY:34}));
  const wave=b.querySelector('.touch-wave');assert.ok(wave);assert.equal(wave.style.left,'-45px');assert.equal(wave.style.top,'-44px');assert.equal(b.textContent,before);
  b.click();assert.equal(f.d.getElementById('search-box').hidden,false);
  b.disabled=true;b.dispatchEvent(new f.w.MouseEvent('pointerdown',{bubbles:true}));assert.equal(b.querySelectorAll('.touch-wave').length,1);
 }finally{f.dom.window.close()}
});
