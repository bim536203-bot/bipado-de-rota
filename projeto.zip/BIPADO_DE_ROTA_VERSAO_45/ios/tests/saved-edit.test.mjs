import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {JSDOM} from 'jsdom';
import {createApp} from '../dist/app.js';import * as C from '../dist/core.js';
const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');
const address='Rua Leão, 670, Cidade Satélite, Boa Vista, RR, 69317-518, Brasil';
const point={lat:2.85,lon:-60.7,precision:'manual'},phone='5595999991234';
const tick=()=>new Promise(r=>setTimeout(r,0));
async function fixture(services={}){
 const dom=new JSDOM(html,{url:'https://example.test/#addresses'}),w=dom.window,d=w.document;
 w.scrollTo=()=>{};w.matchMedia=()=>({matches:false});w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open')};
 let state=C.importRoute(C.freshState(),[{number:61,id:'parcel:61',address,whatsapp:phone,point},{number:80,id:'parcel:80',address:'Rua Libra, 40, Cidade Satélite, Boa Vista, RR'}]);
 const repo={readState:async()=>structuredClone(state),commitState:async(rev,fn)=>{state=C.validateState({...fn(structuredClone(state)),revision:rev+1});return structuredClone(state)}};
 const app=createApp(w,repo,{searchSuggestions:async()=>[],sounds:{unlock(){},play(){}},...services});await app.ready;
 const card=[...d.querySelectorAll('.address-card')].find(x=>x.textContent.includes('PACOTE 61'));card.querySelector('.card-actions button').click();
 const input=(id,value)=>{d.getElementById(id).value=value;d.getElementById(id).dispatchEvent(new w.Event('input'))};
 const confirm=()=>[...d.querySelectorAll('#dialog-actions button')].find(b=>b.textContent==='CONFIRMAR');
 return {dom,d,input,confirm,get state(){return state},external(){state.items.find(i=>i.number===61).address='Rua Outra, 25, Boa Vista, RR'}};
}
test('Editar endereço existente libera confirmar imediatamente e preserva ponto e contato',async()=>{
 const f=await fixture();try{assert.equal(f.confirm().disabled,false);f.confirm().click();await tick();const i=f.state.items.find(i=>i.number===61);assert.equal(i.address,address);assert.deepEqual(i.point,point);assert.equal(i.whatsapp,phone);}finally{f.dom.window.close()}
});
test('Renumerar offline não depende de sugestão e mantém o endereço e seus dados',async()=>{
 const f=await fixture();try{f.input('editor-number','62');assert.equal(f.confirm().disabled,false);f.confirm().click();await tick();const i=f.state.items.find(i=>i.number===62);assert.equal(i.address,address);assert.deepEqual(i.point,point);assert.equal(i.whatsapp,phone);assert.ok(!f.state.items.some(i=>i.number===61));}finally{f.dom.window.close()}
});
test('Correção manual completa salva sem rede; fragmento e número inválido ficam bloqueados',async()=>{
 const f=await fixture();try{
  f.input('editor-address','671 le');assert.equal(f.confirm().disabled,true);
  f.input('editor-address',address.replace('670','671'));assert.equal(f.confirm().disabled,false);
  f.input('editor-number','');assert.equal(f.confirm().disabled,true);f.input('editor-number','2147483648');assert.equal(f.confirm().disabled,true);
  f.input('editor-number','61');assert.equal(f.confirm().disabled,false);f.confirm().click();await tick();const i=f.state.items.find(i=>i.number===61);assert.match(i.address,/671/);assert.equal(i.point,undefined);assert.equal(i.whatsapp,phone);
 }finally{f.dom.window.close()}
});
test('Restaura texto original e rejeita número ocupado sem alterar lista',async()=>{
 const f=await fixture();try{f.input('editor-address','fragmento');assert.equal(f.confirm().disabled,true);f.input('editor-address',address);assert.equal(f.confirm().disabled,false);f.input('editor-number','80');f.confirm().click();await tick();assert.equal(f.state.items.find(i=>i.number===61).address,address);assert.match(f.d.getElementById('dialog-error').textContent,/já está em uso/);}finally{f.dom.window.close()}
});
test('Edição não sobrescreve endereço alterado em outro aparelho',async()=>{
 const f=await fixture();try{f.external();f.confirm().click();await tick();assert.match(f.state.items.find(i=>i.number===61).address,/Rua Outra/);assert.match(f.d.getElementById('dialog-error').textContent,/mudou em outro aparelho/);}finally{f.dom.window.close()}
});

test('Selecionar o mesmo endereço permite salvar novo ponto escolhido explicitamente',async()=>{
 const moved={lat:2.86,lon:-60.71,precision:'manual'};
 const hit={streetLine:'Rua Leão, 670, Cidade Satélite',location:'Boa Vista, RR, 69317-518, Brasil',label:'Rua Leão, 670',lat:2.85,lon:-60.7,exact:true};
 const f=await fixture({searchSuggestions:async()=>[hit],mapFactory:(w,c,s,a,options)=>{options.onPointChanged(moved);return {destroy(){}}}});
 try{f.input('editor-address','670 le');await new Promise(r=>setTimeout(r,430));f.d.querySelector('.address-suggestion').click();assert.equal(f.confirm().disabled,false);f.confirm().click();await tick();assert.deepEqual(f.state.items.find(i=>i.number===61).point,moved);}finally{f.dom.window.close()}
});
