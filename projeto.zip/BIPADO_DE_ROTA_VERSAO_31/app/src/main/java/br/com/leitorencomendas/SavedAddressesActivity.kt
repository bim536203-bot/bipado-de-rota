package br.com.leitorencomendas

import android.app.*
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import android.os.Bundle
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import java.text.Normalizer
import java.util.Locale
import android.view.*
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.graphics.drawable.ColorDrawable
import android.os.VibrationEffect
import android.os.Vibrator

class SavedAddressesActivity : Activity() {
 private lateinit var list: LinearLayout
 private lateinit var searchField: EditText
 private lateinit var searchBox: LinearLayout
 private var searchOpen=false
 private var query=""
 private fun normalized(text:String):String=Normalizer.normalize(text.lowercase(Locale.forLanguageTag("pt-BR")),Normalizer.Form.NFD)
  .replace(Regex("""\p{M}+"""),"")
  .replace(Regex("""[^a-z0-9]+""")," ").trim()
 private fun matches(numbers:List<Int>,address:String,request:String):Boolean {
  val haystack=normalized(numbers.joinToString(" "){"Pacote $it"}+" "+numbers.joinToString("-")+" "+address)
  val compact=haystack.replace(" ","")
  val terms=normalized(request).split(' ').filter{it.isNotBlank()}
  return terms.isEmpty()||terms.all{term->haystack.contains(term)||compact.contains(term)}
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4),dp(8),dp(4),dp(8)); setBackgroundColor(Color.WHITE) }
  val header = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setBackgroundColor(Color.WHITE) }
  val back=ImageView(this).apply {
   setImageResource(R.drawable.ic_back_blue);setPadding(dp(13),dp(12),dp(13),dp(12));contentDescription="Voltar"
   setOnClickListener{finish()}; ripple(this)
  }
  header.addView(back,LinearLayout.LayoutParams(dp(60),dp(58)))
  header.addView(View(this),LinearLayout.LayoutParams(0,1,1f))
  header.addView(ImageView(this).apply {
   setImageResource(R.drawable.ic_search_blue);setPadding(dp(12),dp(12),dp(12),dp(12))
   contentDescription="Pesquisar endereços salvos";ripple(this)
   setOnClickListener {
    searchOpen=!searchOpen
    searchBox.visibility=if(searchOpen) View.VISIBLE else View.GONE
    if(searchOpen){searchField.requestFocus();searchField.post { (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(searchField,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) }}
    else {searchField.setText("");(getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(searchField.windowToken,0)}
   }
  },LinearLayout.LayoutParams(dp(55),dp(58)))
  header.addView(ImageView(this).apply {
   setImageResource(R.drawable.ic_trash_blue);setPadding(dp(13),dp(13),dp(13),dp(13))
   contentDescription="Apagar todos os endereços";ripple(this)
   setOnClickListener {
    AlertDialog.Builder(this@SavedAddressesActivity).setTitle("Apagar todos os endereços?")
     .setMessage("A lista será guardada por 24 horas em Histórico de lista apagada, para consulta e restauração.")
     .setNegativeButton("CANCELAR",null)
     .setPositiveButton("CONFIRMAR") { _,_ -> Store.clear(this@SavedAddressesActivity); render() }.show()
   }
  },LinearLayout.LayoutParams(dp(60),dp(58)))
  root.addView(header)
  searchField=EditText(this).apply{
   hint="Pesquisar rua, número, bairro ou pacote"
   setSingleLine(true)
   textSize=16f
   addTextChangedListener(object:TextWatcher {
    override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
    override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){query=s?.toString().orEmpty();render()}
    override fun afterTextChanged(s:Editable?){}
   })
  }
  searchBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(6),dp(5),dp(6),dp(6))}
  searchBox.addView(searchField,LinearLayout.LayoutParams(-1,-2))
  root.addView(searchBox)
  val scroll=ScrollView(this).apply { setFillViewport(true); clipToPadding=false }
  val content=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}
  val spokeButton=ImageView(this).apply {
   setImageResource(R.drawable.importar_para_spoke)
   scaleType=ImageView.ScaleType.FIT_CENTER
   contentDescription="EXPORTAR PARA ROTA SPOKE"
   isClickable=true
   foreground=RippleDrawable(ColorStateList.valueOf(0x55FFFFFF),null,GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=dp(16).toFloat()})
   setOnClickListener { vibrateLikeFloatingIcon();shareRouteWithSpoke() }
  }
  content.addView(spokeButton,LinearLayout.LayoutParams(-1,dp(86)).apply{bottomMargin=dp(10)})
  list=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(4),0,dp(4),0)}
  content.addView(list)
  scroll.addView(content)
  root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  setContentView(root)
 }
 override fun onResume() { super.onResume(); render() }
 private fun ripple(view:View){
  view.isClickable=true
  view.foreground=RippleDrawable(ColorStateList.valueOf(0x33216BE0),null,null)
 }
 private fun vibrateLikeFloatingIcon(){
  val vibrator=getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
  if(vibrator.hasVibrator())vibrator.vibrate(VibrationEffect.createOneShot(70,VibrationEffect.DEFAULT_AMPLITUDE))
 }
 private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
 private fun render() {
  list.removeAllViews()
  val items = Store.all(this)
  val skipped=Store.skipped(this)
  val skippedNumbers=(0 until skipped.length()).map{skipped.optInt(it)}.filter{it>0}.toSet()
  val existing=Store.addressGroups(items).associateBy {it.primaryNumber}
  val allNumbers=(existing.keys+skippedNumbers).distinct().sortedDescending()
  if(allNumbers.isEmpty()){list.addView(TextView(this).apply{text="Nenhum endereço salvo";textSize=18f});return}
  var shown=0
  for(n in allNumbers){
   val group=existing[n]
   if(group==null){
    if(!matches(listOf(n),"pulado",query))continue
    val compact=LinearLayout(this).apply{
     orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),dp(8),dp(16),dp(8))
     background=GradientDrawable().apply{setColor(0xFFF2F5FA.toInt());cornerRadius=dp(14).toFloat();setStroke(dp(1),0xFFD8DFE9.toInt())}
    }
    compact.addView(TextView(this).apply{
     text="PACOTE $n pulado";textSize=20f;setTextColor(0xFF162C4C.toInt())
    },LinearLayout.LayoutParams(0,-2,1f))
    compact.addView(ImageView(this).apply{
     ripple(this)
     setImageResource(R.drawable.ic_trash);setPadding(dp(10),dp(5),dp(10),dp(5))
     contentDescription="Excluir pacote $n pulado"
     setOnClickListener{
      AlertDialog.Builder(this@SavedAddressesActivity).setTitle("Excluir pacote $n pulado?")
       .setNegativeButton("CANCELAR",null).setPositiveButton("CONFIRMAR"){_,_->
        Store.removeSkipped(this@SavedAddressesActivity,n);render()
       }.show()
     }
    },LinearLayout.LayoutParams(dp(48),dp(40)))
    list.addView(compact,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(12)})
    shown++
    continue
   }
   val address=group.address
   if(!matches(group.numbers,address,query))continue
   shown++
   val card = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(12))
    background = android.graphics.drawable.GradientDrawable().apply {
     setColor(0xFFF2F5FA.toInt()); cornerRadius = dp(14).toFloat()
     setStroke(dp(1),0xFFD8DFE9.toInt())
    }
   }
   val topRow=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
   val titleContainer=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
   titleContainer.addView(TextView(this).apply{
    text="PACOTE";textSize=20f;setTextColor(0xFF162C4C.toInt())
   })
   val numbersLabel=TextView(this).apply{
    text=group.numbers.sorted().joinToString("-");textSize=20f
    if(group.numbers.size>=2){
     setTextColor(0xFFFFE500.toInt());setPadding(dp(7),dp(3),dp(7),dp(3))
     background=GradientDrawable().apply{setColor(Color.BLACK);cornerRadius=dp(5).toFloat()}
    }else setTextColor(0xFF162C4C.toInt())
   }
   titleContainer.addView(numbersLabel,LinearLayout.LayoutParams(-2,-2).apply{leftMargin=dp(7)})
   topRow.addView(titleContainer,LinearLayout.LayoutParams(0,-2,1f))
   topRow.addView(ImageView(this).apply {ripple(this);setImageResource(R.drawable.ic_trash);setPadding(dp(10),dp(5),dp(10),dp(5));contentDescription="Excluir ${group.title}";setOnClickListener {
    AlertDialog.Builder(this@SavedAddressesActivity).setTitle("Excluir ${group.title}?")
     .setMessage(if(group.numbers.size>1)"Serão excluídos os pacotes ${group.numbers.joinToString("-")} deste endereço. Deseja continuar?" else "Somente este endereço será apagado. Deseja continuar?")
     .setNegativeButton("CANCELAR",null).setPositiveButton("CONFIRMAR") {_,_->
      if(!Store.removeGroup(this@SavedAddressesActivity,group.numbers))Toast.makeText(this@SavedAddressesActivity,"A lista mudou. Confira os pacotes e tente novamente.",Toast.LENGTH_LONG).show()
      render()
     }.show()
   }}, LinearLayout.LayoutParams(dp(48),dp(40)))
   card.addView(topRow)
   card.addView(TextView(this).apply { text = address; textSize = 17f; setTextColor(0xFF333333.toInt()); setPadding(0,dp(10),0,dp(8)) })
   card.addView(Button(this).apply { text = "EDITAR";ripple(this); setOnClickListener { editGroup(group.numbers) } })
   list.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = dp(12) })
  }
  if(shown==0)list.addView(TextView(this).apply{text="Nenhum endereço encontrado";textSize=17f;setPadding(dp(5),dp(14),dp(5),dp(10))})
 }
 private fun shareRouteWithSpoke(){
  val csv=try{RouteCsv.export(Store.all(this))}catch(e:Exception){
   Toast.makeText(this,"Não foi possível preparar a rota: ${e.message}",Toast.LENGTH_LONG).show();return
  }
  if(csv=="Address,Notes\r\n"){
   Toast.makeText(this,"Nenhum endereço disponível para exportar",Toast.LENGTH_SHORT).show();return
  }
  try{
   val dir=File(cacheDir,"spoke_exports").apply{mkdirs()}
   val file=File(dir,"ROTA_PARA_SPOKE.csv")
   file.writeText("\uFEFF"+csv,Charsets.UTF_8)
   val uri=FileProvider.getUriForFile(this,"${packageName}.updates",file)
   val send=Intent(Intent.ACTION_SEND).apply{
    type="text/csv";putExtra(Intent.EXTRA_STREAM,uri)
    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    clipData=android.content.ClipData.newUri(contentResolver,"Rota para Spoke",uri)
   }
   SpokeShare.open(send){startActivity(it)}
  }catch(e:Exception){
   Toast.makeText(this,"Não foi possível compartilhar o CSV: ${e.message}",Toast.LENGTH_LONG).show()
  }
 }
 private fun editGroup(numbers:List<Int>){
  // Hidden members remain editable individually; changing one address splits its card naturally.
  fun open(number:Int){
   val current=Store.all(this)
   val index=(0 until current.length()).firstOrNull {current.optJSONObject(it)?.optInt("number",0)==number}
   if(index==null){render();return}
   editItem(index,number,current.getJSONObject(index).optString("address"))
  }
  if(numbers.size==1){open(numbers.first());return}
  AlertDialog.Builder(this).setTitle("Editar qual pacote?")
   .setItems(numbers.map {"PACOTE $it"}.toTypedArray()){_,which->open(numbers[which])}
   .setNegativeButton("CANCELAR",null).show()
 }
 private fun editItem(index: Int, number: Int, address: String) {
  val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),dp(10),dp(20),0) }
  val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
  row.addView(TextView(this).apply { text = "Pacote  "; textSize = 18f })
  val numberInput = EditText(this).apply { setText(number.toString()); inputType = InputType.TYPE_CLASS_NUMBER; selectAll() }
  row.addView(numberInput,LinearLayout.LayoutParams(0,-2,1f)); panel.addView(row)
  panel.addView(TextView(this).apply { text = "⌕ Buscar endereço"; textSize = 16f })
  val addressInput = EditText(this).apply { setText(address); minLines = 2; maxLines = 5; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
  panel.addView(addressInput)
  val suggestions=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  val status=TextView(this).apply{text="Digite parte da rua ou nome do local e escolha uma sugestão";textSize=12f}
  val map=android.webkit.WebView(this)
  panel.addView(status);panel.addView(suggestions);panel.addView(map,LinearLayout.LayoutParams(-1,dp(180)))
  val assistant=MapAssistant(this,map,status)
  val searchHandler=android.os.Handler(android.os.Looper.getMainLooper())
  var pending:Runnable?=null
  var selected:MapAssistant.Hit?=null
  assistant.onPointChanged={selected=it}
  var applying=false
  val dialog = AlertDialog.Builder(this).setTitle("Editar encomenda").setView(panel)
   .setNegativeButton("CANCELAR",null).setPositiveButton("CONFIRMAR",null).create()
  addressInput.addTextChangedListener(object:TextWatcher{
   override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
   override fun afterTextChanged(s:Editable?){}
   override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){
    if(applying)return
    selected=null;assistant.cancelLookup();suggestions.removeAllViews()
    dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled=false
    pending?.let{searchHandler.removeCallbacks(it)}
    val query=addressInput.text.toString().let{if(it.contains("Boa Vista",true))it else "$it, Boa Vista, RR"}
    pending=Runnable{assistant.lookup(query,true){hits->
     suggestions.removeAllViews()
     for(hit in hits){
      val option=TextView(this@SavedAddressesActivity).apply{text=hit.label;textSize=14f;setPadding(dp(8),dp(10),dp(8),dp(10))}
      option.setOnClickListener{
       applying=true;selected=hit
       addressInput.setText(listOf(hit.streetLine,hit.location).filter{it.isNotBlank()}.joinToString(", "))
       applying=false;suggestions.removeAllViews();assistant.choose(hit,refine=true)
       dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled=true
      };suggestions.addView(option)
     }
    }};searchHandler.postDelayed(pending!!,350)
   }
  })
  dialog.setOnDismissListener{pending?.let{searchHandler.removeCallbacks(it)};assistant.release()}
  dialog.setOnShowListener {
   dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled=false
   dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
    val newNumber = numberInput.text.toString().toIntOrNull()
    val newAddress = addressInput.text.toString().trim()
    if (selected==null || newNumber == null || newNumber < 1 || newAddress.length < 5) {
     Toast.makeText(this,"Informe número válido e endereço completo",Toast.LENGTH_LONG).show(); return@setOnClickListener
    }
    val point=assistant.confirmedPoint
    if (!Store.edit(this,index,newNumber,newAddress,point?.lat ?: Double.NaN,point?.lon ?: Double.NaN,point?.precision.orEmpty())) {
     Toast.makeText(this,"Número ou endereço já usado por outro pacote",Toast.LENGTH_LONG).show(); return@setOnClickListener
    }
    dialog.dismiss(); render()
   }
  }
  dialog.show()
 }
}
