import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';
import {streetFeatures} from '../dist/street-catalogue.js';
import {localSuggestions,searchSuggestions,matches,attachAutocomplete,verifiedPoint} from '../dist/mini-map.js';

test('Captura real de ruas: os três fragmentos curtos funcionam sem rede e não inventam precisão de casa',async()=>{
 const window={fetch:()=>{throw Error('offline');}};
 for(const [q,street] of [['160 das',/Rua das Três Marias/],['1600 gl',/Avenida Glaycon de Paiva/],['56 o',/Rua Pastor Osman da Rocha Briglia/]]){
  const hits=await searchSuggestions(window,q+', Boa Vista, RR');
  const target=hits.find(h=>street.test(h.streetLine));assert.ok(target,'Sem rua para '+q);
  assert.ok(target.postcode);assert.equal(target.exact,false);assert.equal(verifiedPoint(target),null);
  assert.match(target.streetLine,new RegExp(q.split(' ')[0]));
  assert.equal(new Set(hits.map(h=>h.streetLine)).size,hits.length);
 }
 assert.equal(matches('Rua Cisne','das'),false);assert.equal(matches('Rua Vega','gl'),false);
 assert.deepEqual(localSuggestions('56 o, São Paulo, SP'),[]);
});

test('Catálogo público idêntico nas plataformas, sem número de casa e com coordenadas válidas',async()=>{
 const native=JSON.parse(await readFile(new URL('../../app/src/main/assets/boa-vista-streets.json',import.meta.url)));
 assert.deepEqual(native,streetFeatures);assert.ok(native.length>300);
 for(const f of native){assert.equal(f.properties.city,'Boa Vista');assert.ok(!f.properties.housenumber);const [lon,lat]=f.geometry.coordinates;assert.ok(lat>=2.4&&lat<=3.25&&lon>=-61.2&&lon<=-60.15);}
});

test('Número seguido de uma letra inicia autocomplete; resposta antiga não substitui a atual',async()=>{
 const dom=new JSDOM('<input id=q><input id=loc value="Boa Vista, RR"><div id=list></div><p id=status></p>');
 const w=dom.window,input=w.document.querySelector('#q'),list=w.document.querySelector('#list'),status=w.document.querySelector('#status');
 let called=0;
 const attached=attachAutocomplete(w,input,w.document.querySelector('#loc'),list,status,{search:async(win,text)=>{called++;return localSuggestions(text);}});
 input.value='56 o';input.dispatchEvent(new w.Event('input'));
 await new Promise(r=>setTimeout(r,300));assert.equal(called,1);assert.ok(list.children.length>0);
 input.value='';input.dispatchEvent(new w.Event('input'));assert.equal(list.children.length,0);
 attached.destroy();w.close();
});
