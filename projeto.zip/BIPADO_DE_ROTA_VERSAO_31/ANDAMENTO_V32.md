# Versão 32 — desenvolvimento parcial, NÃO PRONTA PARA USO

Alterações iniciais no Android:
- Store.saveWhatsappForLast: vinculação de número ao último pacote, com bloqueio de duplicação.
- RouteCsv: números de WhatsApp em Notes (WA<número do pacote>=<telefone>) e leitura de volta.
- SavedAddressesActivity: botão provisório no cartão para abrir conversa com mensagem preenchida.

PENDENTE: cadeado e senha; botão flutuante conjunto; captura OCR específica do WhatsApp; ícone visual definitivo; adaptação da importação no iOS; compilação e testes reais no Android/iOS e interoperabilidade Spoke.

Não instalar/publicar como versão final. A exportação CSV alterada precisa ser validada com o Spoke.
