import br.com.leitorencomendas.GeoAddress as G
fun main(){
 val q=G.query("Alameda das Acácias, 587, Casa de Esquina — Pricumã, Boa Vista, RR, 69309-360")
 check(q.street=="Alameda das Acácias");check(q.number=="587");check(q.district=="Pricumã");check(q.postcode=="69309-360")
 check(!q.full.contains("Esquina"))
 check(G.query("578 veg, Boa Vista, RR").let{it.number=="578"&&it.street=="veg"})
 check(G.query("89 ba, Boa Vista, RR").let{it.number=="89"&&it.street=="ba"})
 check(G.streetScore("Rua João Batista","ba")==100)
 check(G.streetScore("Alameda das Acacias","Alameda das Acácias")==100)
 check(G.streetScore("Rua das Palmeiras","Alameda das Acácias")==0)
 check(G.inRegion(2.815698,-60.701482));check(!G.inRegion(-23.5,-46.6));check(!G.inRegion(Double.NaN,-60.7))
 check(G.exactNumber("587","587"));check(!G.exactNumber("587",""));check(!G.exactNumber("587","589"))
 check(G.query("Rua 13 de Maio, 402, Casa, Boa Vista RR").let{it.street=="Rua 13 de Maio"&&it.number=="402"})
 check(G.query("Alameda dos Bambu Salón de Beleza, 1433, Casa").street=="Alameda dos Bambu")
 for(q in listOf("46 dos b","46 dos bam")){
  val parsed=G.query(q);check(parsed.number=="46")
  check(G.suggestionScore("Alameda dos Bambus",parsed.street)==100)
  check(G.suggestionScore("Travessa dos Bambus",parsed.street)==100)
  check(G.suggestionScore("Rua Cisne",parsed.street)==0)
 }
 for(q in listOf("1003 via","1093 via")){
  val parsed=G.query(q);check(parsed.street=="via")
  check(G.suggestionScore("Via das Flores",parsed.street)==100)
  check(G.suggestionScore("Rua Vega",parsed.street)==0)
  check(G.suggestionText(parsed)=="via")
 }
 check(G.suggestionScore("Rua A","a")==100)
 check(G.suggestionScore("Rua João Batista","jo ba")==100)
 check(G.suggestionScore("Rua João Batista","jo cis")==0)
 check(G.suggestionScore("Supermercado Goiana Cidade Satélite","goiana sat")==100)
 check(G.suggestionScore("Via das Flores","av")==0)
 check(G.suggestionScore("Avenida Brasil","av")==100)
 check(G.query("28Ve").let{it.street=="Ve"&&it.number=="28"})
 check(G.query("Rua 13 de Maio").let{it.street=="Rua 13 de Maio"&&it.number.isBlank()})
 for((raw,street) in listOf("160 das" to "Rua das Três Marias","1600 gl" to "Avenida Glaycon de Paiva","56 o" to "Rua Osman da Rocha Bríglia")){
  val parsed=G.query(raw);check(G.suggestionScore(street,parsed.street)==100)
 }
 check(G.suggestionScore("Rua Cisne","das")==0)
 check(G.suggestionScore("Rua Vega","gl")==0)
 println("Geocoding query/precision regression passed (offline fixtures, not live coverage)")
}
