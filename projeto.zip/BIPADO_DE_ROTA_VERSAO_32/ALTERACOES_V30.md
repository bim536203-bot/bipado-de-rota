# Versão 30 — design Android e adaptação iOS

## Android recebido
Arte verde EXPORTAR PARA ROTA SPOKE preservada, com três ícones acima e frase abaixo, FIT_CENTER e altura86dp. Mantidos cabeçalho de ícones azuis fixo, rolagem conjunta do botão e cartões, vibração70ms, ripple e envio CSV direto ao Spoke com seletor alternativo.

O ZIP recebido estava identificado internamente como28/code83. Identificações corrigidas para30/code85 e raiz30. Corrigida chamada Kotlin fillViewport=true para setFillViewport(true), a mesma correção de compilação já necessária na29. Nenhuma outra alteração funcional Android.

## iPhone / PWA
- Tela Endereços salvos branca, sem título ou texto VOLTAR, com os três ícones azuis e busca fixos. Somente botão e cartões rolam.
- Usa exatamente o mesmo PNG Android do botão EXPORTAR PARA ROTA SPOKE, inteiro, com proporção preservada em86px.
- Grupos exibem PACOTE e números amarelos em etiqueta preta; pacote único conserva o estilo normal. Pacotes pulados são cartões neutros com exclusão individual confirmada. Ordem decrescente pelo número principal igual ao Android, sem mudar o CSV.
- Exportação no toque gera ROTA_PARA_SPOKE.csv UTF8 com BOM, Address/Notes, números reais e grupos preservados. Web Share é chamado no gesto se arquivos forem compatíveis; download funciona como alternativa. Cancelar o compartilhamento não dispara download. Erro de compartilhamento oferece salvar arquivo.
- Busca manual com lupa/X, lista e CEP recebido da base: selecionar destaca, tocar fora ou digitar desmarca; SALVAR aparece somente com seleção; SALVAR abre confirmação com mapa; somente CONFIRMAR grava pacote. Pino aproximado continua identificado, ajuste manual e coordenadas verificadas preservados. CEP ausente nunca inventado.
- Editor de encomenda mantém número, endereço, sugestões, mapa e confirmação; seleção fica no editor e habilita CONFIRMAR. Histórico tem cabeçalho fixo, lista rolável, restauração e exclusão confirmadas. Importação recebe confirmação verde temporária sem OK. Menu e tela inicial preservam o padrão Android com entrada manual no lugar de bipar.
- Ripple rápido no ponto do toque em botões e ícones, inclusive controles dinâmicos; respeita movimento reduzido. Área segura do iPhone e altura do teclado tratadas na busca. Recursos novos entram no cache offline; atualização preserva IndexedDB.

## Limites e validação
O iPhone usa PWA, não APK. Web Share apresenta o seletor do sistema e não permite escolher o aplicativo destinatário por código; não prometer abertura automática do Spoke no iOS. Vibração só é solicitada quando navigator.vibrate está disponível; não prometer vibração no Safari. Fontes, teclados, seletores de arquivo e diálogos do sistema variam por plataforma. Não afirmar equivalência100% pixel a pixel nem teste Safari físico sem aparelho.

Fontes primárias: https://www.w3.org/TR/web-share/ e https://webkit.org/blog/13862/the-user-activation-api/ . Captura de outras telas/ícone flutuante Android não é simulada no iPhone.

Testes: regressões de importação, edição, pesquisa, grupos, exclusão/restauração, dados e CSV; novas verificações DOM do layout/ordem, cartão pulado, compartilhar/cancelar/fallback, payload BOM, seleção/desmarcação/SALVAR/CONFIRMAR e ripple. Compilação/lint/assinatura Android e suíte online existentes são executadas pelo publicador. Verificação visual no navegador após publicação; testes no iPhone/MotoG8 físicos continuam necessários.
