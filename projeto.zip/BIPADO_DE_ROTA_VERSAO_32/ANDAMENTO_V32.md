# Versão 32 — implementação concluída, validação em andamento

Cadeado Android no canto inferior esquerdo, senha numérica já combinada, desbloqueio local persistente e possibilidade de bloquear novamente. Não existe cadeado no iOS.
WhatsApp flutuante abaixo do bipe, arraste conjunto; reaproveita MediaProjection/ML Kit sem segunda autorização de tela. Captura telefone brasileiro, escolhe se houver mais de um candidato e mantém a tela do outro aplicativo.
Vínculo por token ao último pacote confirmado pelo bipador, sem usar o maior número/importação. Pacote alterado/deletado/rota substituída invalida captura atrasada. Não sobrescreve WhatsApp salvo.
Ícone verde nos cartões com telefone, Android/iOS; grupos com contatos diferentes oferecem escolha. Abre conversa com mensagem acordada preenchida, envio manual.
CSV Address/Notes preserva ordem/agrupamento; WhatsApp por pacote via WA<id>=<telefone>. Parser valida telefone, vínculo e repetição. iOS importa, mantém em banco/histórico e exporta novamente sem nuvem. CSV antigo permanece compatível.
Nenhuma conversa foi aberta ou mensagem enviada durante os testes. Compilação e testes automatizados devem passar antes de publicar; captura em tela real Android e interoperabilidade com Spoke ainda exigem validação no celular.
