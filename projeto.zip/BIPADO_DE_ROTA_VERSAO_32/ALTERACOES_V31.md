# VERSÃO 31 — sugestões por fragmentos curtos

Base: Versão 30 preservada no histórico GitHub e ZIP anterior.

- Android e iPhone aceitam número seguido de uma letra e conectivos isolados (das/dos).
- Catálogo local PARCIAL com 497 registros públicos de ruas de Boa Vista, mesmos dados nas duas plataformas. Respostas curtas cobertas não aguardam rede. Consultas mais completas combinam a base com o serviço online; indisponibilidade remota preserva resultados locais.
- Trechos com CEPs distintos são preservados. Até 50 sugestões distintas roláveis, evitando cortar alternativas úteis nas cinco primeiras; novas letras refinam a lista. Debounce de digitação 200ms, cancelamento e proteção contra respostas antigas preservados.
- Casos reais: 160 das → Rua das Três Marias (há dois CEPs por trecho); 1600 gl → Avenida Glaycon de Paiva; 56 o → Rua Pastor Osman da Rocha Briglia, nome presente na fonte.
- CEP somente quando informado pela base. Número digitado aparece no texto, mas ponto de rua continua aproximado. Selecionar → SALVAR → mapa → CONFIRMAR preservado. Consulta exata após seleção e ajuste manual do pino mantidos.
- Desmarcar endereço no iPhone também limpa a mensagem de seleção anterior.
- CSV, números/ordem de pacotes, compartilhamento Spoke, design e banco de dados preservados.

Limitações: catálogo parcial; cobertura, nomes, CEPs e coordenadas podem diferir do Spoke e envelhecer. Não há garantia de igualdade nem de posição exata de todas as casas. Testes automatizados usam dados reais capturados e DOM simulado. Validação física Android/iPhone permanece necessária.
Licença e procedência: STREET_DATA.md.
