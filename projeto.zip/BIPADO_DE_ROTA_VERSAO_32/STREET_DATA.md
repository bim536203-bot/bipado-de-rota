# Catálogo local de ruas — versão 31

Dados públicos © OpenStreetMap contributors, obtidos pelo Photon em 19/10/2026.
Fonte: https://photon.komoot.io/ ; https://www.openstreetmap.org/copyright
Licença: Open Database License (ODbL) 1.0, https://opendatacommons.org/licenses/odbl/1-0/

Este é um índice PARCIAL de ruas de Boa Vista, não um cadastro completo de imóveis.
Coleta: consultas genéricas pelos tipos de via e letras a–z, uma por vez com pausa
mínima de 1,1 segundo, e respostas reais dos casos de regressão. Sem GPS do usuário.
Identificadores OSM e CEP retornados pela fonte são preservados quando disponíveis.
Números digitados são mantidos no texto, nunca considerados prova da coordenada.
Nenhuma casa, CEP ausente, bairro ou coordenada foi inventado.
Android e iOS usam os mesmos registros. O serviço online continua complementar e
refina o número após seleção. A cobertura local pode envelhecer ou não incluir uma rua.

Registros nesta captura: 497.
