import br.com.leitorencomendas.RouteCsv
import org.json.JSONArray
import org.json.JSONObject
fun main(args:Array<String>){
 val rows=JSONArray()
 for(n in listOf(1,2,7))rows.put(JSONObject().put("number",n).put("address","Rua das Campainhas, 111, Casa Verde, Pricumã, Boa Vista, RR, 69309-470, Brasil"))
 rows.put(JSONObject().put("number",5).put("address","Rua dos Ipês, 221, casa \"Azul\", Boa Vista, RR"))
 rows.put(JSONObject().put("number",8).put("address","PACOTE 8 PULADO").put("skipped",true))
 java.io.File(args[0]).writeText(RouteCsv.export(rows))
 if(args.size>1){
  val phones=JSONArray().put(JSONObject().put("number",1).put("address","Rua Exemplo, 28, Boa Vista, RR").put("whatsapp","5595999991234")).put(JSONObject().put("number",7).put("address","Rua Exemplo, 28, Boa Vista, RR").put("whatsapp","5511988881234"))
  java.io.File(args[1]).writeText(RouteCsv.export(phones))
 }
}
