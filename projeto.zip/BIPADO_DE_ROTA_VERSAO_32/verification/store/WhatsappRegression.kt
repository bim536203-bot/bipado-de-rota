import android.content.Context
import br.com.leitorencomendas.*
import org.json.JSONArray
import org.json.JSONObject
fun main(){
 check(WhatsappPolicy.normalize("+55 (95) 99999-1234")=="5595999991234")
 check(WhatsappPolicy.normalize("(95) 99999-1234")=="5595999991234")
 check(WhatsappPolicy.normalize("69309-470")==null)
 check(WhatsappPolicy.normalize("5500999991234")==null)
 check(WhatsappPolicy.extract("CPF 95999991234\nCódigo 95999991234\nCEP 69309-470").isEmpty())
 check(WhatsappPolicy.extract("WhatsApp +55 (95) 99999-1234\nTelefone (11) 98888-1234").size==2)
 check(WhatsappPolicy.extract("+55 (95) 99999-1234\n+55 (95) 99999-1234").size==1)
 check(WhatsappPolicy.extract("Rastreio BR12345678901\n69309-470").isEmpty())
 check(WhatsappPolicy.acceptsPin(charArrayOf('1','9','9','9').concatToString()))
 check(!WhatsappPolicy.acceptsPin("0000"));check(!WhatsappPolicy.acceptsPin("1999 "))
 val c=Context();val a="Rua Exemplo, 28, Boa Vista, RR";val b="Rua Outra, 29, Boa Vista, RR"
 check(Store.add(c,a,1));check(Store.whatsappTarget(c)==null)
 check(Store.add(c,b,2,bipped=true));val token=Store.whatsappTarget(c)!!.getString("captureToken")
 check(Store.skipNext(c,3));check(Store.whatsappTarget(c)!!.getInt("number")==2)
 check(Store.edit(c,1,5,b));check(Store.whatsappTarget(c)!!.getInt("number")==5)
 check(Store.saveWhatsappForLast(c,"+55 (95) 99999-1234",token).startsWith("WhatsApp salvo"))
 check(Store.saveWhatsappForLast(c,"5511988881234",token)=="Whatsapp já foi salvo!!")
 check(Store.all(c).getJSONObject(1).getString("whatsapp")=="5595999991234")
 check(Store.add(c,"Rua Nova, 50, Boa Vista, RR",6,bipped=true))
 check(Store.saveWhatsappForLast(c,"5511988881234",token).contains("pacote mudou"))
 check(!Store.all(c).getJSONObject(2).has("whatsapp"))
 val csv=RouteCsv.export(Store.all(c));val back=RouteCsv.parse(csv)
 check(back.getJSONObject(1).getString("whatsapp")=="5595999991234")
 check(Store.replaceWithImport(c,back));check(Store.whatsappTarget(c)==null)
 val rows=JSONArray().put(JSONObject().put("number",1).put("address",a).put("whatsapp","5595999991234")).put(JSONObject().put("number",7).put("address",a).put("whatsapp","5511988881234"))
 val exported=RouteCsv.export(rows);check(exported.contains("PACOTE 1-7; WA1=5595999991234; WA7=5511988881234"))
 check(RouteCsv.parse(exported).getJSONObject(1).getString("whatsapp")=="5511988881234")
 for(note in listOf("PACOTE 1; WA2=5595999991234","PACOTE 1; WA1=5595999991234; WA1=5511988881234","PACOTE 1; WA99999999999999=5595999991234","PACOTE 1; WA1=5500999991234")){
  check(runCatching{RouteCsv.parse("Address,Notes\n\"$a\",\"$note\"\n")}.isFailure)
 }
 check(Store.clear(c));check(Store.whatsappTarget(c)==null)
 println("WhatsApp: normalization/OCR candidates, numeric gate, capture target/races, no overwrite and grouped CSV roundtrip passed (JVM boundary, not device OCR).")
}
