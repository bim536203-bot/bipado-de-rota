import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {JSDOM} from 'jsdom';
import * as C from '../dist/core.js';import {createApp} from '../dist/app.js';
const a='Rua Exemplo, 28, Boa Vista, RR';
const phones=[{number:1,address:a,whatsapp:'5595999991234'},{number:7,address:a,whatsapp:'5511988881234'}];
test('CSV Android/WhatsApp importa os telefones por pacote, conserva no banco/histórico e exporta de volta',async()=>{
 const csv=await readFile(new URL('./fixtures/android-whatsapp-export.csv',import.meta.url),'utf8');const items=C.parseCsv(csv);
 assert.equal(items[0].whatsapp,phones[0].whatsapp);assert.equal(items[1].number,7);assert.equal(items[1].whatsapp,phones[1].whatsapp);
 let s=C.importRoute(C.freshState(),items);s=C.validateState(s);assert.equal(s.items[1].whatsapp,phones[1].whatsapp);
 const exported=C.exportCsv(s.items);assert.equal(exported,csv);s=C.clearRoute(s,10000);assert.equal(s.history[0].items[0].whatsapp,phones[0].whatsapp);
 s=C.restoreRoute(s,s.history[0].id,10001);assert.equal(s.items[1].whatsapp,phones[1].whatsapp);
 for(const note of ['PACOTE 1; WA2=5595999991234','PACOTE 1; WA1=5595999991234; WA1=5511988881234','PACOTE 1; WA1=5500999991234'])assert.throws(()=>C.parseCsv(`Address,Notes\n"${a}","${note}"\n`));
 assert.throws(()=>C.validateItems([{number:1,address:a,whatsapp:'javascript:alert(1)'}]));
});
test('iPhone só mostra WhatsApp com telefone, oferece pacote no grupo e preenche mensagem sem envio automático',async()=>{
 const dom=new JSDOM(await readFile(new URL('../dist/index.html',import.meta.url),'utf8'),{url:'https://example.test/#addresses'}),w=dom.window,d=w.document;
 w.scrollTo=()=>{};w.matchMedia=()=>({matches:false});w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open')};
 let state=C.importRoute(C.freshState(),[...phones,{number:3,address:'Rua Sem telefone, 99, Boa Vista, RR'}]),opened=[];
 const app=createApp(w,{readState:async()=>state,commitState:async(rev,fn)=>state=fn(state)},{openWhatsapp:url=>opened.push(url),sounds:{unlock(){},play(){}}});await app.ready;
 assert.equal(d.querySelectorAll('.whatsapp-button').length,1);assert.equal(d.querySelectorAll('[aria-label*=cadeado]').length,0);
 d.querySelector('.whatsapp-button').click();assert.equal(opened.length,0);
 [...d.querySelectorAll('.choice-button')].find(b=>b.textContent.startsWith('PACOTE 7')).click();assert.equal(opened.length,1);
 const url=new URL(opened[0]);assert.equal(url.pathname,'/5511988881234');assert.equal(url.searchParams.get('text'),C.WHATSAPP_MESSAGE);assert.ok(!url.searchParams.has('send'));
 w.close();
});
