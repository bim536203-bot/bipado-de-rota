package br.com.leitorencomendas

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Future
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** Photon autocomplete and Geoapify capture lookup run independently of OCR. */
class MapAssistant(context:Context,private val web:WebView?,private val status:TextView){
 data class Hit(val label:String,val lat:Double,val lon:Double,val score:Int=0,val exact:Boolean=false,val source:String="",val streetLine:String=label,val location:String="",val place:Boolean=false,val title:String=streetLine,val details:String=location,val postcode:String="",val manual:Boolean=false){val precision:String get()=if(manual)"manual" else if(exact)"house" else if(place)"place" else "approximate";val usable:Boolean get()=precision!="approximate"}
 var onPointChanged:((Hit)->Unit)?=null
 val confirmedPoint:Hit? get()=pending?.takeIf{it.usable}
 private val refined=mutableSetOf<String>()
 private val app=context.applicationContext
 private val main=Handler(Looper.getMainLooper())
 private val executor=ThreadPoolExecutor(1,1,0L,TimeUnit.MILLISECONDS,LinkedBlockingQueue<Runnable>())
 private val generation=AtomicInteger()
 @Volatile private var connection:HttpURLConnection?=null
 private var job:Future<*>?=null
 @Volatile private var closed=false
 private var ready=false
 private var addressMissing=false
 private var pending:Hit?=null
 private var message="Procurando endereço…"
 private var lastQuery=""
 private val prefs=app.getSharedPreferences("geoapify_cache_v4",Context.MODE_PRIVATE)
 companion object {
  private data class Entry(val at:Long,val hits:List<Hit>)
  private val cache=object:LinkedHashMap<String,Entry>(160,.75f,true){override fun removeEldestEntry(eldest:MutableMap.MutableEntry<String,Entry>)=size>160}
  private var lastPhotonRequest=0L
  private const val TTL=7L*24*60*60*1000
 }
 init{
  web?.apply{
   setBackgroundColor(Color.rgb(241,245,249));settings.javaScriptEnabled=true
   settings.allowFileAccess=true;settings.allowContentAccess=false
   addJavascriptInterface(PointBridge(),"BipadoPoint")
   webViewClient=object:WebViewClient(){
    override fun shouldOverrideUrlLoading(view:WebView?,request:WebResourceRequest?):Boolean=true
    override fun onPageFinished(view:WebView?,url:String?){
    if(closed)return
    ready=true
    if(addressMissing)web?.evaluateJavascript("window.setMissingAddress(true);",null)
    else pending?.let{show(it)} ?: setStatus(message)
   }}
   loadUrl("file:///android_asset/mapa.html")
  }
 }

 private inner class PointBridge{
  @JavascriptInterface fun moved(lat:Double,lon:Double,token:Int){
   main.post{
    if(closed || token!=generation.get() || !GeoAddress.inRegion(lat,lon))return@post
    val old=pending ?: return@post
    generation.incrementAndGet();job?.cancel(true);connection?.disconnect()
    val adjusted=old.copy(lat=lat,lon=lon,exact=false,place=false,manual=true)
    remember("address:"+AddressIdentity.normalize(GeoAddress.query("${old.streetLine}, ${old.location}").full),listOf(adjusted),true)
    show(adjusted)
   }
  }
 }
 private fun setStatus(text:String){
  if(closed)return
  message=text;status.text=text
  if(ready)web?.evaluateJavascript("window.setMapStatus(${JSONObject.quote(text)});",null)
 }
 private fun show(hit:Hit){
  if(closed)return
  pending=hit
  onPointChanged?.invoke(hit)
  message=if(hit.manual)"Pino ajustado por você • confira o local" else if(hit.exact)"Número localizado na base • confira o ponto" else if(hit.place)"Local selecionado na base • confira o ponto" else "Casa não localizada • ponto aproximado da rua. Toque no mapa ou arraste o pino até a casa."
  status.text=message
  if(ready)web?.evaluateJavascript("window.placePin(${hit.lat},${hit.lon},${JSONObject.quote(hit.label)},${hit.exact},${JSONObject.quote(hit.source)},${hit.usable},${generation.get()});",null)
 }
 /** Display an unread parcel without searching the placeholder text or inventing a pin. */
 fun showMissingAddress(){
  if(closed)return
  generation.incrementAndGet();job?.cancel(true);connection?.disconnect();executor.purge()
  addressMissing=true;pending=null;message="";status.text=""
  if(ready)web?.evaluateJavascript("window.setMissingAddress(true);",null)
 }
 private fun cached(key:String):List<Hit>? {
  synchronized(cache){cache[key]?.takeIf{System.currentTimeMillis()-it.at<TTL}?.let{return it.hits}}
  return try{
   val saved=JSONObject(prefs.getString(key,"")!!)
   val at=saved.getLong("at")
   if(System.currentTimeMillis()-at !in 0 until TTL)return null
   val a=saved.getJSONArray("hits")
   val list=(0 until a.length()).map{val h=a.getJSONObject(it);Hit(h.getString("label"),h.getDouble("lat"),h.getDouble("lon"),h.getInt("score"),h.optBoolean("exact"),h.optString("source"),h.optString("streetLine",h.getString("label")),h.optString("location"),h.optBoolean("place"),h.optString("title",h.optString("streetLine",h.getString("label"))),h.optString("details",h.optString("location")),h.optString("postcode"),h.optBoolean("manual"))}
   synchronized(cache){cache[key]=Entry(at,list)};list
  }catch(_:Exception){null}
 }
 private fun remember(key:String,hits:List<Hit>,persist:Boolean){
  if(hits.isEmpty())return
  val at=System.currentTimeMillis();synchronized(cache){cache[key]=Entry(at,hits)}
  if(persist){
   val a=JSONArray();hits.forEach{a.put(JSONObject().put("label",it.label).put("lat",it.lat).put("lon",it.lon).put("score",it.score).put("exact",it.exact).put("source",it.source).put("streetLine",it.streetLine).put("location",it.location).put("place",it.place).put("title",it.title).put("details",it.details).put("postcode",it.postcode).put("manual",it.manual))}
   val editor=prefs.edit();val keys=prefs.all.keys
   if(keys.size>=150)keys.firstOrNull()?.let{editor.remove(it)}
   editor.putString(key,JSONObject().put("at",at).put("hits",a).toString()).apply()
  }
 }
 private val catalogue by lazy {
  try{JSONArray(app.assets.open("boa-vista-streets.json").bufferedReader().use{it.readText()})}catch(_:Exception){JSONArray()}
 }
 private fun localSuggestions(q:GeoAddress.Query):List<Hit>{
  val hits=mutableListOf<Hit>()
  for(i in 0 until catalogue.length()){
   val f=catalogue.getJSONObject(i);val p=f.getJSONObject("properties");val c=f.getJSONObject("geometry").getJSONArray("coordinates")
   val street=p.optString("street").ifBlank{p.optString("name")}
   if(GeoAddress.suggestionScore(street,q.street)<100)continue
   val lat=c.optDouble(1);val lon=c.optDouble(0);if(!GeoAddress.inRegion(lat,lon))continue
   val district=p.optString("district").ifBlank{p.optString("suburb")};val postcode=p.optString("postcode")
   val title=listOf(street,q.number).filter{it.isNotBlank()}.joinToString(", ")
   val line=listOf(title,district).filter{it.isNotBlank()}.joinToString(", ")
   val location=listOf("Boa Vista","RR",postcode).filter{it.isNotBlank()}.joinToString(", ")
   val details=listOf(district,location,if(postcode.isBlank())"CEP não informado pela base" else "").filter{it.isNotBlank()}.joinToString(" — ")
   hits.add(Hit("$line — $location",lat,lon,if(q.district.isNotBlank()&&district.equals(q.district,true))110 else 100,false,"OpenStreetMap / Photon — catálogo local",line,location,false,title,details,postcode))
  }
  return hits.sortedByDescending{it.score}.distinctBy{AddressIdentity.normalize(it.streetLine+"|"+it.postcode)}.take(50)
 }
 private fun fetch(text:String,q:GeoAddress.Query,suggestions:Boolean,id:Int,deadline:Long,geoAutocomplete:Boolean=false):List<Hit>{
  val photon=suggestions && !geoAutocomplete
  if(closed || id!=generation.get())return emptyList()
  if(suggestions){
   val wait=synchronized(cache){(900-(SystemClock.elapsedRealtime()-lastPhotonRequest)).coerceAtLeast(0)}
   if(wait>0)Thread.sleep(wait)
   if(closed || id!=generation.get())return emptyList()
   synchronized(cache){lastPhotonRequest=SystemClock.elapsedRealtime()}
  }
  val remaining=(deadline-SystemClock.elapsedRealtime()).toInt()
  if(remaining<300)throw java.net.SocketTimeoutException()
  val path=if(geoAutocomplete)"autocomplete" else "search"
  fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
  val url=if(photon)"https://photon.komoot.io/api/?q="+enc(text)+(if(q.number.isNotBlank())"&layer=street&layer=house" else "")+"&limit=50&countrycode=BR&bbox=-61.2,2.4,-60.15,3.25&lat=2.8235&lon=-60.6758"
   else "https://api.geoapify.com/v1/geocode/$path?text="+enc(text)+(if(geoAutocomplete && q.street.trim().lowercase() in setOf("via","rua","avenida","alameda","travessa"))"&type=street" else "")+"&format=json&limit=20&lang=pt&filter=rect:-61.2,2.4,-60.15,3.25%7Ccountrycode:br&bias=proximity:-60.6758,2.8235&apiKey="+enc(BuildConfig.GEOAPIFY_API_KEY)
  val conn=URL(url).openConnection() as HttpURLConnection
  conn.connectTimeout=minOf(2000,remaining);conn.readTimeout=minOf(6500,remaining)
  conn.setRequestProperty("User-Agent","BipadoDeRota/31 Android")
  connection=conn
  try{
   if(closed || id!=generation.get())return emptyList()
   val code=conn.responseCode
   if(code==401 || code==403)throw IllegalStateException("Chave Geoapify inválida ou sem permissão")
   if(code==429)throw IllegalStateException("Limite de consultas atingido. Tente mais tarde")
   if(code !in 200..299)throw java.io.IOException("Serviço de mapas indisponível")
   val body=JSONObject(conn.inputStream.bufferedReader().use{it.readText()})
   val data=if(photon)body.optJSONArray("features") else body.optJSONArray("results")
   if(data==null)return emptyList()
   val hits=mutableListOf<Hit>()
   for(i in 0 until data.length()){
    val item=data.getJSONObject(i)
    val p=if(photon)item.optJSONObject("properties") ?: continue else item
    val coordinates=if(photon)item.optJSONObject("geometry")?.optJSONArray("coordinates") else null
    val lat=if(photon)coordinates?.optDouble(1,Double.NaN) ?: Double.NaN else p.optDouble("lat",Double.NaN)
    val lon=if(photon)coordinates?.optDouble(0,Double.NaN) ?: Double.NaN else p.optDouble("lon",Double.NaN)
    if(photon && p.optString("countrycode").isNotBlank() && !p.optString("countrycode").equals("BR",true))continue
    if(!GeoAddress.inRegion(lat,lon))continue
    if(p.optString("city").isNotBlank() && AddressIdentity.normalize(p.optString("city"))!="boa vista")continue
    val street=p.optString("street").ifBlank{if(p.optString("result_type")=="street" || p.optString("type")=="street" || p.optString("osm_key")=="highway")p.optString("name") else ""}
    val name=p.optString("name")
    if(street.isBlank() && name.isBlank())continue
    val place=name.isNotBlank() && name!=street && (p.optString("result_type") in setOf("amenity","building") || (photon && p.optString("type") in setOf("house","street") && p.optString("osm_key") !in setOf("place","highway")))
    val score=if(suggestions)maxOf(GeoAddress.suggestionScore(street,q.street),if(place && q.number.isBlank())GeoAddress.suggestionScore(listOf(name,p.optString("suburb"),p.optString("district"),p.optString("locality")).filter{it.isNotBlank()}.joinToString(" "),q.street) else 0) else if(q.number.isNotBlank())GeoAddress.streetScore(street,q.street) else maxOf(GeoAddress.streetScore(street,q.street),if(place)GeoAddress.streetScore(listOf(name,p.optString("suburb"),p.optString("district"),p.optString("locality")).filter{it.isNotBlank()}.joinToString(" "),q.street) else 0)
    if(score<70)continue
    val returnedNumber=p.optString("housenumber")
    val exact=(photon || (p.optString("result_type") in setOf("building","amenity") && p.optJSONObject("rank")?.optString("match_type") !in setOf("match_by_street","match_by_postcode","match_by_city_or_disrict","match_by_country_or_state"))) && returnedNumber.isNotBlank() && (q.number.isBlank() || GeoAddress.exactNumber(q.number,returnedNumber))
    // Input number can fill the suggestion, but is not proof of its map coordinate.
    val displayedNumber=if(q.number.isNotBlank())q.number else returnedNumber
    val streetLine=listOf(if(place)name else "",street,displayedNumber,p.optString("suburb").ifBlank{p.optString("district")}).filter{it.isNotBlank()&&it!="null"}.joinToString(", ")
    val location=listOf(p.optString("city").ifBlank{"Boa Vista"},p.optString("state_code").ifBlank{if(p.optString("state")=="Roraima")"RR" else p.optString("state").ifBlank{"RR"}},p.optString("postcode")).filter{it.isNotBlank()&&it!="null"}.joinToString(", ")
    val title=listOf(if(place)name else street,displayedNumber).filter{it.isNotBlank()&&it!="null"}.joinToString(", ")
    val postcode=p.optString("postcode").takeUnless{it=="null"}.orEmpty()
    val details=listOf(p.optString("suburb").ifBlank{p.optString("district")},location,if(q.number.isNotBlank() && !exact)"Número ${q.number} não localizado" else "",if(postcode.isBlank())"CEP não informado pela base" else "").filter{it.isNotBlank()&&it!="null"}.joinToString(" — ")
    val label=listOf(streetLine,location).filter{it.isNotBlank()}.joinToString(" — ")
    val source=if(photon)"OpenStreetMap / Photon" else p.optJSONObject("datasource")?.optString("attribution").orEmpty()
    hits.add(Hit(label,lat,lon,score,exact,source,streetLine,location,place && q.number.isBlank(),title,details,postcode))
   }
   return hits.sortedWith(compareByDescending<Hit>{it.exact}.thenByDescending{it.score}).distinctBy{AddressIdentity.normalize(it.streetLine+"|"+it.postcode)}.take(5)
  }finally{if(connection===conn)connection=null;conn.disconnect()}
 }
 fun lookup(text:String,provideSuggestions:Boolean=false,onResults:((List<Hit>)->Unit)?=null){
  if(closed)return
  addressMissing=false
  if(ready)web?.evaluateJavascript("window.setMissingAddress(false);",null)
  val id=generation.incrementAndGet();job?.cancel(true);connection?.disconnect();executor.purge()
  val q=GeoAddress.query(text);lastQuery=q.full
  val key=(if(provideSuggestions)"suggest:" else "address:")+AddressIdentity.normalize(q.full)
  pending=null
  if(ready)web?.evaluateJavascript("window.clearPin();",null)
  if(q.street.length<(if(provideSuggestions)1 else 3)){setStatus("Digite o nome da rua para localizar");onResults?.invoke(emptyList());return}
  if(provideSuggestions){
   val local=localSuggestions(q)
   if(local.isNotEmpty() && q.street.split(Regex("\\s+")).all{it.length<=3}){setStatus("Toque no endereço desejado");onResults?.invoke(local);return}
  }
  cached(key)?.let{hits->if(!provideSuggestions)show(hits.first()) else setStatus("Selecione uma sugestão");onResults?.invoke(hits);return}
  if(!provideSuggestions && BuildConfig.GEOAPIFY_API_KEY.isBlank()){setStatus("Serviço de mapas não configurado");onResults?.invoke(emptyList());return}
  setStatus(if(provideSuggestions)"Buscando sugestões…" else "Procurando endereço…")
  job=executor.submit{
   val started=SystemClock.elapsedRealtime();val deadline=started+8500
   var error:String?=null
   val fallback=if(provideSuggestions)localSuggestions(q) else emptyList()
   val remote=try{
    // One focused request; selecting a suggestion reuses its coordinates.
    val query=if(provideSuggestions)GeoAddress.suggestionText(q) else q.full
    val primary=fetch(query,q,provideSuggestions,id,deadline)
    if(provideSuggestions && primary.isEmpty() && BuildConfig.GEOAPIFY_API_KEY.isNotBlank() && deadline-SystemClock.elapsedRealtime()>700)
     fetch(query,q,true,id,deadline,true)
    else primary
   }catch(_:java.net.SocketTimeoutException){error="Busca demorou. Confira a internet e tente novamente";emptyList()}
    catch(e:IllegalStateException){error=e.message;emptyList()}
    catch(_:Exception){error="Sem conexão com o serviço de mapas. Confira a internet";emptyList()}
   val hits=(remote+fallback).distinctBy{AddressIdentity.normalize(it.streetLine+"|"+it.postcode)}.take(50)
   if(!closed && id==generation.get())remember(key,hits,!provideSuggestions)
   main.post{
    if(closed || id!=generation.get())return@post
    android.util.Log.d("BipadoMapa","Mapa ${SystemClock.elapsedRealtime()-started}ms results=${hits.size}")
    if(hits.isNotEmpty()){if(!provideSuggestions)show(hits.first()) else setStatus("Selecione uma sugestão para localizar no mapa")}
    else setStatus(error ?: "Endereço ou local não encontrado. Confira a busca")
    onResults?.invoke(hits)
   }
  }
 }
 fun cancelLookup(){generation.incrementAndGet();job?.cancel(true);connection?.disconnect();executor.purge();pending=null;if(ready)web?.evaluateJavascript("window.clearPin();",null)}
 fun choose(hit:Hit,refine:Boolean=false){
  if(closed)return
  addressMissing=false;if(ready)web?.evaluateJavascript("window.setMissingAddress(false);",null)
  val id=generation.incrementAndGet();job?.cancel(true);connection?.disconnect();executor.purge()
  val q=GeoAddress.query("${hit.streetLine}, ${hit.location}")
  remember("address:"+AddressIdentity.normalize(q.full),listOf(hit),true);show(hit)
  if(!refine || hit.usable || q.number.isBlank() || BuildConfig.GEOAPIFY_API_KEY.isBlank() || !refined.add(q.full))return
  setStatus("Ponto aproximado da rua • procurando o número ${q.number}…")
  job=executor.submit{
   val exact=try{fetch(q.full,q,false,id,SystemClock.elapsedRealtime()+8500).firstOrNull{it.exact}}catch(_:Exception){null}
   main.post{
    if(closed || id!=generation.get())return@post
    if(exact!=null){remember("address:"+AddressIdentity.normalize(q.full),listOf(exact),true);show(exact)}
    else setStatus("Casa ${q.number} não localizada • toque no mapa ou arraste o pino até a casa. O ponto laranja é aproximado.")
   }
  }
 }

 fun release(){if(closed)return;closed=true;generation.incrementAndGet();job?.cancel(true);connection?.disconnect();executor.shutdownNow();main.removeCallbacksAndMessages(null);web?.stopLoading();web?.destroy()}
}
