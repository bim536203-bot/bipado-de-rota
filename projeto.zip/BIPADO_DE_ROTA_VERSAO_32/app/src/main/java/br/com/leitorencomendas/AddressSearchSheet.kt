package br.com.leitorencomendas

import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.*

/** Search-only sheet. Selection stays local until SALVAR; it never writes a parcel. */
class AddressSearchSheet(
 private val context:Context,
 private val initialQuery:String,
 private val location:String,
 private val onSave:(MapAssistant.Hit)->Unit,
 private val onDismiss:()->Unit
){
 private fun dp(n:Int)=(n*context.resources.displayMetrics.density+.5f).toInt()
 private fun rounded(color:Int,radius:Int,stroke:Int?=null)=GradientDrawable().apply{
  setColor(color);cornerRadius=dp(radius).toFloat();stroke?.let{setStroke(dp(1),it)}
 }
 fun show():Dialog{
  var observeTouch:(MotionEvent)->Unit={}
  val dialog=object:Dialog(context){
   override fun dispatchTouchEvent(event:MotionEvent):Boolean{observeTouch(event);return super.dispatchTouchEvent(event)}
  }
  dialog.setCanceledOnTouchOutside(false)
  dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
  dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
  val root=LinearLayout(context).apply{
   orientation=LinearLayout.VERTICAL
   background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadii=floatArrayOf(dp(24).toFloat(),dp(24).toFloat(),dp(24).toFloat(),dp(24).toFloat(),0f,0f,0f,0f)}
  }
  val handle=View(context).apply{background=rounded(0xFFDCE2EE.toInt(),4)}
  root.addView(handle,LinearLayout.LayoutParams(dp(44),dp(4)).apply{gravity=Gravity.CENTER_HORIZONTAL;topMargin=dp(10);bottomMargin=dp(14)})
  val search=LinearLayout(context).apply{
   orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
   background=rounded(0xFFF5F6FB.toInt(),18,0xFF3D74FF.toInt());setPadding(dp(14),0,dp(8),0)
  }
  search.addView(SearchGlyph(context),LinearLayout.LayoutParams(dp(26),dp(26)).apply{marginEnd=dp(10)})
  val query=EditText(context).apply{
   setText(initialQuery);hint="Buscar endereço";textSize=19f;setTextColor(0xFF171C27.toInt())
   setHintTextColor(0xFF8B98B4.toInt());background=null;setSingleLine(true)
   inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
   imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
   setPadding(0,dp(9),0,dp(9));contentDescription="Buscar endereço por fragmentos"
  }
  search.addView(query,LinearLayout.LayoutParams(0,-2,1f))
  val clear=TextView(context).apply{
   text="×";textSize=32f;setTextColor(0xFF8D9BB7.toInt());gravity=Gravity.CENTER
   contentDescription="Limpar busca";setOnClickListener{query.setText("");query.requestFocus()}
  }
  search.addView(clear,LinearLayout.LayoutParams(dp(42),dp(48)))
  root.addView(search,LinearLayout.LayoutParams(-1,dp(58)).apply{leftMargin=dp(16);rightMargin=dp(16);bottomMargin=dp(20)})
  root.addView(TextView(context).apply{
   text="Adicionar endereço";textSize=15f;setTextColor(0xFF52617C.toInt());gravity=Gravity.CENTER_VERTICAL
   setPadding(dp(18),0,dp(18),0);setBackgroundColor(0xFFF3F5FA.toInt())
  },LinearLayout.LayoutParams(-1,dp(46)))
  val status=TextView(context).apply{
   text="Digite parte da rua, número ou nome do local";textSize=12f;setTextColor(0xFF67758D.toInt())
   setPadding(dp(18),dp(10),dp(18),dp(5));accessibilityLiveRegion=View.ACCESSIBILITY_LIVE_REGION_POLITE
  }
  root.addView(status,LinearLayout.LayoutParams(-1,-2))
  val suggestions=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL}
  val scroll=ScrollView(context).apply{isFillViewport=false;addView(suggestions);isVerticalScrollBarEnabled=false}
  root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  val actions=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.END;setPadding(dp(16),dp(8),dp(16),dp(12))}
  val cancel=Button(context).apply{text="CANCELAR";setTextColor(0xFF52617C.toInt());background=rounded(0xFFF3F5FA.toInt(),12);setOnClickListener{dialog.dismiss()}}
  val save=Button(context).apply{
   text="SALVAR";setTextColor(Color.WHITE);background=rounded(0xFF159B66.toInt(),12);visibility=View.GONE
  }
  actions.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{marginEnd=dp(5)})
  actions.addView(save,LinearLayout.LayoutParams(0,dp(48),1f).apply{marginStart=dp(5)})
  root.addView(TextView(context).apply{text="Toque fora do endereço para desmarcar";textSize=12f;setTextColor(0xFF67758D.toInt());setPadding(dp(18),dp(8),dp(18),dp(5))})
  root.addView(actions,LinearLayout.LayoutParams(-1,-2))
  // No WebView or map is created in this sheet. Only the confirmation shows the map.
  val assistant=MapAssistant(context,null,status)
  val handler=Handler(Looper.getMainLooper())
  var pending:Runnable?=null
  var selected:MapAssistant.Hit?=null
  var selectedRow:View?=null
  var selectedCheck:TextView?=null
  var closed=false
  var revision=0
  fun clearSelection(){
   selected=null;save.visibility=View.GONE
   selectedRow?.background=null;selectedRow=null
   selectedCheck?.visibility=View.GONE;selectedCheck=null
  }
  fun inside(view:View?,event:MotionEvent):Boolean{
   if(view==null || view.visibility!=View.VISIBLE)return false
   val at=IntArray(2);view.getLocationOnScreen(at)
   return event.rawX>=at[0] && event.rawX<at[0]+view.width && event.rawY>=at[1] && event.rawY<at[1]+view.height
  }
  observeTouch={event->
   if(event.action==MotionEvent.ACTION_OUTSIDE || (event.action==MotionEvent.ACTION_DOWN && !inside(selectedRow,event) && !inside(save,event)))clearSelection()
  }
  fun searchChanged(){
   val version=++revision
   clearSelection()
   pending?.let{handler.removeCallbacks(it)};assistant.cancelLookup();suggestions.removeAllViews()
   if(query.text.toString().none{it.isLetter()}){status.text="Digite parte da rua, número ou nome do local";return}
   val searchText="${query.text}, $location"
   status.text="Buscando sugestões…"
   pending=Runnable{
    assistant.lookup(searchText,true){hits->
     if(closed || version!=revision)return@lookup
     suggestions.removeAllViews()
     if(hits.isNotEmpty())status.text="Toque no endereço desejado"
     for(hit in hits){
      val row=LinearLayout(context).apply{
       orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
       setPadding(dp(20),dp(16),dp(16),dp(16));minimumHeight=dp(86)
       contentDescription=hit.label
      }
      row.addView(StopGlyph(context),LinearLayout.LayoutParams(dp(25),dp(29)).apply{marginEnd=dp(22)})
      val lines=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL}
      lines.addView(TextView(context).apply{this.text=hit.title;textSize=18f;setTextColor(0xFF171C27.toInt());setTypeface(null,Typeface.BOLD)})
      lines.addView(TextView(context).apply{this.text=hit.details;textSize=14f;setTextColor(0xFF53627F.toInt());setPadding(0,dp(5),0,0)})
      row.addView(lines,LinearLayout.LayoutParams(0,-2,1f))
      val check=TextView(context).apply{text="✓";textSize=24f;setTextColor(0xFF3975FF.toInt());gravity=Gravity.CENTER;visibility=View.GONE}
      row.addView(check,LinearLayout.LayoutParams(dp(30),dp(32)))
      row.setOnClickListener{
       ++revision;pending?.let{handler.removeCallbacks(it)};assistant.cancelLookup();clearSelection()
       selected=hit;selectedRow=row;selectedCheck=check;check.visibility=View.VISIBLE
       row.background=rounded(0xFFEEF4FF.toInt(),10,0xFF3975FF.toInt());save.visibility=View.VISIBLE
       status.text=if(hit.postcode.isBlank())"Endereço selecionado. CEP não informado pela base." else "Endereço selecionado • CEP ${hit.postcode}"
       (context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(query.windowToken,0)
      }
      suggestions.addView(row,LinearLayout.LayoutParams(-1,-2))
     }
    }
   };handler.postDelayed(pending!!,350)
  }
  query.addTextChangedListener(object:TextWatcher{
   override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
   override fun afterTextChanged(s:Editable?){}
   override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){searchChanged()}
  })
  query.setOnEditorActionListener{_,_,_->searchChanged();true}
  save.setOnClickListener{selected?.let{hit->onSave(hit);dialog.dismiss()}}
  dialog.setOnDismissListener{
   closed=true;++revision;pending?.let{handler.removeCallbacks(it)};assistant.release();onDismiss()
  }
  dialog.setContentView(root)
  dialog.show()
  dialog.window?.apply{
   setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));setGravity(Gravity.BOTTOM)
   addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH)
   clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM)
   setDimAmount(.45f)
   setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
   setLayout(-1,(context.resources.displayMetrics.heightPixels*.86).toInt())
  }
  query.requestFocus();query.setSelection(query.text.length)
  handler.postDelayed({if(!closed)(context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.showSoftInput(query,InputMethodManager.SHOW_IMPLICIT)},120)
  if(initialQuery.isNotBlank())searchChanged()
  return dialog
 }
 private class SearchGlyph(context:Context):View(context){
  private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xFF8D9BB7.toInt();style=Paint.Style.STROKE;strokeWidth=3*resources.displayMetrics.density;strokeCap=Paint.Cap.ROUND}
  override fun onDraw(c:Canvas){super.onDraw(c);val s=minOf(width,height).toFloat();c.drawCircle(s*.4f,s*.4f,s*.27f,paint);c.drawLine(s*.61f,s*.61f,s*.9f,s*.9f,paint)}
 }
 private class StopGlyph(context:Context):View(context){
  private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xFF8D9BB7.toInt();style=Paint.Style.STROKE;strokeWidth=2*resources.displayMetrics.density;strokeJoin=Paint.Join.ROUND;strokeCap=Paint.Cap.ROUND}
  override fun onDraw(c:Canvas){
   super.onDraw(c);val w=width.toFloat();val h=height.toFloat()
   val path=Path().apply{moveTo(w*.18f,h*.08f);lineTo(w*.82f,h*.08f);quadTo(w*.92f,h*.08f,w*.92f,h*.18f);lineTo(w*.92f,h*.7f);quadTo(w*.92f,h*.8f,w*.8f,h*.8f);lineTo(w*.63f,h*.8f);lineTo(w*.47f,h*.97f);lineTo(w*.31f,h*.8f);lineTo(w*.18f,h*.8f);quadTo(w*.08f,h*.8f,w*.08f,h*.68f);lineTo(w*.08f,h*.18f);quadTo(w*.08f,h*.08f,w*.18f,h*.08f);close()}
   c.drawPath(path,paint);c.drawLine(w*.3f,h*.42f,w*.7f,h*.42f,paint);c.drawLine(w*.5f,h*.25f,w*.5f,h*.59f,paint)
  }
 }
}
