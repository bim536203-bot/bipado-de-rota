package br.com.leitorencomendas

object WhatsappPolicy {
 const val MESSAGE="Ola!! Tenho uma entrega para vc, estou aqui na frente do local, tem alguém para receber?"
 private val ddds=setOf(11,12,13,14,15,16,17,18,19,21,22,24,27,28,31,32,33,34,35,37,38,41,42,43,44,45,46,47,48,49,51,53,54,55,61,62,63,64,65,66,67,68,69,71,73,74,75,77,79,81,82,83,84,85,86,87,88,89,91,92,93,94,95,96,97,98,99)
 fun normalize(raw:String):String? {
  if(raw.any{!it.isDigit() && it !in " +().-\t\r\n"})return null
  var n=raw.filter{it in '0'..'9'}
  if(n.length in 12..13 && n.startsWith("55"))n=n.drop(2)
  if(n.length !in 10..11 || n.take(2).toIntOrNull() !in ddds)return null
  if(n.length==11 && n[2]!='9')return null
  if(n.length==10 && n[2] !in '2'..'9')return null
  return "55$n"
 }
 /** Bounded phone-shaped spans; never join digits across unrelated lines. */
 fun extract(text:String):List<String>{
  val found=linkedSetOf<String>()
  val candidate=Regex("""(?<![\p{L}\d])(?:\+?55[ .-]?)?\(?[1-9]\d\)?[ .-]?(?:9[ .-]?)?\d{4}[ .-]?\d{4}(?![\p{L}\d])""")
  for(line in text.lineSequence()){
   val label=Regex("(?i)telefone|celular|whats|contato|\\btel\\b").containsMatchIn(line)
   if(!label && Regex("(?i)rastreio|pedido|c[oó]digo|pacote|cnpj|cpf").containsMatchIn(line))continue
   for(m in candidate.findAll(line))normalize(m.value)?.let{found.add(it)}
  }
  return found.toList()
 }
 fun acceptsPin(pin:String)=pin.length==4 && pin.all{it in '0'..'9'} &&
  java.security.MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString(""){"%02x".format(it)}=="ce8457d59078a699acb70416f88155a96a906b7b7aad43708402e3a3bcc8a4b4"
}
