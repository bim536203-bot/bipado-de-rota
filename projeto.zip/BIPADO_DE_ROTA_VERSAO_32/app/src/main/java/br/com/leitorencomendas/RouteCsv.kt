package br.com.leitorencomendas

import org.json.JSONArray
import org.json.JSONObject

/** Parse CSV with quoted fields, escaped quotes, CRLF and UTF-8 BOM. */
object RouteCsv {
 private fun csvCell(s:String)="\""+s.replace("\"","\"\"")+"\""
 private val packageMarker=Regex("""(?i)\bpacote(?=\s|\d|$)""")
 private val packageList=Regex("""\d+(?:\s*-\s*\d+)*""")
 private val skippedLabel=Regex("""(?i)\bpacote\s*\d+(?:\s*-\s*\d+)*\s*pulado\b""")
 /** One route stop per address; preserve the first address text and list every real parcel. */
 fun export(items:JSONArray):String {
  data class Stop(val address:String,val key:String?,val normalized:String,val numbers:MutableList<Int>,val phones:MutableMap<Int,String>)
  val stops=mutableListOf<Stop>();val used=mutableSetOf<Int>()
  for(i in 0 until items.length()){
   val item=items.optJSONObject(i) ?: throw IllegalArgumentException("Pacote inválido na lista")
   val address=item.optString("address")
   if(item.optBoolean("skipped",false) || address.isBlank())continue
   if(item.optString("whatsapp").isNotBlank() && WhatsappPolicy.normalize(item.optString("whatsapp"))==null)throw IllegalArgumentException("WhatsApp inválido na lista")
   val number=item.optInt("number",i+1)
   if(number<1 || !used.add(number))throw IllegalArgumentException("Numeração de pacote inválida ou repetida")
   // Same identity rule as the cards; compute expensive text normalization only once per item.
   val key=AddressIdentity.key(address);val normalized=AddressIdentity.normalize(address)
   val stop=stops.firstOrNull {
    if(key!=null && it.key!=null)key==it.key else normalized.isNotBlank() && normalized==it.normalized
   }
   if(stop==null)stops.add(Stop(address,key,normalized,mutableListOf(number),mutableMapOf<Int,String>().also { map -> WhatsappPolicy.normalize(item.optString("whatsapp"))?.let { map[number]=it } })) else {stop.numbers.add(number);WhatsappPolicy.normalize(item.optString("whatsapp"))?.let {stop.phones[number]=it}}
  }
  return buildString {
   append("Address,Notes\r\n")
   for(stop in stops){
    append(csvCell(stop.address));append(',')
    append(csvCell("PACOTE "+stop.numbers.sorted().joinToString("-")+stop.phones.toSortedMap().entries.joinToString("") { "; WA${it.key}=${it.value}" }));append("\r\n")
   }
  }
 }
 private fun numbers(note:String):List<Int>? {
  val marker=packageMarker.find(note) ?: return null
  val raw=note.substring(marker.range.last+1).substringBefore(';').substringBefore('\n').trim().removeSuffix(".").trim()
  if(!packageList.matches(raw))throw IllegalArgumentException("Descrição de pacotes inválida no CSV")
  return raw.split('-').map {token->token.trim().toIntOrNull()?.takeIf {it>0}
   ?: throw IllegalArgumentException("Número de pacote inválido no CSV")}
 }
 fun parse(csv:String):JSONArray {
  val text=csv.removePrefix("\uFEFF")
  if(text.length>2_000_000)throw IllegalArgumentException("Arquivo muito grande")
  val rows=mutableListOf<List<String>>()
  val fields=mutableListOf<String>()
  val cell=StringBuilder()
  var quoted=false
  var pos=0
  while(pos<text.length){
   when(val ch=text[pos]){
    '"' -> {
     if(quoted && pos+1<text.length && text[pos+1]=='"'){cell.append('"');pos++}
     else if(quoted)quoted=false
     else if(cell.isEmpty())quoted=true
     else throw IllegalArgumentException("Aspas inválidas no CSV")
    }
    ',' -> if(quoted)cell.append(ch) else {fields.add(cell.toString());cell.setLength(0)}
    '\r','\n' -> if(quoted)cell.append(ch) else {
     fields.add(cell.toString());cell.setLength(0)
     if(fields.any{it.isNotBlank()})rows.add(fields.toList())
     fields.clear()
     if(ch=='\r' && pos+1<text.length && text[pos+1]=='\n')pos++
    }
    else -> cell.append(ch)
   }
   pos++
  }
  if(quoted)throw IllegalArgumentException("CSV com aspas sem fechamento")
  fields.add(cell.toString())
  if(fields.any{it.isNotBlank()})rows.add(fields.toList())
  if(rows.size<2)throw IllegalArgumentException("CSV sem endereços")
  val header=rows.first().map{it.trim().lowercase()}
  val addressColumn=header.indexOf("address")
  val notesColumn=header.indexOf("notes")
  if(addressColumn<0)throw IllegalArgumentException("Coluna Address não encontrada")
  data class ImportRow(val address:String,val numbers:List<Int>?,val phones:Map<Int,String>)
  val importing=mutableListOf<ImportRow>();val used=mutableSetOf<Int>()
  for(row in rows.drop(1)){
   if(row.size!=header.size)throw IllegalArgumentException("Linha de CSV incompleta")
   val address=row[addressColumn].trim()
   if(address.isBlank())continue // Ignore empty rows, never create map pin for skipped item.
   if(address.length<8)throw IllegalArgumentException("Endereço inválido no CSV")
   val note=if(notesColumn>=0)row[notesColumn] else ""
   if(skippedLabel.containsMatchIn(note)||skippedLabel.containsMatchIn(address))continue
   val numbers=numbers(note)
   for(number in numbers.orEmpty())if(!used.add(number))throw IllegalArgumentException("Números de pacotes repetidos no CSV")
   val phones=mutableMapOf<Int,String>()
   for(part in note.split(';').drop(1).map{it.trim()}){
    if(!part.startsWith("WA",true))continue
    val match=Regex("""(?i)WA(\d+)=(55\d{10,11})""").matchEntire(part) ?: throw IllegalArgumentException("WhatsApp inválido no CSV")
    val n=match.groupValues[1].toIntOrNull() ?: throw IllegalArgumentException("Pacote do WhatsApp inválido")
    val phone=WhatsappPolicy.normalize(match.groupValues[2]) ?: throw IllegalArgumentException("Telefone inválido no CSV")
    if(n !in numbers.orEmpty() || phones.put(n,phone)!=null)throw IllegalArgumentException("WhatsApp repetido ou sem pacote correspondente")
   }
   importing.add(ImportRow(address,numbers,phones))
  }
  val output=JSONArray();var next=1
  for(row in importing){
   // Reserve explicit numbers first so an unlabelled row cannot steal a later package ID.
   val numbers=row.numbers ?: run {
    while(next in used)next++
    listOf(next.also {used.add(it)})
   }
   for(number in numbers)output.put(JSONObject().put("address",row.address).put("number",number).put("createdAt",System.currentTimeMillis()).also { obj -> row.phones[number]?.let { obj.put("whatsapp",it) } })
  }
  if(output.length()==0)throw IllegalArgumentException("Nenhum endereço válido para importar")
  return output
 }
}
