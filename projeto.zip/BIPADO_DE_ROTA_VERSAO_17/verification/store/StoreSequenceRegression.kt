import android.content.Context
import br.com.leitorencomendas.Store
import org.json.JSONArray
import org.json.JSONObject

fun main(){
 var cases=0
 fun expect(value:Boolean,message:String){check(value){message};cases++}
 fun row(n:Int)=JSONObject().put("number",n).put("address","Rua Teste $n, ${100+n}, Centro, Boa Vista, RR")
 fun seed(c:Context,last:Int,items:JSONArray=JSONArray(),skips:JSONArray=JSONArray()){
  c.getSharedPreferences("deliveries",0).edit().putString("state",JSONObject().put("items",items).put("skipped",skips).put("history",JSONArray()).put("lastNumber",last).toString()).commit()
 }
 val c=Context()
 expect(Store.nextNumber(c)==1,"A fresh route must start at 1")
 expect(Store.add(c,row(1).getString("address"),1),"First scan saves package 1")
 expect(Store.add(c,row(2).getString("address"),2),"Second scan saves package 2")
 expect(Store.remove(c,1),"Deleting latest package succeeds")
 expect(Store.nextNumber(c)==3,"A nonempty route keeps its sequence")
 expect(Store.remove(c,0),"Deleting last address succeeds")
 expect(Store.nextNumber(c)==1,"Deleting last address resets to 1")
 seed(c,14,JSONArray().put(row(14)))
 expect(Store.clear(c),"Clear archives and empties active route")
 expect(Store.nextNumber(c)==1,"Clear resets to 1")
 expect(Store.history(c).getJSONObject(0).getJSONArray("items").getJSONObject(0).getInt("number")==14,"Archived package number is preserved")
 seed(c,99)
 expect(Store.nextNumber(c)==1,"Empty states from older versions ignore stale counter")
 expect(Store.add(c,row(1).getString("address"),1),"Stale empty state accepts package 1")
 expect(Store.nextNumber(c)==2,"New sequence proceeds to 2")
 seed(c,99)
 expect(Store.clear(c),"Clearing an already empty stale state succeeds")
 expect(JSONObject(c.getSharedPreferences("deliveries",0).getString("state","")!!).getInt("lastNumber")==0,"Clear persists counter reset")
 expect(Store.skipNext(c,1),"Skipping first package reserves 1")
 expect(Store.nextNumber(c)==2,"Visible skipped package retains its reserved number")
 expect(Store.add(c,row(2).getString("address"),2),"First actual address after skip is package 2")
 expect(Store.clear(c),"Clear removes skipped placeholders too")
 expect(Store.skipped(c).length()==0 && Store.nextNumber(c)==1,"Cleared skipped route resets to 1")
 expect(Store.replaceWithImport(c,JSONArray().put(row(14)).put(row(15))),"Import keeps explicit package numbers")
 expect(Store.nextNumber(c)==16,"Imported route continues from its maximum")
 println("$cases Store sequence regression assertions passed")
}
