package br.com.leitorencomendas

object DuplicatePackageLabel {
 fun text(numbers:List<Int>):String {
  val ordered=numbers.filter {it>0}.distinct().sorted()
  val list=ordered.joinToString("-")
  return "MESMO ENDEREÇO PACOTE $list"
 }
}
