# BIPADO DE ROTA — VERSÃO 16

Projeto Android Kotlin com as correções consolidadas nesta conversa. O ZIP contém código-fonte; a atualização instalável é publicada no GitHub para o atualizador do app.

- Captura e seleção do cartão adaptadas às dimensões da tela e ao tamanho local do texto.
- Proteção contra ícones no endereço e leitura ambígua do número da casa.
- Edição manual recupera CONFIRMAR, remove aviso antigo e oculta PULAR ao salvar endereço válido.
- Tela de falha com faixa preta e texto amarelo ENDEREÇO NÃO ENCONTRADO!.
- Confirmação de pacotes reais no mesmo endereço, cartões individuais e caixinhas dos outros pacotes.
- Exportação de um destino por endereço com Notes PACOTE 1-2-3; reimportação recupera cartões individuais. Pulados não entram no CSV.
- Identificação pública VERSÃO 16, com próximas versões 17, 18, 19.

Leia LEIA_ME_VERSAO_16.md para regras e limites. Os demais relatórios LEIA_ME são históricos. São 788 verificações Kotlin locais aprovadas; compilação/lint/assinatura são validados no GitHub antes da release. O teste do fluxo real nos celulares e no Spoke ainda precisa ser feito.

Repositório de atualização: https://github.com/bim536203-bot/bipado-de-rota
