import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {JSDOM} from 'jsdom';
import {createApp} from '../dist/app.js';import * as C from '../dist/core.js';import {pickResult} from '../dist/mini-map.js';
const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');const tick=()=>new Promise(r=>setTimeout(r,0));
test('Salvar mostra mapa sem gravar; cancelar preserva; confirmar grava e toca bip',async()=>{
 const dom=new JSDOM(html,{url:'https://example.test/'}),w=dom.window,d=w.document;w.scrollTo=()=>{};w.matchMedia=()=>({matches:false});w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open')};
 let stored=C.freshState(),maps=0,destroyed=0;const played=[];
 const repo={readState:async()=>structuredClone(stored),commitState:async(rev,fn)=>{assert.equal(rev,stored.revision);stored=C.validateState({...fn(structuredClone(stored)),revision:rev+1});return structuredClone(stored)}};
 const app=createApp(w,repo,{sounds:{unlock(){},play:s=>played.push(s)},mapFactory:(win,map,status,address)=>{maps++;assert.match(address,/Rua Vega, 28/);status.textContent='Número localizado na base • confira o ponto';return {destroy(){destroyed++}}}});await app.ready;
 const click=label=>{const b=[...d.querySelectorAll('#dialog-actions button')].find(b=>b.textContent===label);assert.ok(b,label);b.click()};
 assert.equal(d.querySelector('#import-home span').textContent,'ADICIONAR ENDEREÇO MANUALMENTE');
 d.getElementById('menu-button').click();assert.equal(d.querySelectorAll('.choice-button').length,2);d.getElementById('dialog-close').click();
 const fill=()=>{d.getElementById('import-home').click();d.getElementById('editor-address').value='Rua Vega, 28';click('SALVAR')};
 fill();assert.equal(stored.items.length,0);assert.equal(maps,1);assert.deepEqual([...d.querySelectorAll('#dialog-actions button')].map(b=>b.textContent),['CANCELAR','CONFIRMAR']);assert.ok(d.querySelector('.mini-map'));click('CANCELAR');assert.equal(destroyed,1);assert.deepEqual(played,[]);
 fill();click('CONFIRMAR');await tick();assert.equal(stored.items[0].number,1);assert.deepEqual(played,['success']);assert.equal(destroyed,2);
 fill();assert.match(d.querySelector('.parcel-heading').textContent,/Pacote 2/);d.querySelector('.pencil-button').click();assert.equal(d.getElementById('editor-address').value,'Rua Vega, 28');click('SALVAR');click('CONFIRMAR');await tick();assert.deepEqual(C.groups(stored.items)[0].numbers,[1,2]);
 dom.window.close();
});
test('Próximo pacote ignora contador antigo e acompanha exclusão, edição e grupos',()=>{
 let s=C.freshState();s.lastNumber=999;assert.equal(C.nextNumber(s),1);s=C.addManual(s,'Rua Vega, 28');s=C.editItem(s,1,15,'Rua Vega, 28');assert.equal(C.nextNumber(s),16);s=C.editItem(s,15,7,'Rua Vega, 28');assert.equal(C.nextNumber(s),8);s=C.removeGroup(s,[7]);assert.equal(C.nextNumber(s),1);
 s=C.importRoute(s,[{number:1,address:'Rua Vega, 28'},{number:2,address:'Rua Vega, 28'},{number:7,address:'Rua Vega, 28'}]);assert.equal(C.nextNumber(s),8);
});
test('Mini mapa rejeita outra rua/cidade e diferencia número exato de rua aproximada',()=>{
 const f=(street,city,housenumber)=>({geometry:{coordinates:[-60.6,2.8]},properties:{street,city,housenumber,countrycode:'BR'}});
 const a='Rua Vega, 28, Boa Vista, RR, Brasil';assert.equal(pickResult([f('Rua Cisne','Boa Vista','28')],a),null);assert.equal(pickResult([f('Rua Vega','Outra cidade','28')],a),null);assert.equal(pickResult([f('Rua Vega','Boa Vista','28')],a).exact,true);assert.equal(pickResult([f('Rua Vega','Boa Vista','20')],a).exact,false);
});
