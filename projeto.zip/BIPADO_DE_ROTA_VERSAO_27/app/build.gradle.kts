plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { signingConfigs { getByName("debug") { providers.gradleProperty("bipadoSigningKey").orNull?.let { keyPath -> storeFile=file(keyPath); storePassword="android"; keyAlias="androiddebugkey"; keyPassword="android" } } }; namespace = "br.com.leitorencomendas"; compileSdk = 35
 defaultConfig { applicationId = "br.com.leitorencomendas"; minSdk = 26; targetSdk = 34; versionCode = providers.gradleProperty("ciVersionCode").getOrElse("82").toInt(); versionName = providers.gradleProperty("ciVersionName").getOrElse("27") }
 buildFeatures { buildConfig=true }
 defaultConfig { buildConfigField("String","UPDATE_REPOSITORY","\""+providers.gradleProperty("updateRepository").getOrElse("bim536203-bot/bipado-de-rota")+"\"") }
 defaultConfig { val geoKey=providers.environmentVariable("GEOAPIFY_API_KEY").orElse(providers.gradleProperty("geoapifyApiKey")).getOrElse(""); buildConfigField("String","GEOAPIFY_API_KEY","\""+geoKey+"\"") }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.core:core:1.13.1"); implementation("com.google.mlkit:text-recognition:16.0.1") }
