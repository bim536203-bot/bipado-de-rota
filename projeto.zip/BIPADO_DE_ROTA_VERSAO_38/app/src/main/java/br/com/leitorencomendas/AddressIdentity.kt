package br.com.leitorencomendas
import java.text.Normalizer
import java.util.Locale
object AddressIdentity {
 fun normalize(address:String):String {
  var x=Normalizer.normalize(address.lowercase(Locale.forLanguageTag("pt-BR")),Normalizer.Form.NFD).replace(Regex("\\p{M}+"),"")
  x=x.replace(Regex("\\b(?:avenidas?|av)\\.?\\b")," avenida ")
   .replace(Regex("\\b(?:ruas?|r)\\.?\\b")," rua ")
   .replace(Regex("\\b(?:travessas?|tv)\\.?\\b")," travessa ")
   .replace(Regex("\\b(?:alamedas?|al)\\.?\\b")," alameda ")
   .replace(Regex("\\b(?:vias?)\\b")," via ")
   .replace(Regex("\\bbrasil\\b")," ")
  return x.replace(Regex("[^a-z0-9]")," ").replace(Regex("\\s+")," ").trim()
 }
 fun key(address:String):String? {
  val cleaned=AddressText.clean(address)
  val parts=cleaned.split(',')
  val house=Regex("""^\s*(\d{1,5}(?:/\d{1,5})?[a-zA-Z]?)\s*$""")
  if(parts.size>=2){
   val number=house.matchEntire(parts[1])?.groupValues?.get(1)
   if(number!=null){val street=normalize(AddressText.splitStreet(parts[0]).first);if(street.any{it.isLetter()})return street+"|"+number.lowercase(Locale.ROOT)}
  }
  val segment=cleaned.substringBefore(',').trim()
  val found=Regex("""^(.+?)\s+(\d{1,5}(?:/\d{1,5})?[a-zA-Z]?)(?:\s|$)""").find(segment) ?: return null
  val street=normalize(AddressText.splitStreet(found.groupValues[1]).first)
  if(street.length<4 || !street.any{it.isLetter()})return null
  return street+"|"+found.groupValues[2].lowercase(Locale.ROOT)
 }
 fun same(a:String,b:String):Boolean {
  val ka=key(a);val kb=key(b)
  return if(ka!=null && kb!=null)ka==kb else normalize(a).isNotBlank() && normalize(a)==normalize(b)
 }
}
