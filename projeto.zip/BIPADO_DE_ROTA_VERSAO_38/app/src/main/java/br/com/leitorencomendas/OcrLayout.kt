package br.com.leitorencomendas

import java.text.Normalizer
import java.util.Locale
import kotlin.math.abs

/** Select a parcel's text by its content and local typography, never a screen percentage. */
object OcrLayout {
 data class Span(val text:String,val left:Int,val top:Int,val right:Int,val bottom:Int)
 data class Selection(val text:String,val lines:List<String>,val reason:String)
 private val tracking=Regex("""^\d{9,22}$""")
 private val date=Regex("""\b20\d{2}[-/]\d{2}[-/]\d{2}""")
 private val road=Regex("""(?i)\b(?:ruas?|r\.?|avenidas?|av\.?|vias?|travessas?|tv\.?|alamedas?|al\.?|estradas?|rodovias?|passagens?|praças?|pracas?|becos?|vielas?|ladeiras?|ramais?|conjuntos?|servidões?|servidoes?)\b""")
 private val zip=Regex("""(?<!\d)\d{5}[-.\s]?\d{3}(?!\d)""")
 private val city=Regex("""(?i)\bBoa\s*Vista\s*[-,/ ]*\s*RR\b""")
 private fun normalized(s:String)=Normalizer.normalize(s.lowercase(Locale.ROOT),Normalizer.Form.NFD)
  .replace(Regex("""\p{M}+"""),"").trim()
 private fun sideAction(s:String)=normalized(s).matches(Regex("""(?:[^a-z\s]{0,3}\s*|[a-z0-9]\s+)?(?:navega[a-z]*|telefone)"""))
 private fun footer(s:String)=normalized(s) in setOf("whatsapp","assinar")
 private fun ui(s:String)=sideAction(s) || footer(s) || normalized(s) in setOf("procurar","numero","unico","numero unico")
 private fun Span.h()=(bottom-top).coerceAtLeast(1)
 private fun Span.cy()=(top.toDouble()+bottom)/2
 private fun sameRow(a:Span,b:Span)=abs(a.cy()-b.cy())<=minOf(a.h(),b.h())*.55

 private fun rows(spans:List<Span>):List<List<Span>> {
  val result=mutableListOf<MutableList<Span>>()
  // Use centres: uppercase letters and accents have different bounding-box tops.
  for(s in spans.sortedWith(compareBy<Span>{it.cy()}.thenBy{it.left})){
   val row=result.lastOrNull()
   if(row!=null && sameRow(s,row.first()))row.add(s) else result.add(mutableListOf(s))
  }
  return result.map {it.sortedBy {s->s.left}}
 }

 private data class ActionArea(val left:Int,val top:Int,val bottom:Int)
 private fun actionAreas(spans:List<Span>):List<ActionArea> = spans.filter {sideAction(it.text)}.map {label->
  // Detached compact OCR tokens beside a navigation/phone label are icons, not street suffixes.
  // Distances are measured in letter heights so font size and display density scale together.
  val addressLeft=spans.filter {road.containsMatchIn(it.text) && it.top<=label.bottom}
   .minByOrNull {abs(it.cy()-label.cy())}?.left
  val icon=spans.filter {s->
   val compact=s.text.filterNot {it.isWhitespace()}
   val gap=label.left-s.right
   val previous=spans.filter {it!==s && !ui(it.text) && sameRow(s,it) && it.right<=s.left}.maxByOrNull {it.right}
   // ML Kit may read only one edge of the icon circle: T), (T, 1), etc.
   // Treat those as icons ONLY with the same detached position beside an action label.
   val core=compact.trim('(',')','[',']','{','}')
   val partial=compact.length in 2..6 && core.length==1 && core[0] in "Tt1Il+↗→"
   val glyph=compact.length==1 || partial || (compact.length in 2..6 && compact.first() in "([{" && compact.last() in ")]}" )
   val detached=if(previous!=null)s.left-previous.right>minOf(s.h(),previous.h())*.65
    else addressLeft!=null && s.left-addressLeft>maxOf(s.h(),label.h())*4
   glyph && s.right<=label.left && gap<=maxOf(s.h(),label.h())*2.5 &&
    s.right-s.left<=s.h()*2 && abs(s.cy()-label.cy())<=maxOf(s.h(),label.h())*.65 &&
    detached
  }.maxByOrNull {it.right}
  ActionArea(icon?.left ?: label.left,minOf(label.top,icon?.top ?: label.top),maxOf(label.bottom,icon?.bottom ?: label.bottom))
 }

 fun select(spans:List<Span>,width:Int,height:Int):Selection {
  if(width<=0 || height<=0)return Selection("",emptyList(),"invalid image")
  val visible=spans.filter {it.text.isNotBlank() && it.right>it.left && it.bottom>it.top &&
   it.left<width && it.right>0 && it.top<height && it.bottom>0}
  val actions=actionAreas(visible)
  val candidates=visible.filter {s->!ui(s.text) && actions.none {a->s.left>=a.left && s.cy()>=a.top && s.cy()<=a.bottom}}
  val grouped=rows(candidates)
  fun text(row:List<Span>)=row.joinToString(" "){it.text.trim()}
  fun isTracking(row:List<Span>)=tracking.matches(text(row).replace(" ","")) || row.any {tracking.matches(it.text.trim())}
  val firstTrack=grouped.indexOfFirst(::isTracking)
  val searchStart=if(firstTrack>=0)firstTrack+1 else 0
  val streetIndex=(searchStart until grouped.size).firstOrNull {road.containsMatchIn(text(grouped[it]))}
  // Untyped streets require the parcel section after tracking + recipient.
  // A header or unrelated screen is never used as a guessed address.
  val start=streetIndex ?: if(firstTrack>=0)firstTrack+2 else return Selection("",emptyList(),"no parcel address anchor")
  if(start>=grouped.size)return Selection("",emptyList(),"no address below tracking")
  // Never jump from one parcel into the next if the first has no road name.
  if((searchStart until start).any {date.containsMatchIn(text(grouped[it])) || isTracking(grouped[it])})
   return Selection("",emptyList(),"parcel boundary before address")
  val anchor=grouped[start]
  val anchorY=anchor.minOf {it.top}
  val anchorLeft=anchor.minOf {it.left}
  val stopAtFooter=visible.filter {footer(it.text) && it.top>anchorY}.minOfOrNull {it.top}
  val selected=mutableListOf<String>()
  var previousBottom=anchor.maxOf {it.bottom}
  var previousHeight=anchor.map {it.h()}.sorted().let {it[it.size/2]}
  for(i in start until grouped.size){
   val row=grouped[i]
   val line=text(row)
   val top=row.minOf {it.top}
   val rowHeight=row.map {it.h()}.sorted().let {it[it.size/2]}
   if(date.containsMatchIn(line) || isTracking(row) || (stopAtFooter!=null && top>=stopAtFooter))break
   // A large gap means another block; use local font size rather than screen height.
   val gap=top-previousBottom
   val normalizedLine=AddressOcrText.normalize(line)
   val alignedLocation=(city.containsMatchIn(normalizedLine) || zip.containsMatchIn(normalizedLine)) &&
    abs(row.minOf {it.left}-anchorLeft)<=maxOf(previousHeight,rowHeight)*2 &&
    !road.containsMatchIn(line)
   // A separated city/CEP row may still belong to this card, but never cross a
   // tracking/date/footer boundary or jump to an unrelated column/block.
   val maxGap=maxOf(previousHeight,rowHeight)*(if(alignedLocation)6 else 3)
   if(i>start && gap>maxGap)break
   selected.add(line)
   previousBottom=row.maxOf {it.bottom};previousHeight=rowHeight
   val joined=AddressOcrText.normalize(selected.joinToString(" "))
   if(city.containsMatchIn(joined) && zip.containsMatchIn(joined))break
  }
  return Selection(selected.joinToString("\n"),selected,"parcel rows; track=$firstTrack street=$streetIndex actions=${actions.size}")
 }
}
